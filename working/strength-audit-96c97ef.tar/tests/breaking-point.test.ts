import { withImmediateAttacks } from "./helpers/attack-response-fixtures";
import { describe, expect, it } from "vitest";

// Ported from script/probe/check-breaking-point.mjs.
describe("breaking-point", () => {
  it("Breaking Point stacking and dodge proc cooldown checks passed", async () => {
    const { buildRotationTimeline } = await import("../src/calculations/rotationTimeline.ts");
    const buffs = (await import("../data/buff/bamboocut-wind.json")).default;
    const breakingPoint = (await import("../data/innerway/breaking-point.json")).default;
    const generalSkills = (await import("../data/skill/general.json")).default;

    const hit = {
      name: "Breaking Point probe hit",
      castTime: 1,
      action: [{ type: "damage", phyCoef: 1, attrCoef: 1, time: 0.5 }],
      modifier: [],
      tags: ["DirectDamage"],
    };
    const exhausted = {
      name: "Exhausted",
      castTime: 0,
      action: [{ type: "apply", target: "target", value: "Exhausted", time: 0 }],
      tags: ["Event"],
    };
    const triggerDefinition = breakingPoint.effect.BreakingPointT0.trigger[0];
    const triggerRule = {
      requirement: triggerDefinition.requirement,
      trigger: { target: triggerDefinition.target, action: triggerDefinition.action },
      effect: {},
      source: "BreakingPoint",
      tier: 0,
    };
    const maxStackRule = {
      ...breakingPoint.effect.BreakingPointT4.effect[0],
      source: "BreakingPoint",
      tier: 4,
    };
    const stackStarts = (hitCount, highTier) => {
      const timeline = buildRotationTimeline({
        rotation: {
          name: "Breaking Point stacking probe",
          steps: [
            ...Array.from({ length: hitCount }, () => ({ type: "skill", skill: "Hit" })),
            { type: "event", event: "Exhausted", startTime: 0 },
          ],
          eventTimeReference: "battleStart",
        },
        skills: { Hit: hit },
        eventDefinitions: { Exhausted: exhausted },
        dots: {},
        effectDefinitions: { ...buffs, Exhausted: { name: "Exhausted", duration: 100, maxStack: 1 } },
        innerWayConditions: Array.from({ length: highTier ? 5 : 1 }, (_, tier) => `BreakingPointT${tier}`),
        innerWayRules: highTier ? [triggerRule, maxStackRule] : [triggerRule],
        setupEffects: [],
        weapons: [],
      });
      return timeline
        .filter((row) => row.kind === "rotation" && row.step.type === "skill")
        .map((row) => row.buffs.find((effect) => effect.name === "Disintegration")?.stack ?? 0);
    };
    expect(
      JSON.stringify(stackStarts(4, false)) === JSON.stringify([0, 1, 2, 3]),
      "Repeated Breaking Point triggers must accumulate to the default three-stack cap.",
    ).toBeTruthy();
    expect(
      JSON.stringify(stackStarts(6, true)) === JSON.stringify([0, 1, 2, 3, 4, 5]),
      "Breaking Point T4 must accumulate Disintegration to five stacks.",
    ).toBeTruthy();
    for (const firstDodge of ["PerfectDodge", "PerfectDodgeCancel"]) {
      const secondDodge = firstDodge === "PerfectDodge" ? "PerfectDodgeCancel" : "PerfectDodge";
      const firstCastTime = firstDodge === "PerfectDodge" ? 0.5 : 0;
      const secondCastTime = secondDodge === "PerfectDodge" ? 0.5 : 0;
      const runDodgeProbe = (tier) =>
        buildRotationTimeline({
          rotation: {
            name: "Breaking Point dodge cooldown probe",
            steps: [
              { type: "skill", skill: firstDodge },
              { type: "skill", skill: "Observe" },
              { type: "event", event: "Delay", duration: 4 - firstCastTime },
              { type: "skill", skill: secondDodge },
              { type: "skill", skill: "Observe" },
              { type: "skill", skill: "Hit" },
              { type: "skill", skill: "Observe" },
              { type: "event", event: "Delay", duration: 10 - secondCastTime },
              { type: "skill", skill: firstDodge },
              { type: "skill", skill: "Observe" },
              { type: "event", event: "Exhausted", startTime: 0 },
            ],
            eventTimeReference: "battleStart",
          },
          skills: withImmediateAttacks({
            ...generalSkills,
            Hit: hit,
            Observe: { name: "Observe", castTime: 0, action: [], tags: [] },
          }),
          eventDefinitions: { Exhausted: exhausted },
          dots: {},
          effectDefinitions: { ...buffs, Exhausted: { name: "Exhausted", duration: 100, maxStack: 1 } },
          innerWayConditions: Array.from({ length: tier + 1 }, (_, index) => `BreakingPointT${index}`),
          innerWayRules: [triggerRule, maxStackRule],
          setupEffects: [],
          weapons: [],
          initialResources: { Vitality: 0 },
          resourceMaximums: { Vitality: 40 },
        });
      const timeline = runDodgeProbe(6);
      expect(
        timeline.filter((row) => row.step.skill === "Observe").at(-1).resources.Vitality === 9,
        "All three dodges must grant Vitality even when the BP T6 proc is on cooldown.",
      ).toBeTruthy();
      const observedStacks = timeline
        .filter((row) => row.step.skill === "Observe")
        .map((row) => row.buffs.find((effect) => effect.name === "Disintegration")?.stack ?? 0);
      expect(
        JSON.stringify(observedStacks) === JSON.stringify([5, 0, 1, 5]),
        "Dodge must share only the T6 proc cooldown, permit normal stacks during it, and proc again at 15 seconds.",
      ).toBeTruthy();
      const dodges = timeline.filter(
        (row) => row.kind === "rotation" && [firstDodge, secondDodge].includes(row.step.skill),
      );
      expect(
        JSON.stringify(dodges.map((row) => row.startTime)) === JSON.stringify([0, 4, 15]),
        "The BP T6 proc cooldown must not delay either dodge variant.",
      ).toBeTruthy();
      const belowT6 = runDodgeProbe(5)
        .filter((row) => row.step.skill === "Observe")
        .map((row) => row.buffs.find((effect) => effect.name === "Disintegration")?.stack ?? 0);
      expect(
        JSON.stringify(belowT6) === JSON.stringify([0, 0, 1, 0]),
        "Dodges must not grant Disintegration below Breaking Point T6.",
      ).toBeTruthy();
    }
  });
});
