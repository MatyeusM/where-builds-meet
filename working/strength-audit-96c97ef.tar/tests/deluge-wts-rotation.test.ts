import { describe, expect, it } from "vitest";

// Ported from script/probe/check-deluge-wts-rotation.mjs.
describe("deluge-wts-rotation", () => {
  it("Deluge WTS sequence and standard dummy-attack schedule verified", async () => {
    const rotation = (await import("../data/rotation/silkbind-deluge/dummy-1-min-wts.json")).default;
    const panacea = (await import("../data/skill/panacea-fan.json")).default;
    const soulshade = (await import("../data/skill/soulshade-umbrella.json")).default;
    const mystic = (await import("../data/skill/mystic.json")).default;
    const general = (await import("../data/skill/general.json")).default;
    const mysticBuffs = (await import("../data/buff/mystic.json")).default;
    const generalBuffs = (await import("../data/buff/general.json")).default;
    const delugeBuffs = (await import("../data/buff/silkbind-deluge.json")).default;
    const mysticDebuffs = (await import("../data/debuff/mystic.json")).default;
    const generalDebuffs = (await import("../data/debuff/general.json")).default;
    const dots = (await import("../data/dot/mystic.json")).default;
    const { buildRotationTimeline } = await import("../src/calculations/rotationTimeline.ts");
    const { mergeCalculatedTimelineState } = await import("../src/calculations/rotationTimeline.ts");
    const { calculateRotationBaseline } = await import("../src/calculations/rotationCalculator.ts");
    const { calculateHealingAttackSnapshot } = await import("../src/calculations/healing.ts");
    const { calculateDerivedStats } = await import("../src/calculations/effectiveStats.ts");
    const { emptyStats } = await import("../src/data/statDefinitions.ts");
    const timelineInput = {
      rotation,
      skills: { ...panacea, ...soulshade, ...mystic, ...general },
      eventDefinitions: {
        TakeDamage: {
          name: "Take Damage",
          castTime: 0,
          action: [{ type: "takeDamage", time: 0 }],
          tags: ["Event"],
        },
        BattleEnd: { name: "Battle End", castTime: 0, action: [], tags: ["Event"] },
      },
      dots,
      effectDefinitions: {
        ...mysticBuffs,
        ...generalBuffs,
        ...delugeBuffs,
        ...mysticDebuffs,
        ...generalDebuffs,
        ...dots,
      },
      innerWayConditions: [],
      innerWayRules: [],
      setupEffects: [],
      weapons: ["panaceaFan", "soulshadeUmbrella"],
    };
    const timeline = buildRotationTimeline(timelineInput);
    const anchorRow = timeline.find((row) => row.id === `rotation-${rotation.start.step}`)!;
    const anchorTime = anchorRow.startTime + Number(anchorRow.actions[rotation.start.action]?.time ?? 0);
    for (const preset of [
      rotation,
      (await import("../data/rotation/silkbind-deluge/dummy-1-min-wts-team.json")).default,
    ]) {
      const rows = buildRotationTimeline({ ...timelineInput, rotation: preset });
      expect(
        !rows.some((row) => row.step.skill === "EchoesOfAThousandPlantsFanQQ"),
        "Cancelled Fan QQ must not trigger Echoes in either WTS preset.",
      ).toBeTruthy();
      expect(
        rows
          .filter((row) => row.kind === "rotation" && row.step.skill === "EchoesOfAThousandPlants")
          .every((row) => !row.cooldownWait),
        "Cancelled Fan QQ must leave the preset's manual Umbrella Special available.",
      ).toBeTruthy();
    }
    const deflectRows = timeline.filter(
      (row) => row.kind === "rotation" && row.step.type === "skill" && row.step.skill === "DeflectSuccessful",
    );
    const manualAttackRows = timeline.filter(
      (row) =>
        row.step.type === "event" &&
        row.step.event === "TakeDamage" &&
        row.step.automatic !== "dummyAttack" &&
        row.startTime - anchorTime < 60,
    );
    expect(manualAttackRows.length === 0, "The preset must not invent manual Take Damage events.").toBeTruthy();
    const automaticAttackRows = timeline.filter(
      (row) => row.step.type === "event" && row.step.event === "TakeDamage" && row.step.automatic === "dummyAttack",
    );
    expect(
      automaticAttackRows.length === 20 &&
        automaticAttackRows.every(
          (row, index) => Math.abs(row.startTime - anchorTime - (5.5 + Math.floor(index / 2) * 6)) < 1e-9,
        ),
      "The preset must use only the standard paired dummy attacks every six seconds from 5.5 seconds.",
    ).toBeTruthy();
    expect(
      deflectRows.every((row) => row.startTime < 60),
      "Every requested Successful Deflect must occur before the one-minute battle end.",
    ).toBeTruthy();
    const stats = {
      ...emptyStats,
      minPhys: 1000,
      maxPhys: 1000,
      minSilkbind: 500,
      maxSilkbind: 500,
      precision: 1,
    };
    const voidSnapshot = calculateHealingAttackSnapshot({
      stats: { ...stats, minVoidAttack: 100, maxVoidAttack: 200 },
      derivedStats: calculateDerivedStats({ ...stats, minVoidAttack: 100, maxVoidAttack: 200 }, 0, {}, [
        "panaceaFan",
        "soulshadeUmbrella",
      ]),
      effects: [],
      enemy: { judgementResistance: 0 },
      weapons: ["panaceaFan", "soulshadeUmbrella"],
    });
    expect(
      Math.abs(voidSnapshot.averageSilkbindAttack - 650) < 1e-9,
      "World to Sword must include Deluge's Void Attack conversion in its effective Silkbind threshold snapshot.",
    ).toBeTruthy();
    const timelineBundle = {
      ...timelineInput,
      initialResources: { Vitality: 100 },
      resourceMaximums: { Vitality: 100 },
      maxHP: 100000,
    };
    const baseline = calculateRotationBaseline({
      timeline: timelineBundle,
      startAnchor: { rowId: "rotation-0" },
      stats,
      attunement: {},
      enemy: {
        name: "Probe",
        level: 96,
        defense: 0,
        physicalResistance: 0,
        bellstrikeResistance: 0,
        stonesplitResistance: 0,
        silkbindResistance: 0,
        bamboocutResistance: 0,
        judgementResistance: 0,
        setupEffects: [],
        weapons: ["panaceaFan", "soulshadeUmbrella"],
      },
      derivedStats: calculateDerivedStats(stats, 0),
      weapons: ["panaceaFan", "soulshadeUmbrella"],
      statPriority: [],
      attunementPriority: [],
      innerWayPriority: [],
      setupComparisons: {},
    });
    const groupResult = (groupSize) =>
      calculateRotationBaseline({
        timeline: {
          ...timelineBundle,
          rotation: { ...rotation, groupSize },
        },
        startAnchor: { rowId: "rotation-0" },
        stats,
        attunement: {},
        enemy: {
          name: "Probe",
          level: 96,
          defense: 0,
          physicalResistance: 0,
          bellstrikeResistance: 0,
          stonesplitResistance: 0,
          silkbindResistance: 0,
          bamboocutResistance: 0,
          judgementResistance: 0,
          setupEffects: [],
          weapons: ["panaceaFan", "soulshadeUmbrella"],
        },
        derivedStats: calculateDerivedStats(stats, 0),
        weapons: ["panaceaFan", "soulshadeUmbrella"],
        statPriority: [],
        attunementPriority: [],
        innerWayPriority: [],
        setupComparisons: {},
      });
    const teamBaseline = groupResult(5);
    const groupBaseline = groupResult(10);
    const qiBladeHits = (result) => result.metrics.breakdown.skills.find((skill) => skill.id === "QiBlade")?.hits ?? 0;
    expect(
      baseline.metrics.totalHealing < teamBaseline.metrics.totalHealing &&
        teamBaseline.metrics.totalHealing < groupBaseline.metrics.totalHealing,
      "Changing the WTS preset from Solo to Team to Group must increase recipient-weighted healing.",
    ).toBeTruthy();
    expect(
      qiBladeHits(baseline) < qiBladeHits(teamBaseline) && qiBladeHits(teamBaseline) <= qiBladeHits(groupBaseline),
      "Changing the WTS preset group size must increase its overheal-driven Qi Blade triggers.",
    ).toBeTruthy();
    const qiBladeBreakdown = baseline.metrics.breakdown.skills.find((skill) => skill.id === "QiBlade");
    expect(qiBladeBreakdown?.hits, "The WTS preset must trigger Qi Blade damage before Battle End.").toBeTruthy();
    const worldToSwordCast = baseline.metrics.breakdown.casts.find((cast) => cast.skillId === "WorldToSword");
    expect(
      worldToSwordCast?.casts === 2 && Math.abs(worldToSwordCast.damage - qiBladeBreakdown.damage) < 1e-9,
      "The WTS per-cast row must own all damage dealt by its triggered Qi Blades.",
    ).toBeTruthy();
    expect(
      !baseline.metrics.breakdown.casts.some((cast) => cast.skillId === "QiBlade"),
      "Triggered Qi Blades must not appear as a separate per-cast row.",
    ).toBeTruthy();
    const displayedTimeline = mergeCalculatedTimelineState(timeline, baseline.timeline);
    expect(
      displayedTimeline.some((row) => row.step.type === "skill" && row.step.skill === "QiBlade"),
      "The rotation editor timeline must retain worker-created Qi Blade rows.",
    ).toBeTruthy();
  });
});
