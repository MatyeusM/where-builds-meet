import { describe, it } from "vitest";

// Ported from script/probe/check-calculation-fingerprint-cache.mjs.
describe("calculation-fingerprint-cache", () => {
  it("Calculation fingerprint cache probe passed", async () => {
    const { calculationFingerprint, rotationBundleFingerprint, RotationCalculationCache } =
      await import("../src/calculations/rotationCalculationCache.ts");
    const cache = new RotationCalculationCache();
    const setupA = calculationFingerprint({ stats: { minPhys: 1 }, selector: "A", rotation: ["SkillA"] });
    const setupB = calculationFingerprint({ stats: { minPhys: 2 }, selector: "B", rotation: ["SkillA"] });
    const setupC = calculationFingerprint({ stats: { minPhys: 3 }, selector: "C", rotation: ["SkillA"] });
    const baselineA = { metrics: { dps: 100 } };
    const baselineB = { metrics: { dps: 200 } };
    const baselineC = { metrics: { dps: 300 } };
    const variant = calculationFingerprint({ category: "food", value: "Fish" });
    const variantA = { dps: 101 };

    cache.storeBaseline(setupA, baselineA);
    cache.storeVariant(setupA, variant, variantA);
    cache.storeBaseline(setupB, baselineB);
    cache.storeBaseline(setupC, baselineC);

    if (cache.baseline(setupA) !== baselineA) throw new Error("Returning to setup A did not restore its baseline.");
    if (cache.variant(setupA, variant) !== variantA) throw new Error("Setup A did not restore its cached variant.");
    if (cache.variant(setupB, variant) !== undefined)
      throw new Error("A cached variant leaked into a different setup fingerprint.");
    if (new Set([setupA, setupB, setupC]).size !== 3)
      throw new Error("Distinct setup inputs produced duplicate fingerprints.");

    const namedRotationBundle = (name, skill, weapons = ["snowparting", "phalanxbane"]) => ({
      timeline: { rotation: { name, steps: [{ type: "skill", skill }] } },
      weapons,
    });
    const rotationA = rotationBundleFingerprint(namedRotationBundle("First name", "SkillA"));
    const renamedRotationA = rotationBundleFingerprint(namedRotationBundle("Renamed", "SkillA"));
    const rotationB = rotationBundleFingerprint(namedRotationBundle("First name", "SkillB"));
    const reversedMartialArts = rotationBundleFingerprint(
      namedRotationBundle("First name", "SkillA", ["phalanxbane", "snowparting"]),
    );
    if (rotationA !== renamedRotationA)
      throw new Error("Display-only rotation names changed the calculation fingerprint.");
    if (rotationA === rotationB) throw new Error("Different rotation step content produced the same fingerprint.");
    if (rotationA === reversedMartialArts)
      throw new Error("Different ordered martial-art selections produced the same fingerprint.");

    const rotationSettings = [
      ["target HP", { targetHP: 100000 }],
      ["automatic HP", { autoHP: true }],
      ["dummy attacks", { dummyAttack: true }],
      ["group size", { groupSize: 5 }],
      ["infinite Vitality", { infiniteVitality: true }],
      ["battle-start event timing", { eventTimeReference: "battleStart" }],
      ["battle start anchor", { start: { step: 0, action: 0 } }],
    ];
    const baseRotation = { name: "Settings", steps: [{ type: "skill", skill: "SkillA" }], groupSize: 1 };
    const baseSettingsFingerprint = rotationBundleFingerprint({ timeline: { rotation: baseRotation }, weapons: [] });
    for (const [label, setting] of rotationSettings) {
      const changedFingerprint = rotationBundleFingerprint({
        timeline: { rotation: { ...baseRotation, ...setting } },
        weapons: [],
      });
      if (changedFingerprint === baseSettingsFingerprint)
        throw new Error(`Changing ${label} did not change the rotation calculation fingerprint.`);
    }
  });
});
