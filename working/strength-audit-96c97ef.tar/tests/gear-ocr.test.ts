import { describe, expect, it } from "vitest";
import { existsSync } from "node:fs";
import { createWorker, OEM, PSM } from "tesseract.js";
import { inferGearLevelAndRarity, parseGearOcrTsv } from "../src/gearOcr";

// Ported from script/probe/check-gear-ocr.mjs. Screenshot recognition needs
// the gitignored local/OCR fixtures; the pure parsing checks always run.
const moBladeImage = "local/OCR/mo blade.png";
const helmetImage = "local/OCR/helmet.png";
const screenshotsPresent = existsSync(moBladeImage) && existsSync(helmetImage);

describe("gear-ocr", () => {
  it.skipIf(!screenshotsPresent)("recognizes gear screenshots", async () => {
    const worker = await createWorker("eng", OEM.LSTM_ONLY, { langPath: "public/ocr" });
    try {
      const recognize = async (path, width, height) => {
        await worker.setParameters({ tessedit_pageseg_mode: PSM.SINGLE_BLOCK, preserve_interword_spaces: "1" });
        const metadata = await worker.recognize(path, {}, { text: true, tsv: true });
        await worker.setParameters({ tessedit_pageseg_mode: PSM.SPARSE_TEXT, preserve_interword_spaces: "1" });
        const positioned = await worker.recognize(path, {}, { text: true, tsv: true });
        return parseGearOcrTsv(positioned.data.tsv, `${metadata.data.text}\n${positioned.data.text}`, width, height);
      };

      const moBlade = await recognize("local/OCR/mo blade.png", 583, 797);
      expect(
        moBlade.definitionId === "moBlade" && moBlade.level === 96 && moBlade.rarity === "Gold" && !moBlade.relayed,
        "Mo Blade metadata was not recognized.",
      ).toBeTruthy();
      expect(
        moBlade.baseAffix.key === "maxPhys" && moBlade.baseAffix.value === 55,
        "Mo Blade base affix was not recognized.",
      ).toBeTruthy();
      expect(
        moBlade.additionalAffixes.map((affix) => affix.key).join(",") === "moBladeDmgBoost,maxPhys,crit,maxVoidAttack",
        "Mo Blade additional affixes were not recognized in order.",
      ).toBeTruthy();
      expect(
        Math.abs(moBlade.additionalAffixes[0].value - 0.06) < 1e-9 &&
          Math.abs(moBlade.additionalAffixes[2].value - 0.088) < 1e-9,
        "Mo Blade percentage values were not converted to ratios.",
      ).toBeTruthy();
      expect(
        moBlade.attunement.key === "physicalPenetration" && moBlade.attunement.value === 10,
        "Mo Blade attunement was not recognized.",
      ).toBeTruthy();

      await worker.setParameters({ tessedit_pageseg_mode: PSM.SINGLE_BLOCK, preserve_interword_spaces: "1" });
      const moBladeBlock = await worker.recognize("local/OCR/mo blade.png", {}, { text: true, tsv: true });
      const moBladeFallback = parseGearOcrTsv(moBladeBlock.data.tsv, moBladeBlock.data.text, 583, 797);
      expect(
        moBladeFallback.additionalAffixes.length === 4 && moBladeFallback.attunement.key === "physicalPenetration",
        "The block-layout fallback must recognize all six Mo Blade rows.",
      ).toBeTruthy();
      const moBladeDifferentCrop = parseGearOcrTsv(moBladeBlock.data.tsv, moBladeBlock.data.text, 583, 2000);
      expect(
        moBladeDifferentCrop.additionalAffixes.map((affix) => affix.key).join(",") ===
          "moBladeDmgBoost,maxPhys,crit,maxVoidAttack" && moBladeDifferentCrop.attunement.key === "physicalPenetration",
        "Affix row recognition must not depend on the screenshot height.",
      ).toBeTruthy();

      const helmet = await recognize("local/OCR/helmet.png", 564, 811);
      expect(
        helmet.definitionId === "helmet" && helmet.level === 96 && helmet.rarity === "Purple" && helmet.relayed,
        "Helmet metadata was not recognized.",
      ).toBeTruthy();
      expect(
        helmet.baseAffix.key === "precision" && Math.abs(helmet.baseAffix.value - 0.075) < 1e-9,
        "Helmet base affix was not recognized.",
      ).toBeTruthy();
      expect(
        helmet.additionalAffixes.map((affix) => affix.key).join(",") === "minPhys,agility,crit,maxStonesplit",
        "Helmet additional affixes were not recognized in order.",
      ).toBeTruthy();
      expect(
        helmet.additionalAffixes[0].value === 73.1 && helmet.additionalAffixes[1].value === 46.4,
        "Helmet numeric values were not recognized.",
      ).toBeTruthy();
      expect(
        helmet.attunement.key === "phalanxbaneChargedBoost" && Math.abs(helmet.attunement.value - 0.054) < 1e-9,
        "Helmet attunement was not recognized.",
      ).toBeTruthy();
    } finally {
      await worker.terminate();
    }
  });

  it("infers rarity and tolerates unclear OCR fields without screenshots", () => {
    const inferredPurple = inferGearLevelAndRarity("helmet", "Gear Tier 96 Max HP 5196 Physical Defense 20");
    expect(
      inferredPurple.level === 96 && inferredPurple.rarity === "Purple",
      "Fixed base stats must determine rarity.",
    ).toBeTruthy();
    const defaultMetadata = inferGearLevelAndRarity("helmet", "unreadable metadata");
    expect(
      defaultMetadata.level === 96 && defaultMetadata.rarity === "Gold",
      "Unclear metadata must default to 96 Gold.",
    ).toBeTruthy();
    const partial = parseGearOcrTsv(
      "5\t1\t1\t1\t1\t1\t10\t10\t100\t20\t90\tUnreadable",
      "Unreadable",
      500,
      500,
      "moBlade",
    );
    expect(
      partial.definitionId === "moBlade" &&
        partial.level === 96 &&
        partial.rarity === "Gold" &&
        !partial.baseAffix &&
        partial.additionalAffixes.length === 0 &&
        !partial.attunement,
      "Unclear OCR fields must use the editor gear type and leave attribute rows empty.",
    ).toBeTruthy();
  });
});
