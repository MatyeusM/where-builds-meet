import { describe, expect, it } from "vitest";

// Ported from script/probe/check-cast-breakdown.mjs.
describe("cast-breakdown", () => {
  it("Per-cast buff attribution, Deflect timing, and zero-damage filtering checks passed", async () => {
    const { calculateRotationBaseline } = await import("../src/calculations/rotationCalculator.ts");
    const { calculateDerivedStats } = await import("../src/calculations/effectiveStats.ts");
    const { emptyStats } = await import("../src/data/statDefinitions.ts");
    const stats = { ...emptyStats, minPhys: 100, maxPhys: 100, precision: 1 };
    const enemy = {
      name: "Probe",
      level: 96,
      defense: 0,
      physicalResistance: 0,
      bellstrikeResistance: 0,
      stonesplitResistance: 0,
      silkbindResistance: 0,
      bamboocutResistance: 0,
      judgementResistance: 0,
    };
    const result = calculateRotationBaseline({
      timeline: {
        rotation: {
          name: "Cast breakdown probe",
          steps: [
            { type: "skill", skill: "Base" },
            { type: "skill", skill: "Deflect" },
            { type: "skill", skill: "Utility" },
            { type: "skill", skill: "Base" },
          ],
        },
        skills: {
          Base: {
            name: "Base",
            castTime: 2,
            action: [
              { type: "damage", phyCoef: 1, attrCoef: 1, time: 0 },
              { type: "trigger", value: "Child", time: 0.5 },
              { type: "consumeResource", value: "Vitality", amount: 10, time: 0 },
            ],
            modifier: [],
            tags: ["BaseOnly"],
          },
          Deflect: { name: "Deflect", castTime: 0.5, action: [], modifier: [], tags: ["Deflect"] },
          Utility: {
            name: "Utility",
            castTime: 1,
            action: [{ type: "apply", target: "self", value: "Utility", time: 0 }],
            modifier: [],
            tags: [],
          },
          Child: {
            name: "Child",
            castTime: 0,
            action: [{ type: "damage", phyCoef: 1, attrCoef: 1, time: 0 }],
            modifier: [],
            tags: ["Triggered"],
          },
          MoraleChant: {
            name: "Morale Chant",
            castTime: 0,
            action: [{ type: "damage", phyCoef: 1, attrCoef: 1, time: 0 }],
            modifier: [],
            tags: ["Triggered"],
          },
        },
        eventDefinitions: {},
        dots: {},
        effectDefinitions: {},
        innerWayConditions: [],
        setupEffects: [],
        weapons: [],
        innerWayRules: [
          {
            source: "MoraleChant",
            tier: 6,
            requirement: [{ target: "skillTag", value: "BaseOnly" }],
            effect: {},
            trigger: { event: "damage", action: [{ type: "trigger", value: "MoraleChant" }] },
          },
        ],
      },
      startAnchor: { rowId: "rotation-0" },
      stats,
      attunement: {},
      enemy,
      derivedStats: calculateDerivedStats(stats, 0),
      weapons: [],
      statPriority: [],
      attunementPriority: [],
      innerWayPriority: [],
      setupComparisons: {},
    });
    const baseRows = result.timeline.filter((row) => row.step.type === "skill" && row.step.skill === "Base");
    const childRows = result.timeline.filter((row) => row.step.type === "skill" && row.step.skill === "Child");
    const moraleRows = result.timeline.filter((row) => row.step.type === "skill" && row.step.skill === "MoraleChant");
    const baseCast = result.metrics.breakdown.casts.find((row) => row.skillId === "Base");
    const moraleCast = result.metrics.breakdown.casts.find((row) => row.skillId === "MoraleChant");
    const damage = (row) => (row ? (result.actionBreakdowns[`${row.id}:0`]?.total ?? 0) : 0);
    const damageSum = (rows) => rows.reduce((total, row) => total + damage(row), 0);
    expect(
      result.metrics.breakdown.casts.length === 2,
      "Repeated casts must group into one skill row, with Inner Way triggers in their own group.",
    ).toBeTruthy();
    expect(
      baseCast?.casts === 2 && Math.abs(baseCast.damage - damageSum(baseRows) - damageSum(childRows)) < 1e-9,
      "Directly triggered skill damage must sum into its grouped base casts.",
    ).toBeTruthy();
    expect(
      moraleCast?.casts === 2 && Math.abs(moraleCast.damage - damageSum(moraleRows)) < 1e-9,
      "Inner Way-triggered Morale Chant damage must remain a separate grouped row.",
    ).toBeTruthy();
    const damagePerBaseCast = baseCast.damage / baseCast.casts;
    const expectedAverageDps = (damagePerBaseCast / 2.5 + damagePerBaseCast / 2) / 2;
    expect(
      baseCast.averageCastTime === 2.25 &&
        Math.abs(baseCast.averageDamage - damagePerBaseCast) < 1e-9 &&
        Math.abs((baseCast.averageDps ?? 0) - expectedAverageDps) < 1e-9,
      "Per-cast damage must be averaged by cast count while a following Deflect contributes to the DPS time sample.",
    ).toBeTruthy();
    expect(
      baseCast.vitalitySpent === 20 && Math.abs((baseCast.damagePerVitality ?? 0) - baseCast.damage / 20) < 1e-9,
      "Per-cast groups must report gross Vitality consumption and their total attributed damage per Vitality.",
    ).toBeTruthy();
    expect(
      !result.metrics.breakdown.casts.some((row) => row.skillId === "Deflect" || row.skillId === "Utility"),
      "Skills with no attributed damage must be omitted from per-cast breakdown.",
    ).toBeTruthy();
    expect(
      result.metrics.breakdown.casts[0].skillId === "Base",
      "Grouped cast rows must be sorted by average DPS descending.",
    ).toBeTruthy();

    const attributionBundle = (withFluteEffect) => ({
      timeline: {
        rotation: {
          name: "Flute attribution probe",
          steps: [
            { type: "skill", skill: "FluteCast" },
            { type: "skill", skill: "Hit" },
          ],
        },
        skills: {
          FluteCast: {
            name: "Flute",
            collectBoostDamage: "Flute",
            castTime: 1,
            action: [
              { type: "apply", target: "self", value: "OtherBuff", time: 0 },
              { type: "apply", target: "self", value: "Flute", time: 0 },
            ],
            modifier: [],
            tags: ["FluteOfTheTides"],
          },
          Hit: {
            name: "Hit",
            castTime: 1,
            action: [{ type: "damage", phyCoef: 1, attrCoef: 1, time: 0.5 }],
            modifier: [],
            tags: ["DirectDamage"],
          },
        },
        eventDefinitions: {},
        dots: {},
        effectDefinitions: {
          Flute: {
            name: "Flute",
            duration: 10,
            maxStack: 1,
            effect: withFluteEffect ? [{ effect: { dmgBonus: 0.2 } }] : [],
          },
          OtherBuff: {
            name: "Other Buff",
            duration: 10,
            maxStack: 1,
            effect: [{ effect: { dmgBonus: 0.5 } }],
          },
        },
        innerWayConditions: [],
        innerWayRules: [],
        setupEffects: [],
        weapons: [],
      },
      startAnchor: { rowId: "rotation-0" },
      stats,
      attunement: {},
      enemy,
      derivedStats: calculateDerivedStats(stats, 0),
      weapons: [],
      statPriority: [],
      attunementPriority: [],
      innerWayPriority: [],
      setupComparisons: {},
    });
    const attributed = calculateRotationBaseline(attributionBundle(true));
    const unbuffed = calculateRotationBaseline(attributionBundle(false));
    const fluteCast = attributed.metrics.breakdown.casts.find((row) => row.skillId === "FluteCast");
    const fluteDifference = attributed.metrics.totalDamage - unbuffed.metrics.totalDamage;
    expect(fluteDifference > 0, "The Flute buff must increase the following hit.").toBeTruthy();
    expect(
      fluteCast?.damage === 0 &&
        fluteCast.averageDamage === 0 &&
        Math.abs((fluteCast.damageWithBuff ?? 0) - fluteDifference) < 1e-9 &&
        Math.abs((fluteCast.averageDamageWithBuff ?? 0) - fluteDifference) < 1e-9,
      "Flute's inclusive total and per-cast damage must add exactly the damage caused by its buff.",
    ).toBeTruthy();
    expect(
      fluteCast?.averageDps === 0 && Math.abs((fluteCast.averageDpsWithBuff ?? 0) - fluteDifference) < 1e-9,
      "Flute's inclusive average DPS must include its attributed buff damage.",
    ).toBeTruthy();

    const ghostlyAttributionBundle = (withGhostlyEffect) => ({
      timeline: {
        rotation: {
          name: "Ghostly attribution probe",
          steps: [
            { type: "skill", skill: "GhostlyCast" },
            { type: "skill", skill: "PerfectDodge" },
            { type: "skill", skill: "Hit" },
          ],
        },
        skills: {
          GhostlyCast: {
            name: "Ghostly Step",
            collectBoostDamage: "MysteryDMGBoost",
            castTime: 1,
            action: [{ type: "apply", target: "self", value: "Mystery", time: 0 }],
            modifier: [],
            tags: ["GhostlySteps"],
          },
          PerfectDodge: {
            name: "Perfect Dodge",
            castTime: 1,
            action: [
              {
                type: "apply",
                target: "self",
                value: "MysteryDMGBoost",
                time: 0,
                requirement: [{ target: "self", value: "Mystery" }],
              },
            ],
            modifier: [],
            tags: ["PerfectDodge"],
          },
          Hit: {
            name: "Hit",
            castTime: 1,
            action: [{ type: "damage", phyCoef: 1, attrCoef: 1, time: 0.5 }],
            modifier: [],
            tags: ["DirectDamage"],
          },
        },
        eventDefinitions: {},
        dots: {},
        effectDefinitions: {
          Mystery: { name: "Mystery", duration: 10, maxStack: 1, effect: [] },
          MysteryDMGBoost: {
            name: "Mystery DMG Boost",
            duration: 10,
            maxStack: 1,
            effect: withGhostlyEffect ? [{ effect: { dmgBonus: 0.15 } }] : [],
          },
        },
        innerWayConditions: [],
        innerWayRules: [],
        setupEffects: [],
        weapons: [],
      },
      startAnchor: { rowId: "rotation-0" },
      stats,
      attunement: {},
      enemy,
      derivedStats: calculateDerivedStats(stats, 0),
      weapons: [],
      statPriority: [],
      attunementPriority: [],
      innerWayPriority: [],
      setupComparisons: {},
    });
    const ghostlyAttributed = calculateRotationBaseline(ghostlyAttributionBundle(true));
    const ghostlyUnbuffed = calculateRotationBaseline(ghostlyAttributionBundle(false));
    const ghostlyCast = ghostlyAttributed.metrics.breakdown.casts.find((row) => row.skillId === "GhostlyCast");
    const ghostlyDifference = ghostlyAttributed.metrics.totalDamage - ghostlyUnbuffed.metrics.totalDamage;
    expect(ghostlyDifference > 0, "Mystery DMG Boost must increase the following hit.").toBeTruthy();
    expect(
      ghostlyCast?.damage === 0 &&
        ghostlyCast.averageDamage === 0 &&
        Math.abs((ghostlyCast.damageWithBuff ?? 0) - ghostlyDifference) < 1e-9 &&
        Math.abs((ghostlyCast.averageDamageWithBuff ?? 0) - ghostlyDifference) < 1e-9,
      "Ghostly Step's total and per-cast damage must inherit the indirect buff damage applied through Perfect Dodge.",
    ).toBeTruthy();
    expect(
      !ghostlyAttributed.metrics.breakdown.casts.some((row) => row.skillId === "PerfectDodge"),
      "Perfect Dodge must not own Ghostly Step's attributed buff damage.",
    ).toBeTruthy();
  });
});
