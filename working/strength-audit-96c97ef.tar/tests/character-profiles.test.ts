import { describe, expect, it } from "vitest";

// Ported from script/probe/check-character-profiles.mjs.
describe("character-profiles", () => {
  it("Character profile validation, matching, export, and collision-safe import checks passed", async () => {
    const { characterProfileMatches, exportCharacterProfiles, mergeImportedCharacterProfiles, parseCharacterProfiles } =
      await import("../src/characterProfiles.ts");
    const parsed = parseCharacterProfiles([
      {
        id: "profile-1",
        name: " Test Profile ",
        statOverrides: { minPhys: 123, unknownStat: 999, maxPhys: Number.NaN },
        attunementOverrides: { physicalPenetration: 0.051, unknownAttunement: 2 },
        breakthrough: "17",
        innerWays: [
          { innerWay: "FrostCladNight", tier: "T6" },
          { innerWay: "MoraleChant", tier: "T5" },
          { innerWay: "SteadfastDevotion", tier: "T4" },
          { innerWay: "ThroatPiercingArt", tier: "T3" },
        ],
        buildSetup: { gearSets: { Cleftpeak: 2, RainWhisper: 2 }, bowRingSet: "Precision", arsenal: "Stonesplit" },
        food: "SimmeringFishSlices",
        divinecraft: "FireWater",
        globalDebuffs: { phantomChime: true },
      },
    ]);
    expect(
      parsed.length === 1 && parsed[0].name === "Test Profile",
      "Profiles must load with a trimmed name.",
    ).toBeTruthy();
    expect(
      parsed[0].statOverrides.minPhys === 123 &&
        !("unknownStat" in parsed[0].statOverrides) &&
        !("maxPhys" in parsed[0].statOverrides),
      "Only finite known character overrides may load.",
    ).toBeTruthy();
    expect(
      parsed[0].attunementOverrides.physicalPenetration === 0.051 &&
        !("unknownAttunement" in parsed[0].attunementOverrides),
      "Only finite known attunement overrides may load.",
    ).toBeTruthy();
    expect(
      !("breakthrough" in parsed[0]) &&
        !("food" in parsed[0]) &&
        !("divinecraft" in parsed[0]) &&
        !("globalDebuffs" in parsed[0]),
      "Transient and legacy independent selections must be discarded from character profiles.",
    ).toBeTruthy();
    expect(
      parsed[0].buildSetup.weaponSets.Cleftpeak === 2 && parsed[0].buildSetup.armorSets.Formbend === 0,
      "Legacy gearSets must migrate to weaponSets while armor sets receive their default.",
    ).toBeTruthy();
    expect(
      characterProfileMatches(parsed[0], {
        statOverrides: { minPhys: 123 },
        attunementOverrides: { physicalPenetration: 0.051 },
        innerWays: parsed[0].innerWays.map((row) => ({ ...row })),
        buildSetup: {
          ...parsed[0].buildSetup,
          innerWays: parsed[0].innerWays.map((row) => ({ ...row })),
          weaponSets: { ...parsed[0].buildSetup.weaponSets },
          armorSets: { ...parsed[0].buildSetup.armorSets },
        },
      }),
      "Profile matching must include every profile-owned Main-tab selection.",
    ).toBeTruthy();

    expect(
      !characterProfileMatches(parsed[0], {
        statOverrides: { minPhys: 124 },
        attunementOverrides: { physicalPenetration: 0.051 },
        innerWays: parsed[0].innerWays.map((row) => ({ ...row })),
        buildSetup: {
          ...parsed[0].buildSetup,
          innerWays: parsed[0].innerWays.map((row) => ({ ...row })),
          weaponSets: { ...parsed[0].buildSetup.weaponSets },
          armorSets: { ...parsed[0].buildSetup.armorSets },
        },
      }),
      "Changing profile-owned character state must make the current Main-tab state differ from the saved profile.",
    ).toBeTruthy();

    const exported = JSON.parse(exportCharacterProfiles(parsed));
    expect(
      exported.version === 5 &&
        !("breakthrough" in exported.profiles[0]) &&
        exported.profiles[0].buildSetup.innerWays.length === 4 &&
        exported.profiles[0].buildSetup.weaponSets.Cleftpeak === 2 &&
        exported.profiles[0].buildSetup.armorSets.Formbend === 0 &&
        !("food" in exported.profiles[0]) &&
        !("divinecraft" in exported.profiles[0]) &&
        !("globalDebuffs" in exported.profiles[0]),
      "Profile export v5 must include build-backed setup selections but omit transient and independent session controls.",
    ).toBeTruthy();
    const merged = mergeImportedCharacterProfiles(parsed, exported);
    expect(
      merged.importedCount === 1 && merged.profiles.length === 2,
      "Import must append valid profiles.",
    ).toBeTruthy();
    expect(merged.profiles[1].id !== parsed[0].id, "Import must remap a colliding profile ID.").toBeTruthy();
    const migrated = mergeImportedCharacterProfiles([], {
      format: exported.format,
      version: 1,
      profiles: [{ id: "legacy", name: "Legacy", statOverrides: { minPhys: 99 }, attunementOverrides: {} }],
    });
    expect(
      migrated.profiles[0].innerWays.length === 4 &&
        !("breakthrough" in migrated.profiles[0]) &&
        !("food" in migrated.profiles[0]) &&
        !("divinecraft" in migrated.profiles[0]),
      "Version 1 profiles must discard transient and independent session controls.",
    ).toBeTruthy();
  });
});
