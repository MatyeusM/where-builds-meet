import { RotationPingField } from "./components/RotationPingField";
import resourceEventDefinitions from "../data/event.json";
import { PingInput } from "./components/PingInput";
import { DEFAULT_PING_MS, normalizePing, resolvePing } from "./calculations/combatDefaults";
import {
  lazy,
  Suspense,
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
  type ChangeEvent,
  type CSSProperties,
  type Dispatch,
  type SetStateAction,
} from "react";
import { type AttunementStats, type DamageBreakdown } from "./calculations/damage";
import { resolveAttunementStats, type AttunementOverrides } from "./calculations/attunementStats";
import { resolveSwitchValue } from "./calculations/dynamicValues";
import { UiIcon } from "./UiIcon";
import { buildTimelineDisplayEntries } from "./rotationDisplay";
import { nextStatPriorityMode, statPriorityDisplayRows, type StatPriorityMode } from "./statPriorityDisplay";
import { NoticeArea, FeatureLoadBoundary } from "./components/NoticeArea";
import { publishNotice, dismissNotice } from "./notices";
const loadBuildTab = () => import("./BuildTab");
const loadSimulationTab = () => import("./SimulationTab");
const BuildTab = lazy(loadBuildTab);
const SimulationTab = lazy(loadSimulationTab);
import { allStatDefinitions, emptyStats } from "./data/statDefinitions";
import {
  activeBuildStorageKey,
  armorSetDefinitions,
  attunementData,
  availableSetEntriesForTags,
  buildPresetInventory,
  buildEntryAvailableForPath,
  buildEntryIsTestPreset,
  buildListStorageKey,
  calculateEquippedGearEffects,
  defaultBuildPresets,
  loadBuildState,
  maxGearRoll,
  normalizeBuildSetup,
  normalizeBuildSetupOverrides,
  resolveBuildInventory,
  resolveBuildSetup,
  sameWeaponPair,
  selectSetTier,
  serializeBuildState,
  setAvailableForTags,
  setSelectionChangesTimeline,
  statRollsForLevel,
  weaponSetDefinitions,
  type BuildSetup,
  type BuildSetupOverrides,
  type BuildState,
  type SetDefinition,
  type SetSelections,
} from "./gear";
import {
  normalizeStoredWeaponIds,
  weaponIds as allWeaponIds,
  type CharacterStats,
  type EnemyProfile,
  type StatDefinition,
  type WeaponFamily,
  type WeaponId,
} from "./types";
import type { DerivedStats } from "./calculations/effectiveStats";
import { martialArtEffectsForRank, type MartialArtTalent } from "./data/martialArtTalents";
import snowpartingSkills from "../data/skill/snowparting-blade.json";
import phalanxbaneSkills from "../data/skill/phalanxbane-blade.json";
import thundercrySkills from "../data/skill/thundercry-blade.json";
import stormbreakerSkills from "../data/skill/stormbreaker-spear.json";
import heavenwillSkills from "../data/skill/heavenwill-gauntlets.json";
import skygraspSkills from "../data/skill/skygrasp-rope-dart.json";
import panaceaSkills from "../data/skill/panacea-fan.json";
import soulshadeSkills from "../data/skill/soulshade-umbrella.json";
import mysticSkills from "../data/skill/mystic.json";
import generalSkills from "../data/skill/general.json";
import infernalSkills from "../data/skill/infernal-twinblades.json";
import mortalSkills from "../data/skill/mortal-rope-dart.json";
import mysticBuffs from "../data/buff/mystic.json";
import generalBuffs from "../data/buff/general.json";
import stonesplitStrengthBuffs from "../data/buff/stonesplit-strength.json";
import stonesplitMightBuffs from "../data/buff/stonesplit-might.json";
import bamboocutWindBuffs from "../data/buff/bamboocut-wind.json";
import bamboocutDraughtBuffs from "../data/buff/bamboocut-draught.json";
import bamboocutKiteBuffs from "../data/buff/bamboocut-kite.json";
import silkbindDelugeBuffs from "../data/buff/silkbind-deluge.json";
import bellstrikeUmbraBuffs from "../data/buff/bellstrike-umbra.json";
import mysticDebuffs from "../data/debuff/mystic.json";
import stonesplitStrengthDebuffs from "../data/debuff/stonesplit-strength.json";
import generalDebuffs from "../data/debuff/general.json";
import bellstrikeSplendorDebuffs from "../data/debuff/bellstrike-splendor.json";
import bellstrikeUmbraDebuffs from "../data/debuff/bellstrike-umbra.json";
import innerWayDebuffs from "../data/debuff/innerway.json";
import bamboocutDustDebuffs from "../data/debuff/bamboocut-dust.json";
import bamboocutWindDebuffs from "../data/debuff/bamboocut-wind.json";
import bamboocutKiteDebuffs from "../data/debuff/bamboocut-kite.json";
import stonesplitMightDebuffs from "../data/debuff/stonesplit-might.json";
import mysticDots from "../data/dot/mystic.json";
import innerWayDots from "../data/dot/innerway.json";
import breakthroughProfiles from "../data/breakthrough.json";
import systemStats from "../data/system.json";
import { createBaseAttributeEffects, type BaseAttributeData } from "./data/baseAttributeEffects";
import {
  innerWayAvailableForTag,
  innerWayDefinitions,
  innerWayEntriesForTag,
  innerWayDefinitionForSoloLevel,
} from "./data/innerWayDefinitions";
import defaultSetup from "../data/default-setup.json";
import {
  beginRotationCalculation,
  completeRotationCalculationCategory,
  emptyRotationBreakdown,
  endRotationCalculation,
  getRotationCalculationStatus,
  getRotationMetrics,
  publishRotationCategoryProgress,
  publishRotationMetrics,
  rotationCalculationCategories,
  subscribeToRotationCalculationStatus,
  subscribeToRotationMetrics,
  type RotationCalculationCategory,
  type RotationEffectCoverage,
  type RotationGroupBreakdown,
  type RotationHealingGroupBreakdown,
  type RotationMetrics,
  type RotationPriority,
} from "./calculations/rotationMetrics";
import arsenalDefinitions from "../data/arsenal.json";
import bowRingSetDefinitions from "../data/bow-ring-set.json";
import foodDefinitions from "../data/food.json";
import divinecraftDefinitions from "../data/divinecraft.json";
import scriptDefinitions from "../data/script.json";
import pathDefinitions from "../data/path.json";
import snowpartingMartialArt from "../data/martial-art/snowparting-blade.json";
import phalanxbaneMartialArt from "../data/martial-art/phalanxbane-blade.json";
import everspringMartialArt from "../data/martial-art/everspring-umbrella.json";
import unfetteredMartialArt from "../data/martial-art/unfettered-rope-dart.json";
import heavenwillMartialArt from "../data/martial-art/heavenwill-gauntlets.json";
import skygraspMartialArt from "../data/martial-art/skygrasp-rope-dart.json";
import thundercryMartialArt from "../data/martial-art/thundercry-blade.json";
import stormbreakerMartialArt from "../data/martial-art/stormbreaker-spear.json";
import namelessSwordMartialArt from "../data/martial-art/nameless-sword.json";
import namelessSpearMartialArt from "../data/martial-art/nameless-spear.json";
import strategicSwordMartialArt from "../data/martial-art/strategic-sword.json";
import heavenquakerSpearMartialArt from "../data/martial-art/heavenquaker-spear.json";
import vernalUmbrellaMartialArt from "../data/martial-art/vernal-umbrella.json";
import inkwellFanMartialArt from "../data/martial-art/inkwell-fan.json";
import panaceaFanMartialArt from "../data/martial-art/panacea-fan.json";
import soulshadeUmbrellaMartialArt from "../data/martial-art/soulshade-umbrella.json";
import infernalTwinbladesMartialArt from "../data/martial-art/infernal-twinblades.json";
import mortalRopeDartMartialArt from "../data/martial-art/mortal-rope-dart.json";
import skystrikeGauntletsMartialArt from "../data/martial-art/skystrike-gauntlets.json";
import rivenTwinbladesMartialArt from "../data/martial-art/riven-twinblades.json";
import {
  sortAttunementPriorityRows,
  sortRotationPriorityRows,
  type RotationActionBreakdown,
  type RotationSimulationBundle,
  type RotationSimulationResult,
  type RotationSimulationVariant,
} from "./calculations/rotationCalculator";
import {
  requestRotationBaseline,
  requestEditorTimeline,
  requestRotationComparisons,
  supersedeRotationCalculationRequests,
} from "./calculations/rotationWorkerClient";
import {
  pendingEditorTimeline,
  withUnresolvedEditorSteps,
  sameEditorRevision,
  type EditorRevision,
} from "./editorTimelinePreview";
import type { EditorTimelineResult } from "./calculations/editorTimeline";
import {
  RotationCalculationCache,
  calculationFingerprint,
  rotationBundleFingerprint,
  rotationVariantFingerprint,
} from "./calculations/rotationCalculationCache";
import {
  buildRotationTimeline,
  compareTimelineTime,
  isAttachmentAnchorStep,
  mergeEffectDefinition,
  mergeCalculatedTimelineState,
  type AttachedEventTarget,
  type EditableObject,
  type EffectDefinition,
  type InnerWayEffectRule,
  type RotationRecord,
  type RotationStep,
  type SkillRecord,
  type TimelineBuildInput,
  type TimelineRow,
} from "./calculations/rotationTimeline";
import {
  resolveSkillCalculationDefinitions,
  deserializeSkillOverrides,
  serializeSkillOverrides,
  type EditorCategory,
  type SkillCategory,
  type SkillMap,
  type SkillOverrides,
} from "./skillOverrides";
import { setupSelectionChangesTimeline } from "./data/scriptDefinitions";
import {
  calculateStatsWithOverrides,
  requirementIsUnconditional,
  type CharacterStatOverrides,
  type EffectiveStatEffectContainer,
  type StatEffectContainer,
} from "./calculations/statEffects";
import {
  exportRotationEntries,
  mergeImportedRotationEntries,
  serializeRotationEntries,
  type RotationEntry,
} from "./rotationTransfer";
import { readableRotationText } from "./readableRotation";
import { resolvePathWorkspaceSelection } from "./pathWorkspace";
import {
  attachedEventPhase,
  attachedEventSiblingIndex,
  attachedTargetForStep,
  isAutomaticDelay,
  migrateDrunkenPoetSequences,
  migrateAutomaticDelays,
  migrateDefenseActionAnchors,
  migrateGeneralsBaneSlides,
  reorderAttachedEventWithinTarget,
} from "./rotationEditing";
import {
  characterProfileMatches,
  characterProfileStorageKey,
  exportCharacterProfiles,
  loadCharacterProfiles,
  mergeImportedCharacterProfiles,
  serializeCharacterProfiles,
  type CharacterProfile,
} from "./characterProfiles";
import {
  globalDebuffRows,
  globalDebuffStorageKey,
  globalBuffTimelineEffects,
  globalDebuffTimelineEffects,
  loadGlobalDebuffs,
  type GlobalDebuffState,
} from "./globalDebuffs";
import {
  developmentModeStorageKey as devModeStorageKey,
  dataText,
  gameText,
  getLocale,
  getLocaleDisplayName,
  getSupportedLocales,
  isLocaleWip,
  selectLocale,
  t,
} from "./i18n";
import { getPersistentItem, removePersistentItem, setPersistentItem } from "./persistentStorage";

const storageKey = "wwm-character-stats-v3";
const legacyStorageKey = "wwm-character-stats-v2";
const statOverrideStorageKey = "wwm-stat-overrides-v1";
const skillStorageKey = "wwm-skill-editor-session-v1";
const layoutPreviewStorageKey = "wwm-layout-preview-session-v1";
const legacyInnerWayStorageKey = "wwm-inner-way-session-v1";
const attunementStorageKey = "wwm-attunement-session-v2";
const legacyAttunementStorageKey = "wwm-attunement-session-v1";
const attunementOverrideStorageKey = "wwm-attunement-overrides-v1";
const settingsStorageKey = "wwm-settings-session-v1";
const arsenalStorageKey = "wwm-arsenal-session-v1";
const bowRingSetStorageKey = "wwm-bow-ring-set-session-v1";
const gearSetStorageKey = "wwm-gear-set-session-v1";
const foodStorageKey = "wwm-food-session-v1";
const divinecraftStorageKey = "wwm-divinecraft-session-v1";
const scriptStorageKey = "wwm-script-session-v1";
const pathStorageKey = "wwm-path-session-v1";
const buildSetupOverrideStorageKey = "wwm-build-setup-overrides-v1";
const percentageStatKeys = new Set<keyof CharacterStats>(
  allStatDefinitions.filter(({ unit }) => unit === "%").map(({ key }) => key),
);
const statDefinitionByKey = new Map<keyof CharacterStats, StatDefinition>(
  allStatDefinitions.map((definition) => [definition.key, definition]),
);

function statDefinition(key: keyof CharacterStats) {
  const definition = statDefinitionByKey.get(key);
  if (!definition) throw new Error(`Missing stat definition for ${key}.`);
  return definition;
}

type CalculatorSettings = { weapons: [WeaponId, WeaponId]; breakthrough: string; ping: number };
type LayoutMode = "pc" | "mobile";
type PathId =
  | "mixed"
  | "bellstrikeSplendor"
  | "bellstrikeUmbra"
  | "stonesplitStrength"
  | "stonesplitMight"
  | "silkbindJade"
  | "silkbindDeluge"
  | "bamboocutWind"
  | "bamboocutKite"
  | "bamboocutDust"
  | "bamboocutDraught";
type PathDefinition = {
  name: string;
  icon?: string;
  tag?: string;
  status: "available" | "wip" | "devOnly" | "plannerOnly";
  buildGroup: string;
  defaultBuild: string;
  graduated: string;
  defaultRotation: string;
  lockedWeapons?: [WeaponId, WeaponId];
};
type DefaultSetup = {
  innerWays: Array<{ innerWay: string; tier: string }>;
  weaponSets: SetSelections;
  armorSets: SetSelections;
  bowRingSet: string;
  arsenal: string;
  food: string;
  divinecraft: string;
};
const typedDefaultSetup = defaultSetup as DefaultSetup;
const typedPathDefinitions = pathDefinitions as Record<PathId, PathDefinition>;

function defaultBuildIdForPath(pathId: PathId) {
  return typedPathDefinitions[pathId].defaultBuild;
}

function defaultRotationIdForPath(pathId: PathId) {
  return typedPathDefinitions[pathId].defaultRotation;
}
const productionWeaponIds = new Set<WeaponId>(
  (Object.entries(typedPathDefinitions) as Array<[PathId, PathDefinition]>).flatMap(([id, definition]) =>
    id !== "mixed" && definition.status === "available" ? (definition.lockedWeapons ?? []) : [],
  ),
);

function pathRequiresDev(definition: PathDefinition) {
  return definition.status !== "available";
}

function pathStatusLabel(definition: PathDefinition) {
  switch (definition.status) {
    case "plannerOnly":
      return t("ui.app.plannerOnly");
    case "devOnly":
      return t("ui.app.dev");
    case "wip":
      return t("ui.app.wip");
    case "available":
      return "";
  }
}

const defaultSkillMaps: Record<SkillCategory, SkillMap> = {
  Snowparting: snowpartingSkills as SkillMap,
  Phalanxbane: phalanxbaneSkills as SkillMap,
  Thundercry: thundercrySkills as SkillMap,
  Stormbreaker: stormbreakerSkills as SkillMap,
  Heavenwill: heavenwillSkills as SkillMap,
  Skygrasp: skygraspSkills as SkillMap,
  Panacea: panaceaSkills as SkillMap,
  Soulshade: soulshadeSkills as SkillMap,
  Infernal: infernalSkills as SkillMap,
  Mortal: mortalSkills as SkillMap,
  Mystic: mysticSkills as SkillMap,
  General: generalSkills as SkillMap,
};
const manualMysticBuffs = Object.fromEntries(
  Object.entries(mysticBuffs as Record<string, EffectDefinition>).filter(([, definition]) => !definition.global),
);
const defaultEditorMaps: Record<EditorCategory, SkillMap> = {
  ...defaultSkillMaps,
  Buff: {
    ...manualMysticBuffs,
    ...generalBuffs,
    ...stonesplitStrengthBuffs,
    ...stonesplitMightBuffs,
    ...bamboocutWindBuffs,
    ...bamboocutDraughtBuffs,
    ...bamboocutKiteBuffs,
    ...silkbindDelugeBuffs,
    ...bellstrikeUmbraBuffs,
  } as SkillMap,
  Debuff: {
    ...stonesplitStrengthDebuffs,
    ...stonesplitMightDebuffs,
    ...bellstrikeSplendorDebuffs,
    ...bellstrikeUmbraDebuffs,
    ...bamboocutDustDebuffs,
    ...bamboocutWindDebuffs,
    ...bamboocutKiteDebuffs,
    ...innerWayDebuffs,
    ...generalDebuffs,
  } as SkillMap,
  DOT: { ...mysticDots, ...innerWayDots } as SkillMap,
};
const skillCategoryByWeapon: Partial<Record<WeaponId, SkillCategory>> = {
  snowparting: "Snowparting",
  phalanxbane: "Phalanxbane",
  thundercry: "Thundercry",
  stormbreaker: "Stormbreaker",
  heavenwill: "Heavenwill",
  skygrasp: "Skygrasp",
  panaceaFan: "Panacea",
  soulshadeUmbrella: "Soulshade",
  infernalTwinblades: "Infernal",
  mortalRopeDart: "Mortal",
};
const rotationEventDefinitions: Record<string, SkillRecord> = {
  ...resourceEventDefinitions,
  Controlled: {
    name: "Event: Controlled",
    castTime: 0,
    action: [{ type: "apply", target: "target", value: "Controlled", stack: 1, time: 0 }],
    modifier: [],
    tags: ["Event"],
  },
  MartialArt: {
    name: "Event: Switch Martial Art",
    castTime: 0,
    action: [{ type: "switchMartialArt", time: 0 }],
    modifier: [],
    tags: ["Event"],
  },
  ShieldBroken: {
    name: "Event: Shield Broken",
    castTime: 0,
    action: [
      { type: "consume", target: "self", value: "Shield", stack: "all", time: 0 },
      {
        type: "apply",
        target: "self",
        value: "HardenedFoe",
        stack: 1,
        requirement: [{ target: "self", value: "ArtOfResistanceT6" }],
        time: 0,
      },
    ],
    modifier: [],
    tags: ["Event"],
  },
  BattleEnd: {
    name: "Event: Battle End",
    castTime: 0,
    action: [],
    modifier: [],
    tags: ["Event"],
  },
  Delay: {
    name: "Event: Delay",
    castTime: 0,
    action: [],
    modifier: [],
    tags: ["Event"],
  },
  Move: {
    name: "Event: Move",
    castTime: 0,
    action: [{ type: "move", time: 0 }],
    modifier: [],
    tags: ["Event"],
  },
  SelfHP: {
    name: "Event: Self HP",
    castTime: 0,
    action: [{ type: "setHP", time: 0 }],
    modifier: [],
    tags: ["Event"],
  },
  TakeDamage: {
    name: "Event: Take Damage",
    castTime: 0,
    action: [{ type: "takeDamage", time: 0 }],
    modifier: [],
    tags: ["Event"],
  },
  HP: {
    name: "Event: HP",
    castTime: 0,
    action: [{ type: "setTargetHP", time: 0 }],
    modifier: [],
    tags: ["Event"],
  },
  Qi: {
    name: "Event: Qi",
    castTime: 0,
    action: [
      { type: "setQi", time: 0 },
      {
        type: "apply",
        target: "target",
        value: "Exhausted",
        stack: 1,
        requirement: [{ target: "resource", value: "Qi", comparison: "==", amount: 0 }],
        time: 0,
      },
    ],
    modifier: [],
    tags: ["Event"],
  },
  Buff: {
    name: "Event: Buff",
    castTime: 0,
    action: [{ type: "apply", target: "self", time: 0 }],
    modifier: [],
    tags: ["Event"],
  },
  Debuff: {
    name: "Event: Debuff",
    castTime: 0,
    action: [{ type: "apply", target: "target", time: 0 }],
    modifier: [],
    tags: ["Event"],
  },
};

function rotationEventDisplayName(eventId: string) {
  const key = `${eventId.charAt(0).toLowerCase()}${eventId.slice(1)}`;
  return dataText(`game.event.${key}`, rotationEventDefinitions[eventId]?.name ?? eventId);
}

const rotationStorageKey = "wwm-rotation-editor-session-v2";
const rotationListStorageKey = "wwm-rotation-list-session-v1";
const activeRotationStorageKey = "wwm-active-rotation-session-v1";
const activeRotationByPathStorageKey = "wwm-active-rotation-by-path-v1";
const activeBuildByPathStorageKey = "wwm-active-build-by-path-v1";

type PathSelectionIds = Partial<Record<PathId, string>>;

function loadPathSelectionIds(storageKey: string, legacyStorageKey: string, currentPathId: PathId) {
  let selections: PathSelectionIds = {};
  try {
    const saved = JSON.parse(getPersistentItem(storageKey) ?? "null") as unknown;
    if (saved && typeof saved === "object" && !Array.isArray(saved)) {
      selections = Object.fromEntries(
        Object.entries(saved).filter(
          ([path, id]) => path in typedPathDefinitions && typeof id === "string" && id.length > 0,
        ),
      ) as PathSelectionIds;
    }
  } catch {
    selections = {};
  }
  if (!selections[currentPathId]) {
    const legacyId = getPersistentItem(legacyStorageKey);
    if (legacyId) {
      selections = { ...selections, [currentPathId]: legacyId };
      setPersistentItem(storageKey, JSON.stringify(selections));
    }
  }
  return selections;
}

function withPathSelection(selections: PathSelectionIds, pathId: PathId, id: string) {
  return selections[pathId] === id ? selections : { ...selections, [pathId]: id };
}
const allSkillDefinitions = Object.assign({}, ...Object.values(defaultSkillMaps)) as SkillMap;
const skillDataNamespaceByCategory: Record<SkillCategory, string> = {
  Snowparting: "snowpartingBlade",
  Phalanxbane: "phalanxbaneBlade",
  Thundercry: "thundercryBlade",
  Stormbreaker: "stormbreakerSpear",
  Heavenwill: "heavenwillGauntlets",
  Skygrasp: "skygraspRopeDart",
  Panacea: "panaceaFan",
  Soulshade: "soulshadeUmbrella",
  Infernal: "infernalTwinblades",
  Mortal: "mortalRopeDart",
  Mystic: "mystic",
  General: "general",
};
const skillDataNamespaceById = new Map<string, string>(
  (Object.entries(defaultSkillMaps) as Array<[SkillCategory, SkillMap]>).flatMap(([category, definitions]) =>
    Object.keys(definitions).map((id) => [id, skillDataNamespaceByCategory[category]]),
  ),
);
const allSkillIds = (Object.keys(defaultSkillMaps) as SkillCategory[]).flatMap((category) =>
  Object.keys(defaultSkillMaps[category]),
);
const editorSkillIds = Array.from(new Set(allSkillIds));
const martialArtBySkillId = new Map<string, WeaponId>([
  ...Object.keys(snowpartingSkills).map((id) => [id, "snowparting"] as const),
  ...Object.keys(phalanxbaneSkills).map((id) => [id, "phalanxbane"] as const),
  ...Object.keys(thundercrySkills).map((id) => [id, "thundercry"] as const),
  ...Object.keys(stormbreakerSkills).map((id) => [id, "stormbreaker"] as const),
  ...Object.keys(heavenwillSkills).map((id) => [id, "heavenwill"] as const),
  ...Object.keys(skygraspSkills).map((id) => [id, "skygrasp"] as const),
  ...Object.keys(panaceaSkills).map((id) => [id, "panaceaFan"] as const),
  ...Object.keys(soulshadeSkills).map((id) => [id, "soulshadeUmbrella"] as const),
]);
const rotationEventOptionIds = [
  "__event:Delay",
  "__event:Controlled",
  "__event:ShieldBroken",
  "__event:BattleEnd",
  "__event:Move",
  "__event:SelfHP",
  "__event:TakeDamage",
  "__event:Hellfire",
  "__event:HP",
  "__event:Qi",
  "__event:Buff",
  "__event:Debuff",
  "__event:MartialArt",
];
const dotDefinitions = { ...mysticDots, ...innerWayDots } as Record<string, SkillRecord>;
const generalDebuffIds = new Set(Object.keys(generalDebuffs));
const dotEffectIds = new Set(Object.keys(dotDefinitions));
const effectDefinitions = {
  ...mysticBuffs,
  ...generalBuffs,
  ...stonesplitStrengthBuffs,
  ...stonesplitMightBuffs,
  ...bamboocutWindBuffs,
  ...bamboocutDraughtBuffs,
  ...bamboocutKiteBuffs,
  ...silkbindDelugeBuffs,
  ...bellstrikeUmbraBuffs,
  ...mysticDebuffs,
  ...stonesplitStrengthDebuffs,
  ...stonesplitMightDebuffs,
  ...bellstrikeSplendorDebuffs,
  ...bellstrikeUmbraDebuffs,
  ...bamboocutDustDebuffs,
  ...bamboocutWindDebuffs,
  ...bamboocutKiteDebuffs,
  ...innerWayDebuffs,
  ...generalDebuffs,
  ...dotDefinitions,
} as Record<string, EffectDefinition>;
const expectedOutcomeBuffPlateDefinitions = [
  { name: "Hawkwing", maxStack: 5 },
  { name: "Concentration", maxStack: 1 },
  { name: "Bloom", maxStack: 1 },
  { name: "Flare", maxStack: 1 },
  { name: "Yield", maxStack: 1 },
  { name: "Frost", maxStack: 1 },
] as const;
const expectedOutcomeBuffPlateNames = new Set<string>(expectedOutcomeBuffPlateDefinitions.map(({ name }) => name));
type DisplayedTimelineEffect = TimelineRow["buffs"][number] & {
  hideRemainingTime?: boolean;
  averageStackOnly?: boolean;
};
function withExpectedOutcomeBuffPlates(
  buffs: TimelineRow["buffs"],
  expectedBuffStacks: Record<string, number> | undefined,
): DisplayedTimelineEffect[] {
  if (!expectedBuffStacks) return buffs;
  return [
    ...buffs.filter((effect) => !expectedOutcomeBuffPlateNames.has(effect.name)),
    ...expectedOutcomeBuffPlateDefinitions.flatMap(({ name, maxStack }) => {
      const stack = expectedBuffStacks[name];
      return stack !== undefined && stack > 0
        ? [
            {
              name,
              stack,
              maxStack,
              hideRemainingTime: true,
              averageStackOnly: true,
            },
          ]
        : [];
    }),
  ];
}

function formatResourceRange(value: number, range: { minimum: number; maximum: number } | undefined) {
  if (!range || Math.abs(range.maximum - range.minimum) < 1e-9) return formatNumber(value);
  return `${formatNumber(range.minimum)} ~ ${formatNumber(range.maximum)}`;
}
const globalEffectRules = Object.values(effectDefinitions).flatMap((definition) =>
  definition.global ? (definition.effect ?? []) : [],
) as EditableObject[];
const manualBuffDefinitions = {
  ...manualMysticBuffs,
  ...generalBuffs,
  ...stonesplitStrengthBuffs,
  ...stonesplitMightBuffs,
  ...bamboocutWindBuffs,
  ...bamboocutDraughtBuffs,
  ...bamboocutKiteBuffs,
  ...silkbindDelugeBuffs,
  ...bellstrikeUmbraBuffs,
} as Record<string, { name?: string }>;
const manualGeneralDebuffs = Object.fromEntries(Object.entries(generalDebuffs).filter(([id]) => id !== "Exhausted"));
const manualDebuffDefinitions = {
  ...mysticDebuffs,
  ...stonesplitStrengthDebuffs,
  ...stonesplitMightDebuffs,
  ...bellstrikeSplendorDebuffs,
  ...bellstrikeUmbraDebuffs,
  ...bamboocutDustDebuffs,
  ...bamboocutWindDebuffs,
  ...bamboocutKiteDebuffs,
  ...innerWayDebuffs,
  ...manualGeneralDebuffs,
} as Record<string, { name?: string }>;

function loadDevMode() {
  return localStorage.getItem(devModeStorageKey) === "true";
}

const compactLayoutQuery = "(max-width: 48em)";

function subscribeToCompactLayout(callback: () => void) {
  const query = window.matchMedia(compactLayoutQuery);
  query.addEventListener("change", callback);
  return () => query.removeEventListener("change", callback);
}

function compactLayoutSnapshot() {
  return window.matchMedia(compactLayoutQuery).matches;
}

function loadLayoutPreview(compact: boolean): LayoutMode {
  const saved = getPersistentItem(layoutPreviewStorageKey);
  return saved === "pc" || saved === "mobile" ? saved : compact ? "mobile" : "pc";
}

function loadSelectedPath(devMode = loadDevMode()): PathId {
  const saved = getPersistentItem(pathStorageKey);
  const definition = saved ? typedPathDefinitions[saved as PathId] : undefined;
  return definition && (!pathRequiresDev(definition) || devMode) ? (saved as PathId) : "stonesplitStrength";
}

function innerWayAvailableForPath(innerWay: string, pathId = loadSelectedPath()) {
  return innerWayAvailableForTag(innerWay, typedPathDefinitions[pathId].tag);
}

function attunementAvailableForSettings(attunement: string, pathId: PathId, settings: CalculatorSettings) {
  const definition = attunementData[attunement];
  if (definition?.tags.includes("Defensive")) return false;
  if (definition?.tags.includes("Weapon")) return true;
  const requiredTag = typedPathDefinitions[pathId].tag;
  if (requiredTag && !definition?.tags.includes(requiredTag)) return false;
  return settings.weapons.some((weapon) => definition?.tags.includes(martialArtDefinitions[weapon].tag));
}

function settingsForPath(settings: CalculatorSettings, pathId: PathId): CalculatorSettings {
  const lockedWeapons = typedPathDefinitions[pathId].lockedWeapons;
  return lockedWeapons ? { ...settings, weapons: [...lockedWeapons] } : settings;
}

function selectableRotationSkillIds(weapons: [WeaponId, WeaponId]) {
  const martialCategories = weapons.flatMap((weapon) => {
    const category = skillCategoryByWeapon[weapon];
    return category ? [category] : [];
  });
  const categories = [...new Set<SkillCategory>([...martialCategories, "Mystic", "General"])] as SkillCategory[];
  return categories
    .flatMap((category) => Object.keys(defaultSkillMaps[category]))
    .filter(
      (skillId) => !allSkillDefinitions[skillId]?.tags?.some((tag) => tag === "Triggered" || tag === "SubAction"),
    );
}

function innerWayConditionsFor(
  selectedInnerWays: BuildSetup["innerWays"],
  excludedInnerWay?: string,
  pathId = loadSelectedPath(),
) {
  const conditions = new Set<string>();
  for (const row of selectedInnerWays) {
    if (!row.innerWay || row.innerWay === excludedInnerWay || !innerWayAvailableForPath(row.innerWay, pathId)) continue;
    const tierNumber = Number(row.tier.slice(1));
    for (let tier = 0; tier <= tierNumber; tier += 1) conditions.add(`${row.innerWay}T${tier}`);
  }
  return conditions;
}

function innerWayEffectRulesFor(
  selectedInnerWays: BuildSetup["innerWays"],
  soloLevel: number,
  pathId = loadSelectedPath(),
): InnerWayEffectRule[] {
  const selected = selectedInnerWays.filter(({ innerWay }) => innerWayAvailableForPath(innerWay, pathId));
  return selected.flatMap(({ innerWay, tier }) => {
    if (!innerWay || !innerWayDefinitions[innerWay as keyof typeof innerWayDefinitions]) return [];
    const definition = innerWayDefinitionForSoloLevel(
      innerWayDefinitions[innerWay as keyof typeof innerWayDefinitions],
      soloLevel,
    ) as {
      effect?: Record<string, { effect?: unknown[]; trigger?: unknown[]; listen?: unknown[] }>;
    };
    const tierNumber = Number(tier.slice(1));
    return Array.from({ length: tierNumber + 1 }, (_, currentTier) => {
      const tierDefinition = definition.effect?.[`${innerWay}T${currentTier}`];
      const effects = tierDefinition?.effect ?? [];
      const triggers = tierDefinition?.trigger ?? [];
      const listeners = tierDefinition?.listen ?? [];
      const effectRules = effects
        .filter((item): item is EditableObject => Boolean(item) && typeof item === "object" && !Array.isArray(item))
        .map((item) => ({
          requirement: item.requirement,
          trigger:
            item.trigger && typeof item.trigger === "object" && !Array.isArray(item.trigger)
              ? (item.trigger as EditableObject)
              : undefined,
          target: typeof item.target === "string" ? item.target : undefined,
          modify:
            item.modify && typeof item.modify === "object" && !Array.isArray(item.modify)
              ? (item.modify as EditableObject)
              : undefined,
          effect:
            item.effect && typeof item.effect === "object" && !Array.isArray(item.effect)
              ? (item.effect as EditableObject)
              : Object.fromEntries(
                  ["rawStat", "stat", "effectiveStat"].flatMap((field) =>
                    item[field] && typeof item[field] === "object" && !Array.isArray(item[field])
                      ? [[field, item[field]]]
                      : [],
                  ),
                ),
          source: innerWay,
          tier: currentTier,
        }));
      const triggerRules = triggers
        .filter((item): item is EditableObject => Boolean(item) && typeof item === "object" && !Array.isArray(item))
        .map((item) => ({
          requirement: item.requirement,
          trigger: {
            ...item,
            target: typeof item.target === "string" ? item.target : "self",
            action: Array.isArray(item.action) ? item.action : [],
          },
          effect: {},
          source: innerWay,
          tier: currentTier,
        }));
      const listenerRules = listeners
        .filter((item): item is EditableObject => Boolean(item) && typeof item === "object" && !Array.isArray(item))
        .map((item) => ({
          requirement: item.requirement,
          listen: item,
          effect: {},
          source: innerWay,
          tier: currentTier,
        }));
      return [...effectRules, ...triggerRules, ...listenerRules];
    }).flat();
  });
}

function normalizeRotation(rotation: RotationRecord): RotationRecord {
  const autoHP = rotation.autoHP === true;
  const expandedSteps: RotationStep[] = (rotation.steps as Array<RotationStep & { repeat?: number }>).flatMap(
    (step): RotationStep[] => {
      if (step.type === "event") return [step];
      const repeat = Math.max(1, step.repeat ?? 1);
      const { repeat: _repeat, ...stepWithoutRepeat } = step;
      return Array.from({ length: repeat }, (_, index) => ({
        ...stepWithoutRepeat,
        causesBreak: index === repeat - 1 ? step.causesBreak : undefined,
      })) as RotationStep[];
    },
  );
  const steps = autoHP ? expandedSteps.filter((step) => step.type !== "event" || step.event !== "HP") : expandedSteps;
  const start = rotation.start
    ? {
        ...rotation.start,
        step: Math.max(
          0,
          rotation.start.step -
            (autoHP
              ? expandedSteps
                  .slice(0, rotation.start.step)
                  .filter((step) => step.type === "event" && step.event === "HP").length
              : 0),
        ),
      }
    : undefined;
  return {
    name: rotation.name,
    steps,
    ...(typeof rotation.targetHP === "number" && rotation.targetHP > 0 ? { targetHP: rotation.targetHP } : {}),
    ...(autoHP ? { autoHP: true } : {}),
    ...(rotation.dummyAttack === true ? { dummyAttack: true } : {}),
    ...(normalizePing(rotation.ping) !== undefined ? { ping: normalizePing(rotation.ping) } : {}),
    groupSize: rotation.groupSize === 5 || rotation.groupSize === 10 ? rotation.groupSize : 1,
    infiniteVitality:
      typeof rotation.infiniteVitality === "boolean"
        ? rotation.infiniteVitality
        : /\bIV\b|infinite vitality/i.test(rotation.name),
    start,
    ...(rotation.eventTimeReference === "battleStart" ? { eventTimeReference: "battleStart" as const } : {}),
  };
}

function eventDefaultDuration(event: "Exhausted" | "Controlled") {
  return effectDefinitions[event]?.duration ?? 0;
}

function baseSkillCastTime(skill: SkillRecord | undefined) {
  if (typeof skill?.castTime === "number" && Number.isFinite(skill.castTime)) return skill.castTime;
  const fallback = resolveSwitchValue(skill?.castTime, {});
  return typeof fallback === "number" && Number.isFinite(fallback) ? fallback : 0;
}

function baseRotationAnchorTime(rotation: RotationRecord) {
  if (!rotation.start) return 0;
  let time = 0;
  for (const [stepIndex, step] of rotation.steps.entries()) {
    if (stepIndex === rotation.start.step) {
      if (step.type !== "skill") return time;
      const skill = allSkillDefinitions[step.skill ?? ""];
      return (
        time +
        (rotation.start.action === undefined || !Array.isArray(skill?.action)
          ? 0
          : Number((skill.action[rotation.start.action] as EditableObject | undefined)?.time ?? 0))
      );
    }
    if (step.type === "skill") time += baseSkillCastTime(allSkillDefinitions[step.skill ?? ""]);
    else if (step.event === "Delay") time += Math.max(0, step.duration);
  }
  return 0;
}

function baseAttachedEventTime(rotation: RotationRecord, eventStepIndex: number, target: AttachedEventTarget) {
  let elapsed = 0;
  for (const [stepIndex, step] of rotation.steps.entries()) {
    if (step.type === "skill") {
      const skill = allSkillDefinitions[step.skill ?? ""];
      if (stepIndex > eventStepIndex) {
        if (target.action === "start") return elapsed;
        const actions = Array.isArray(skill?.action) ? (skill.action as EditableObject[]) : [];
        if (target.trigger === undefined) return elapsed + Number(actions[target.action]?.time ?? 0);
        const triggerAction = actions.filter((action) => action.type === "trigger")[target.trigger];
        if (!triggerAction || typeof triggerAction.value !== "string") return elapsed;
        const triggeredSkill = allSkillDefinitions[triggerAction.value];
        const triggeredActions = Array.isArray(triggeredSkill?.action)
          ? (triggeredSkill.action as EditableObject[])
          : [];
        return elapsed + Number(triggerAction.time ?? 0) + Number(triggeredActions[target.action]?.time ?? 0);
      }
      elapsed += baseSkillCastTime(skill);
    } else if (step.event === "Delay") {
      elapsed += Math.max(0, step.duration);
    }
  }
  return elapsed;
}

function timelineAnchorTime(timeline: TimelineRow[], startAnchor: { rowId: string; actionIndex?: number }) {
  const anchorRow = timeline.find((row) => row.id === startAnchor.rowId);
  if (!anchorRow) return 0;
  if (startAnchor.actionIndex === undefined) return anchorRow.startTime;
  return anchorRow.startTime + Number(anchorRow.actions[startAnchor.actionIndex]?.time ?? 0);
}

function migrateRotation(rotation: RotationRecord): RotationRecord {
  const migrated = migrateDefenseActionAnchors(
    migrateAutomaticDelays(migrateDrunkenPoetSequences(migrateGeneralsBaneSlides(normalizeRotation(rotation)))),
  );
  const attachedDamageIndexes = migrated.steps.flatMap((step, index) =>
    step.type === "event" && step.event === "TakeDamage" && "before" in step ? [index] : [],
  );
  const migrationTimeline = attachedDamageIndexes.length
    ? buildRotationTimeline({
        rotation: migrated,
        skills: allSkillDefinitions,
        eventDefinitions: rotationEventDefinitions,
        dots: dotDefinitions,
        effectDefinitions,
        innerWayConditions: [],
        innerWayRules: [],
        setupEffects: [],
        weapons: [],
      })
    : [];
  const anchorTime = migrationTimeline.length
    ? timelineAnchorTime(migrationTimeline, {
        rowId: `rotation-${migrated.start?.step ?? 0}`,
        actionIndex: migrated.start?.action,
      })
    : baseRotationAnchorTime(migrated);
  migrated.steps = migrated.steps.map((step, stepIndex) => {
    const legacyStep = step as unknown as Record<string, unknown>;
    if (step.type !== "event") return step;
    if (step.event === "TakeDamage" && "before" in step) {
      const targetTime =
        migrationTimeline.find((row) => row.id === `rotation-${stepIndex}`)?.startTime ??
        baseAttachedEventTime(migrated, stepIndex, step.before);
      return {
        type: "event",
        event: "TakeDamage",
        startTime: migrated.eventTimeReference === "battleStart" ? targetTime - anchorTime : targetTime,
        damage: step.damage,
      };
    }
    if (step.event === "HP" && typeof legacyStep.currentHPRatio === "number")
      return {
        type: "event",
        event: "SelfHP",
        before: legacyStep.before as AttachedEventTarget,
        currentHPRatio: legacyStep.currentHPRatio,
      };
    if (step.event === "Debuff" && step.debuff === "Exhausted")
      return { type: "event", event: "Qi", before: step.before, targetQiRatio: 0 };
    if (legacyStep.event === "Exhausted" && (legacyStep.after || legacyStep.before))
      return {
        type: "event",
        event: "Qi",
        after: (legacyStep.after ?? legacyStep.before) as AttachedEventTarget,
        targetQiRatio: 0,
      };
    return step;
  });
  if (migrated.eventTimeReference !== "battleStart") {
    const previousAnchorTime = baseRotationAnchorTime(migrated);
    migrated.steps = migrated.steps.map((step) =>
      step.type === "event" && "startTime" in step ? { ...step, startTime: step.startTime - previousAnchorTime } : step,
    );
    migrated.eventTimeReference = "battleStart";
  }
  const legacyEvents = migrated.steps.flatMap((step, index) =>
    step.type === "event" &&
    (step.event === "Move" || (step as unknown as { event: string }).event === "Exhausted") &&
    "startTime" in step
      ? [{ step, index }]
      : [],
  );
  if (legacyEvents.length) {
    const anchor = baseRotationAnchorTime(migrated);
    let elapsed = 0;
    const candidates = migrated.steps.flatMap((step, index) => {
      if (step.type !== "skill") return [];
      const skill = allSkillDefinitions[step.skill ?? ""];
      const castStart = elapsed;
      elapsed += baseSkillCastTime(skill);
      const actions = Array.isArray(skill?.action) ? (skill.action as EditableObject[]) : [];
      return [
        { index, time: castStart - anchor, before: { action: "start" } as AttachedEventTarget },
        ...actions.flatMap((action, actionIndex) => {
          const time = castStart + Number(action.time ?? 0) - anchor;
          const direct = { index, time, before: { action: actionIndex } as AttachedEventTarget };
          if (action.type !== "trigger" || typeof action.value !== "string") return [direct];
          const triggered = allSkillDefinitions[action.value];
          const triggeredActions = Array.isArray(triggered?.action) ? (triggered.action as EditableObject[]) : [];
          const triggerOrdinal =
            actions.slice(0, actionIndex + 1).filter((candidate) => candidate.type === "trigger").length - 1;
          return [
            direct,
            ...triggeredActions.map((triggeredAction, triggeredActionIndex) => ({
              index,
              time: time + Number(triggeredAction.time ?? 0),
              before: { trigger: triggerOrdinal, action: triggeredActionIndex } as AttachedEventTarget,
            })),
          ];
        }),
      ];
    });
    const attachments = new Map<number, RotationStep[]>();
    legacyEvents.forEach(({ step }) => {
      if (!candidates.length) return;
      const target = candidates.reduce(
        (best, candidate) =>
          Math.abs(candidate.time - step.startTime) < Math.abs(best.time - step.startTime) ? candidate : best,
        candidates[0],
      );
      if (!target) return;
      const attached =
        step.event === "Move"
          ? ({ type: "event", event: "Move", before: target.before, distance: step.distance } as RotationStep)
          : ({
              type: "event",
              event: "Qi",
              after: target.before,
              targetQiRatio: 0,
            } as RotationStep);
      attachments.set(target.index, [...(attachments.get(target.index) ?? []), attached]);
    });
    const startSkill = migrated.steps[migrated.start?.step ?? -1];
    migrated.steps = migrated.steps.flatMap((step, index) =>
      step.type === "event" &&
      (step.event === "Move" || (step as unknown as { event: string }).event === "Exhausted") &&
      "startTime" in step
        ? []
        : step.type === "skill"
          ? [...(attachments.get(index) ?? []), step]
          : [step],
    );
    const startStep = migrated.steps.indexOf(startSkill);
    if (startStep >= 0 && migrated.start) migrated.start = { ...migrated.start, step: startStep };
  }
  return migrated;
}

type RotationPresetRecord = RotationRecord & { martialArts?: WeaponId[]; test?: boolean };
const rotationPresetModules = import.meta.glob("../data/rotation/**/*.json", {
  eager: true,
  import: "default",
}) as Record<string, RotationPresetRecord>;
function rotationMartialArts(rotation: RotationRecord, explicit?: unknown) {
  const configured = normalizeStoredWeaponIds(explicit);
  if (configured.length) return configured;
  const inferred = [
    ...new Set(
      rotation.steps.flatMap((step) =>
        step.type === "skill" ? (martialArtBySkillId.get(step.skill ?? "") ?? []) : [],
      ),
    ),
  ];
  return inferred.length ? inferred : [...allWeaponIds];
}
function rotationAvailableForWeapons(entry: RotationEntry, weapons: [WeaponId, WeaponId]) {
  if (allWeaponIds.every((weapon) => entry.martialArts.includes(weapon))) return true;
  const selected = [...new Set(weapons)];
  const tagged = [...new Set(entry.martialArts)];
  return tagged.length === selected.length && selected.every((weapon) => tagged.includes(weapon));
}
const defaultRotationEntries = Object.entries(rotationPresetModules)
  .sort(
    ([leftPath, left], [rightPath, right]) =>
      Number(left.test === true) - Number(right.test === true) || leftPath.localeCompare(rightPath),
  )
  .map(([path, rotation]): RotationEntry => ({
    id:
      path
        .split("/")
        .pop()
        ?.replace(/\.json$/, "") ?? path,
    rotation: migrateRotation(rotation),
    martialArts: rotationMartialArts(rotation, rotation.martialArts),
    isDefault: true,
    test: rotation.test === true,
  }));
const defaultRotation = defaultRotationEntries[0]?.rotation ?? { name: "Default Rotation", steps: [] };
const defaultRotationId = defaultRotationEntries[0]?.id ?? "default-rotation";
const formerDefaultRotationIds = new Set(["dummy-1-min"]);

function rotationRecordForEntry(entry: RotationEntry) {
  if (!entry.isDefault) return entry.rotation;
  return defaultRotationEntries.find((preset) => preset.id === entry.id)?.rotation ?? entry.rotation;
}

type SetupEffect = StatEffectContainer &
  EffectiveStatEffectContainer & {
    condition?: string;
    requirement?: unknown;
    trigger?: EditableObject;
    buffDurationBonus?: number;
    target?: string;
    modify?: EditableObject;
  };
type BreakthroughProfile = EnemyProfile & {
  soloLevel: number;
  martialArtTalentRank: number;
  levelBonusStats: SetupEffect & {
    rawStat: {
      precision: number;
      agility: number;
      power: number;
      momentum: number;
      body: number;
      defense: number;
    };
  };
};
const typedBreakthroughProfiles = breakthroughProfiles as Record<string, BreakthroughProfile>;
const defaultBreakthrough = "17";
const defaultSettings: CalculatorSettings = {
  weapons: ["snowparting", "phalanxbane"],
  breakthrough: defaultBreakthrough,
  ping: DEFAULT_PING_MS,
};

function breakthroughProfile(settings: CalculatorSettings) {
  return typedBreakthroughProfiles[settings.breakthrough] ?? typedBreakthroughProfiles[defaultSettings.breakthrough];
}

type SystemStatsDefinition = {
  initialResources: Record<string, number>;
  resourceMaximums: Record<string, number>;
  resourceEvents: import("./calculations/rotationTimeline").ResourceEventRule[];
  baseStats: SetupEffect;
  enhancementStats: Array<SetupEffect & { id: string }>;
  talentStats: Array<SetupEffect & { id: string }>;
  qingheOddityStats: Array<SetupEffect & { id: string }>;
  kaifengOddityStats: Array<SetupEffect & { id: string }>;
  imperialPalaceOddityStats: Array<SetupEffect & { id: string }>;
  hexiOddityStats: Array<SetupEffect & { id: string }>;
  hiddenMountainOddityStats: Array<SetupEffect & { id: string }>;
  baseAttributes: BaseAttributeData;
};
const typedSystemStats = systemStats as SystemStatsDefinition;
const baseAttributeEffects = createBaseAttributeEffects(typedSystemStats.baseAttributes);
const systemStatEffects: SetupEffect[] = [
  typedSystemStats.baseStats,
  ...typedSystemStats.enhancementStats,
  ...typedSystemStats.talentStats,
  ...typedSystemStats.qingheOddityStats,
  ...typedSystemStats.kaifengOddityStats,
  ...typedSystemStats.imperialPalaceOddityStats,
  ...typedSystemStats.hexiOddityStats,
  ...typedSystemStats.hiddenMountainOddityStats,
  ...baseAttributeEffects,
];
type ArsenalDefinition = { name: string; effect?: SetupEffect };
const typedArsenalDefinitions = arsenalDefinitions as Record<string, ArsenalDefinition>;
const typedBowRingSetDefinitions = bowRingSetDefinitions as Record<string, ArsenalDefinition>;
type GearSetOption = { name: string; effect?: SetupEffect | SetupEffect[] };
type GearSetDefinition = Omit<SetDefinition, "options"> & { options: Record<string, GearSetOption> };
const typedWeaponSetDefinitions = weaponSetDefinitions as Record<string, GearSetDefinition>;
const typedArmorSetDefinitions = armorSetDefinitions as Record<string, GearSetDefinition>;
const typedFoodDefinitions = foodDefinitions as Record<string, ArsenalDefinition>;
type DivinecraftDefinition = ArsenalDefinition & {
  description: string;
  image?: string;
  available?: boolean;
  altersTimeline?: boolean;
};
const typedDivinecraftDefinitions = divinecraftDefinitions as Record<string, DivinecraftDefinition>;
type ScriptDefinition = ArsenalDefinition & { description: string; image?: string; altersTimeline?: boolean };
const typedScriptDefinitions = scriptDefinitions as Record<string, ScriptDefinition>;
const scriptDisplayOrder = [
  "Wraithstrike",
  "Voidrot",
  "Convergence",
  "Opportunity",
  "Detachment",
  "Insight",
  "Revelry",
  "None",
] as const;
const divinecraftDisplayOrder = [
  "Fire",
  "FireWater",
  "FirePoison",
  "None",
  "WaterFire",
  "WaterPoison",
  null,
  "PoisonFire",
  "PoisonWater",
] as const;
const comparisonCategoryOrder: RotationCalculationCategory[] = rotationCalculationCategories.filter(
  (category) => category !== "baseline",
);

function setupGroupMatchesCategory(group: string, category: RotationCalculationCategory) {
  if (category === "weaponSets") return group.startsWith("weaponSets:");
  if (category === "armorSets") return group.startsWith("armorSets:");
  if (category === "globalDebuffs") return group.startsWith("debuff:") || group.startsWith("buff:");
  return group === category;
}

type ComparisonVariantRequest = { key: string; bundle: RotationSimulationBundle };

function comparisonVariantRequests(
  bundle: RotationSimulationBundle,
  category: RotationCalculationCategory,
): ComparisonVariantRequest[] {
  const singleVariantBundle = (
    variant: RotationSimulationVariant,
    field: "statPriority" | "attunementPriority" | "innerWayPriority" | "setupComparisons",
    group?: string,
  ): RotationSimulationBundle => ({
    ...bundle,
    statPriority: field === "statPriority" ? [variant] : [],
    attunementPriority: field === "attunementPriority" ? [variant] : [],
    innerWayPriority: field === "innerWayPriority" ? [variant] : [],
    setupComparisons: field === "setupComparisons" && group ? { [group]: [variant] } : {},
  });
  const descriptor = (
    variant: RotationSimulationVariant,
    field: "statPriority" | "attunementPriority" | "innerWayPriority" | "setupComparisons",
    group?: string,
  ) => {
    return {
      key: rotationVariantFingerprint(category, field, group, variant),
      bundle: singleVariantBundle(variant, field, group),
    };
  };
  if (category === "statPriority") return bundle.statPriority.map((variant) => descriptor(variant, "statPriority"));
  if (category === "attunementPriority")
    return bundle.attunementPriority.map((variant) => descriptor(variant, "attunementPriority"));
  if (category === "innerWays")
    return bundle.innerWayPriority.map((variant) => descriptor(variant, "innerWayPriority"));
  return Object.entries(bundle.setupComparisons)
    .filter(([group]) => setupGroupMatchesCategory(group, category))
    .flatMap(([group, variants]) => variants.map((variant) => descriptor(variant, "setupComparisons", group)));
}

function combineComparisonVariantMetrics(
  current: RotationMetrics,
  results: RotationMetrics[],
  category: RotationCalculationCategory,
) {
  const combined: RotationMetrics = {
    ...current,
    statPriority: [],
    attunementPriority: [],
    innerWayPriority: [],
    setupComparisons: {},
  };
  if (category === "statPriority")
    combined.statPriority = sortRotationPriorityRows(results.flatMap((result) => result.statPriority));
  else if (category === "attunementPriority")
    combined.attunementPriority = sortAttunementPriorityRows(results.flatMap((result) => result.attunementPriority));
  else if (category === "innerWays")
    combined.innerWayPriority = sortRotationPriorityRows(
      results.flatMap((result) => result.innerWayPriority),
      "ascending",
    );
  else {
    for (const result of results)
      for (const [group, rows] of Object.entries(result.setupComparisons))
        combined.setupComparisons[group] = sortRotationPriorityRows([
          ...(combined.setupComparisons[group] ?? []),
          ...rows,
        ]);
  }
  return mergeComparisonCategory(current, combined, category);
}

function baselineMetricsWithPreviousComparisons(
  baseline: RotationMetrics,
  previous?: RotationMetrics,
): RotationMetrics {
  return {
    ...baseline,
    statPriority: previous?.statPriority ?? [],
    attunementPriority: previous?.attunementPriority ?? [],
    innerWayPriority: previous?.innerWayPriority ?? [],
    setupComparisons: previous?.setupComparisons ?? {},
  };
}

function mergeComparisonCategory(
  current: RotationMetrics,
  calculated: RotationMetrics,
  category: RotationCalculationCategory,
) {
  if (category === "statPriority") return { ...current, statPriority: calculated.statPriority };
  if (category === "attunementPriority") return { ...current, attunementPriority: calculated.attunementPriority };
  if (category === "innerWays") return { ...current, innerWayPriority: calculated.innerWayPriority };
  const setupComparisons = Object.fromEntries(
    Object.entries(current.setupComparisons).filter(([group]) => !setupGroupMatchesCategory(group, category)),
  );
  for (const [group, rows] of Object.entries(calculated.setupComparisons)) setupComparisons[group] = rows;
  return { ...current, setupComparisons };
}

type MartialArtDefinition = {
  name: string;
  weapon: WeaponFamily;
  tag: string;
  talent: MartialArtTalent<SetupEffect>[][];
};
const martialArtDefinitions: Record<WeaponId, MartialArtDefinition> = {
  snowparting: snowpartingMartialArt as MartialArtDefinition,
  phalanxbane: phalanxbaneMartialArt as MartialArtDefinition,
  thundercry: thundercryMartialArt as MartialArtDefinition,
  stormbreaker: stormbreakerMartialArt as MartialArtDefinition,
  everspring: everspringMartialArt as MartialArtDefinition,
  unfettered: unfetteredMartialArt as MartialArtDefinition,
  heavenwill: heavenwillMartialArt as MartialArtDefinition,
  skygrasp: skygraspMartialArt as MartialArtDefinition,
  namelessSword: namelessSwordMartialArt as MartialArtDefinition,
  namelessSpear: namelessSpearMartialArt as MartialArtDefinition,
  strategicSword: strategicSwordMartialArt as MartialArtDefinition,
  heavenquakerSpear: heavenquakerSpearMartialArt as MartialArtDefinition,
  vernalUmbrella: vernalUmbrellaMartialArt as MartialArtDefinition,
  inkwellFan: inkwellFanMartialArt as MartialArtDefinition,
  panaceaFan: panaceaFanMartialArt as MartialArtDefinition,
  soulshadeUmbrella: soulshadeUmbrellaMartialArt as MartialArtDefinition,
  infernalTwinblades: infernalTwinbladesMartialArt as MartialArtDefinition,
  mortalRopeDart: mortalRopeDartMartialArt as MartialArtDefinition,
  skystrikeGauntlets: skystrikeGauntletsMartialArt as MartialArtDefinition,
  rivenTwinblades: rivenTwinbladesMartialArt as MartialArtDefinition,
};
const weaponFamilyNames: Record<WeaponFamily, string> = {
  HengBlade: "Heng Blade",
  MoBlade: "Mo Blade",
  Spear: "Spear",
  Umbrella: "Umbrella",
  RopeDart: "Rope Dart",
  Gauntlet: "Gauntlet",
  Sword: "Sword",
  Fan: "Fan",
  DualBlades: "Dual Blades",
};
const weaponIdSet = new Set<WeaponId>(allWeaponIds);
const isWeaponId = (value: unknown): value is WeaponId =>
  typeof value === "string" && weaponIdSet.has(value as WeaponId);

const artStatByWeaponFamily: Record<WeaponFamily, keyof CharacterStats> = {
  HengBlade: "hengBladeDmgBoost",
  MoBlade: "moBladeDmgBoost",
  Spear: "spearDmgBoost",
  Umbrella: "umbrellaDmgBoost",
  RopeDart: "ropeDartDmgBoost",
  Gauntlet: "gauntletDmgBoost",
  Sword: "swordDmgBoost",
  Fan: "fanDmgBoost",
  DualBlades: "dualBladesDmgBoost",
};

function characterStatAvailableForSettings(
  key: keyof CharacterStats,
  settings: CalculatorSettings,
  pathId = loadSelectedPath(),
) {
  if (key === "criticalHealingBonus" || key === "silkbindHealingBonus") return pathId === "silkbindDeluge";
  const artStats = new Set(Object.values(artStatByWeaponFamily));
  if (artStats.has(key))
    return settings.weapons.some((weapon) => artStatByWeaponFamily[martialArtDefinitions[weapon].weapon] === key);
  return true;
}

function arsenalEffectFor(value: string) {
  return typedArsenalDefinitions[value]?.effect ?? {};
}

function bowRingSetEffectFor(value: string) {
  return typedBowRingSetDefinitions[value]?.effect ?? {};
}

function loadFood() {
  const saved = getPersistentItem(foodStorageKey);
  return saved && typedFoodDefinitions[saved] ? saved : typedDefaultSetup.food;
}

function selectedFoodEffect() {
  return typedFoodDefinitions[loadFood()]?.effect ?? {};
}

function loadDivinecraft() {
  const saved = getPersistentItem(divinecraftStorageKey);
  return saved && typedDivinecraftDefinitions[saved]?.available !== false ? saved : typedDefaultSetup.divinecraft;
}

function divinecraftEffectFor(value: string) {
  return typedDivinecraftDefinitions[value]?.effect ?? {};
}

function loadScript() {
  const saved = getPersistentItem(scriptStorageKey);
  return saved && typedScriptDefinitions[saved] ? saved : "None";
}

function scriptEffectFor(value: string) {
  return typedScriptDefinitions[value]?.effect ?? {};
}

function selectedMartialArtEffects(settings: CalculatorSettings) {
  return martialArtEffectsForRank(
    martialArtDefinitions,
    settings.weapons,
    breakthroughProfile(settings).martialArtTalentRank,
  );
}

function selectedSetupEffects(
  settings: CalculatorSettings,
  gearStatEffect: StatEffectContainer,
  buildSetup: BuildSetup,
  overrides: Partial<BuildSetup> & { food?: string; divinecraft?: string; script?: string } = {},
  pathId = loadSelectedPath(),
) {
  const selectedBuildSetup = {
    ...buildSetup,
    ...overrides,
    weaponSets: overrides.weaponSets ?? buildSetup.weaponSets,
    armorSets: overrides.armorSets ?? buildSetup.armorSets,
  };
  const foodEffect = overrides.food ? (typedFoodDefinitions[overrides.food]?.effect ?? {}) : selectedFoodEffect();
  const divinecraftEffect = divinecraftEffectFor(overrides.divinecraft ?? loadDivinecraft());
  const scriptEffect = scriptEffectFor(overrides.script ?? loadScript());
  return [
    ...globalEffectRules,
    ...systemStatEffects,
    breakthroughProfile(settings).levelBonusStats,
    ...selectedMartialArtEffects(settings),
    arsenalEffectFor(selectedBuildSetup.arsenal),
    bowRingSetEffectFor(selectedBuildSetup.bowRingSet),
    ...setEffectsFor(selectedBuildSetup.weaponSets, typedWeaponSetDefinitions, settings, pathId),
    ...setEffectsFor(selectedBuildSetup.armorSets, typedArmorSetDefinitions, settings, pathId),
    { ...foodEffect, statStage: "food" as const },
    scriptEffect,
    divinecraftEffect,
    gearStatEffect,
  ];
}

function setAvailableForSettings(
  definition: GearSetDefinition,
  settings: CalculatorSettings,
  pathId = loadSelectedPath(),
) {
  return setAvailableForTags(
    definition,
    settings.weapons.map((weapon) => martialArtDefinitions[weapon].tag),
    typedPathDefinitions[pathId].tag,
  );
}

function availableSetEntriesForSettings<T extends GearSetDefinition>(
  definitions: Record<string, T>,
  settings: CalculatorSettings,
  pathId = loadSelectedPath(),
) {
  return availableSetEntriesForTags(
    definitions,
    settings.weapons.map((weapon) => martialArtDefinitions[weapon].tag),
    typedPathDefinitions[pathId].tag,
  );
}

function setEffectsFor(
  selected: SetSelections,
  definitions: Record<string, GearSetDefinition>,
  settings: CalculatorSettings,
  pathId = loadSelectedPath(),
) {
  return Object.entries(selected)
    .filter(([setName]) => definitions[setName] && setAvailableForSettings(definitions[setName], settings, pathId))
    .flatMap(([setName, tier]) => {
      const effect = definitions[setName]?.options[String(tier)]?.effect;
      return Array.isArray(effect) ? effect : [effect ?? {}];
    });
}

function setupConditionsFor(effects: SetupEffect[]) {
  return effects.flatMap((effect) => (typeof effect.condition === "string" ? [effect.condition] : []));
}

function sameBuildSetupValue(
  key: keyof BuildSetup,
  left: BuildSetup[keyof BuildSetup],
  right: BuildSetup[keyof BuildSetup],
) {
  return key === "weaponSets" || key === "armorSets" || key === "innerWays"
    ? JSON.stringify(left) === JSON.stringify(right)
    : left === right;
}

export function loadBuildSetupOverrides(baseline: BuildSetup): BuildSetupOverrides {
  try {
    const saved = getPersistentItem(buildSetupOverrideStorageKey);
    if (saved !== null) return normalizeBuildSetupOverrides(JSON.parse(saved));
    const legacy: Record<string, unknown> = {};
    const legacyInnerWays = getPersistentItem(legacyInnerWayStorageKey);
    const legacyGearSets = getPersistentItem(gearSetStorageKey);
    const legacyBowRingSet = getPersistentItem(bowRingSetStorageKey);
    const legacyArsenal = getPersistentItem(arsenalStorageKey);
    if (legacyInnerWays !== null) legacy.innerWays = JSON.parse(legacyInnerWays);
    if (legacyGearSets !== null) legacy.weaponSets = JSON.parse(legacyGearSets);
    if (legacyBowRingSet !== null) legacy.bowRingSet = legacyBowRingSet;
    if (legacyArsenal !== null) legacy.arsenal = legacyArsenal;
    const parsed = normalizeBuildSetupOverrides(legacy);
    return Object.fromEntries(
      Object.entries(parsed).filter(
        ([key, value]) =>
          !sameBuildSetupValue(
            key as keyof BuildSetup,
            value as BuildSetup[keyof BuildSetup],
            baseline[key as keyof BuildSetup],
          ),
      ),
    ) as BuildSetupOverrides;
  } catch {
    return {};
  }
}

function formatNumber(value: number) {
  return Number.isInteger(value) ? String(value) : value.toFixed(2).replace(/0+$/, "").replace(/\.$/, "");
}

function formatDamageNumber(value: number) {
  const rounded = Number(value.toFixed(2));
  return rounded === 0 ? "0" : rounded.toFixed(2);
}

type ThroughputChannel = "damage" | "healing";

function displayedDelta(value: number) {
  return Number(value.toFixed(2));
}

function formatDelta(value: number) {
  const delta = displayedDelta(value);
  return delta === 0 ? "0" : delta.toFixed(2);
}

function deltaPrefix(value: number) {
  return displayedDelta(value) > 0 ? "+" : "";
}

function throughputDeltaClass(value: number, channel: ThroughputChannel) {
  const delta = displayedDelta(value);
  if (delta === 0) return "throughput-neutral";
  switch (channel) {
    case "damage":
      return delta > 0 ? "damage-positive" : "damage-negative";
    case "healing":
      return delta > 0 ? "healing-positive" : "healing-negative";
  }
}

function skillFieldText(skillId: string, skill: SkillRecord | undefined, field: "name" | "shortName") {
  const value = skill?.[field]?.trim();
  if (!value) return field === "name" ? skillId : "";
  const namespace = skillDataNamespaceById.get(skillId);
  const defaultValue = allSkillDefinitions[skillId]?.[field]?.trim();
  return namespace && value === defaultValue ? dataText(`data.skill.${namespace}.${skillId}.${field}`, value) : value;
}

function skillDisplayName(skill: SkillRecord | undefined, fallback = "", skillId = fallback) {
  const name = skillFieldText(skillId, skill, "name");
  const shortName = skillFieldText(skillId, skill, "shortName");
  return shortName ? `${name} (${shortName})` : name;
}

function RotationSkillName({ skill, fallback = "" }: { skill: SkillRecord | undefined; fallback?: string }) {
  const name = skillFieldText(fallback, skill, "name");
  const shortName = skillFieldText(fallback, skill, "shortName");
  return (
    <span className="rotation-skill-label">
      <span>{name}</span>
      {shortName && <span>({shortName})</span>}
    </span>
  );
}

function loadStats(): CharacterStats {
  try {
    const currentSaved = localStorage.getItem(storageKey);
    const isLegacy = currentSaved === null;
    const saved = JSON.parse(currentSaved ?? localStorage.getItem(legacyStorageKey) ?? "null") as
      | (Partial<CharacterStats> & Record<string, unknown> & { attributeDmgBonus?: unknown })
      | null;
    if (!saved) return { ...emptyStats };
    const legacyAttributeBonus =
      typeof saved.attributeDmgBonus === "number" && Number.isFinite(saved.attributeDmgBonus)
        ? saved.attributeDmgBonus / (isLegacy ? 100 : 1)
        : 0;
    const pathBonusKeys = new Set<keyof CharacterStats>([
      "bellstrikeDmgBonus",
      "stonesplitDmgBonus",
      "silkbindDmgBonus",
      "bamboocutDmgBonus",
    ]);
    const legacyPenetrationKeys: Partial<Record<keyof CharacterStats, string>> = {
      bellstrikePenetration: "bellstrikePen",
      silkbindPenetration: "silkbindPen",
      stonesplitPenetration: "stonesplitPen",
      bamboocutPenetration: "bamboocutPen",
    };
    return Object.fromEntries(
      allStatDefinitions.map(({ key }) => {
        const savedValue = saved[key] ?? (legacyPenetrationKeys[key] ? saved[legacyPenetrationKeys[key]!] : undefined);
        const hasSavedValue = typeof savedValue === "number" && Number.isFinite(savedValue);
        const value = hasSavedValue ? savedValue : pathBonusKeys.has(key) ? legacyAttributeBonus : 0;
        return [key, isLegacy && hasSavedValue && percentageStatKeys.has(key) ? value / 100 : value];
      }),
    ) as CharacterStats;
  } catch {
    return { ...emptyStats };
  }
}

function loadStatOverrides(): CharacterStatOverrides {
  try {
    const currentSaved = localStorage.getItem(statOverrideStorageKey);
    if (currentSaved !== null) {
      const values = JSON.parse(currentSaved) as Record<string, unknown>;
      return Object.fromEntries(
        allStatDefinitions.flatMap(({ key }) => {
          const value = values?.[key];
          return typeof value === "number" && Number.isFinite(value) ? [[key, value]] : [];
        }),
      ) as CharacterStatOverrides;
    }

    // Existing raw stat entries were all manual inputs. Preserve non-zero values
    // as final-value overrides when moving to the calculated-stat model.
    return Object.fromEntries(Object.entries(loadStats()).filter(([, value]) => value !== 0)) as CharacterStatOverrides;
  } catch {
    return {};
  }
}

function loadSettings(): CalculatorSettings {
  try {
    const saved = JSON.parse(getPersistentItem(settingsStorageKey) ?? "null") as {
      weapons?: unknown;
      weapon?: unknown;
      ping?: unknown;
    } | null;
    const savedWeapons = Array.isArray(saved?.weapons) ? saved.weapons.filter(isWeaponId) : [];
    const legacyWeapon = saved && "weapon" in saved && saved.weapon === "phalanxbane" ? "phalanxbane" : "snowparting";
    const weapons: [WeaponId, WeaponId] =
      savedWeapons.length === 2
        ? [savedWeapons[0], savedWeapons[1]]
        : [legacyWeapon, legacyWeapon === "snowparting" ? "phalanxbane" : "snowparting"];
    return { weapons, breakthrough: defaultBreakthrough, ping: resolvePing(saved?.ping) };
  } catch {
    return { ...defaultSettings };
  }
}

function loadSkillOverrides(): SkillOverrides {
  try {
    return deserializeSkillOverrides(JSON.parse(getPersistentItem(skillStorageKey) ?? "{}"));
  } catch {
    return {};
  }
}

function hasSkillOverrides(overrides: SkillOverrides) {
  return Object.values(overrides).some(
    (categoryOverrides) => categoryOverrides && Object.keys(categoryOverrides).length > 0,
  );
}

const defaultAttunementStats = Object.fromEntries(
  Object.keys(attunementData).map((key) => [key, 0]),
) as AttunementStats;
const percentageAttunementKeys = new Set<keyof AttunementStats>(
  Object.entries(attunementData)
    .filter(([, definition]) => definition.percentage)
    .map(([key]) => key as keyof AttunementStats),
);
type CharacterState = {
  stats: CharacterStats;
  rawStats: CharacterStats;
  baseStats: CharacterStats;
  attunementStats: AttunementStats;
  displayedAttunementStats: AttunementStats;
  settings: CalculatorSettings;
  enemy: EnemyProfile;
  derivedStats: DerivedStats;
  innerWayRevision: number;
  gearStatEffect: StatEffectContainer;
  buildSetup: BuildSetup;
};

function loadAttunementStats() {
  try {
    const currentSaved = getPersistentItem(attunementStorageKey);
    const isLegacy = currentSaved === null;
    const saved = JSON.parse(currentSaved ?? getPersistentItem(legacyAttunementStorageKey) ?? "null") as unknown;
    if (!saved || typeof saved !== "object") return { ...defaultAttunementStats };
    const values = saved as Record<string, unknown>;
    return Object.fromEntries(
      Object.keys(defaultAttunementStats).map((key) => {
        const statKey = key as keyof AttunementStats;
        const value = typeof values[key] === "number" && Number.isFinite(values[key]) ? (values[key] as number) : 0;
        return [key, isLegacy && percentageAttunementKeys.has(statKey) ? value / 100 : value];
      }),
    ) as typeof defaultAttunementStats;
  } catch {
    return { ...defaultAttunementStats };
  }
}

function loadAttunementOverrides(): AttunementOverrides {
  try {
    const currentSaved = getPersistentItem(attunementOverrideStorageKey);
    if (currentSaved !== null) {
      const values = JSON.parse(currentSaved) as Record<string, unknown>;
      return Object.fromEntries(
        Object.keys(defaultAttunementStats).flatMap((key) => {
          const value = values?.[key];
          return typeof value === "number" && Number.isFinite(value) ? [[key, value]] : [];
        }),
      ) as AttunementOverrides;
    }
    return Object.fromEntries(
      Object.entries(loadAttunementStats()).filter(([, value]) => value !== 0),
    ) as AttunementOverrides;
  } catch {
    return {};
  }
}

function loadRotationEntries(): RotationEntry[] {
  const bundledDefaults = (): RotationEntry[] =>
    defaultRotationEntries.map((entry) => ({
      ...entry,
      martialArts: [...entry.martialArts],
      rotation: JSON.parse(JSON.stringify(entry.rotation)) as RotationRecord,
    }));
  try {
    const saved = JSON.parse(getPersistentItem(rotationListStorageKey) ?? "null") as RotationEntry[] | null;
    const customEntries: RotationEntry[] = [];
    const bundledDefaultIds = new Set(defaultRotationEntries.map((entry) => entry.id));
    const usedIds = new Set(bundledDefaultIds);
    const addCustom = (preferredId: string, rotation: RotationRecord, martialArts?: unknown) => {
      let id = preferredId;
      let suffix = 2;
      while (usedIds.has(id)) id = `${preferredId}:${suffix++}`;
      usedIds.add(id);
      customEntries.push({ id, rotation, martialArts: rotationMartialArts(rotation, martialArts) });
    };
    const preserveFormerDefault = (rotation: RotationRecord) => {
      const migrated = migrateRotation(rotation);
      if (defaultRotationEntries.some((entry) => JSON.stringify(migrated) === JSON.stringify(entry.rotation))) return;
      addCustom("migrated-default-rotation", { ...migrated, name: `${migrated.name || defaultRotation.name} Copy` });
    };
    if (Array.isArray(saved)) {
      saved.forEach((entry) => {
        if (
          !entry ||
          typeof entry.id !== "string" ||
          !entry.id ||
          !entry.rotation ||
          !Array.isArray(entry.rotation.steps)
        )
          return;
        try {
          if (entry.isDefault === true || bundledDefaultIds.has(entry.id) || formerDefaultRotationIds.has(entry.id))
            preserveFormerDefault(entry.rotation);
          else addCustom(entry.id, migrateRotation(entry.rotation), entry.martialArts);
        } catch (error) {
          console.error(`[Rotation storage] Could not migrate saved rotation ${entry.id}.`, error);
        }
      });
      return [...bundledDefaults(), ...customEntries];
    }
    const legacy = JSON.parse(getPersistentItem(rotationStorageKey) ?? "null") as RotationRecord | null;
    if (legacy && Array.isArray(legacy.steps)) preserveFormerDefault(legacy);
    return [...bundledDefaults(), ...customEntries];
  } catch {
    return bundledDefaults();
  }
}

function initialRotationId(entries: RotationEntry[], preferredId: string, weapons: [WeaponId, WeaponId]) {
  return (
    entries.find((entry) => entry.id === preferredId && rotationAvailableForWeapons(entry, weapons))?.id ??
    entries.find((entry) => rotationAvailableForWeapons(entry, weapons))?.id ??
    defaultRotationId
  );
}

function initialRotationEditorState(devMode: boolean, preferredRotationId: string, weapons: [WeaponId, WeaponId]) {
  const entries = loadRotationEntries();
  const selectableEntries = entries.filter((entry) => devMode || !entry.test);
  const activeId = initialRotationId(selectableEntries, preferredRotationId, weapons);
  const activeRotation =
    selectableEntries.find((entry) => entry.id === activeId)?.rotation ??
    selectableEntries[0]?.rotation ??
    defaultRotation;
  const rotation = JSON.parse(JSON.stringify(activeRotation)) as RotationRecord;
  const startAnchor = rotation.start
    ? { rowId: `rotation-${rotation.start.step}`, actionIndex: rotation.start.action }
    : { rowId: "rotation-0" };
  return { entries, activeId, rotation, startAnchor };
}

function rotationEntryDisplayName(entry: RotationEntry) {
  const name = entry.rotation.name || "Unnamed Rotation";
  return entry.isDefault ? gameText(name) : name;
}

function globalStatEffects(settings: CalculatorSettings, gearStatEffect: StatEffectContainer, buildSetup: BuildSetup) {
  const innerWayStatEffects = innerWayEffectRulesFor(buildSetup.innerWays, breakthroughProfile(settings).soloLevel)
    .filter(
      (rule) =>
        requirementIsUnconditional(rule.requirement) &&
        (rule.effect.rawStat || rule.effect.stat || rule.effect.effectiveStat),
    )
    .map((rule) => rule.effect as StatEffectContainer);
  // A setup effect with requirements is a per-action rule. It is resolved by
  // the rotation calculator against the current skill and timeline state and
  // must not leak into the always-visible character-stat baseline.
  const unconditionalSetupEffects = selectedSetupEffects(settings, gearStatEffect, buildSetup).filter(
    (effect) => !("requirement" in effect) || requirementIsUnconditional(effect.requirement),
  );
  return [...unconditionalSetupEffects, ...innerWayStatEffects];
}

function calculateGlobalStatState(
  overrides: CharacterStatOverrides,
  settings: CalculatorSettings,
  gearStatEffect: StatEffectContainer,
  buildSetup: BuildSetup,
) {
  const breakthrough = breakthroughProfile(settings);
  const enemy: EnemyProfile = breakthrough;
  return calculateStatsWithOverrides(
    emptyStats,
    globalStatEffects(settings, gearStatEffect, buildSetup),
    enemy.judgementResistance,
    overrides,
    settings.weapons,
  );
}

type GraduationEnvironment = {
  pathId: PathId;
  martialArts: [WeaponId, WeaponId];
  rotation: RotationRecord;
  breakthrough: string;
  globalDebuffs: GlobalDebuffState;
  food: string;
  script: string;
  divinecraft: string;
  skillOverrides: SkillOverrides;
};

function graduationEnvironmentFingerprint(environment: GraduationEnvironment) {
  const { name: _displayName, ...rotation } = environment.rotation;
  return calculationFingerprint({
    pathId: environment.pathId,
    martialArts: environment.martialArts,
    rotation,
    breakthrough: environment.breakthrough,
    globalDebuffs: environment.globalDebuffs,
    food: environment.food,
    script: environment.script,
    divinecraft: environment.divinecraft,
    skillOverrides: environment.skillOverrides,
  });
}

export function buildPresetRotationBundle(
  environment: GraduationEnvironment,
  buildId: string,
): RotationSimulationBundle | undefined {
  const { pathId } = environment;
  const path = typedPathDefinitions[pathId];
  if (!path || buildId === "empty") return undefined;
  const build = defaultBuildPresets.find((candidate) => candidate.id === buildId);
  const configuredWeapons = path.lockedWeapons ?? build?.martialArts;
  if (!build || configuredWeapons?.length !== 2) return undefined;

  const weapons = [...configuredWeapons] as [WeaponId, WeaponId];
  const settings: CalculatorSettings = {
    weapons,
    breakthrough: environment.breakthrough,
    ping: resolvePing(environment.rotation.ping),
  };
  const buildSetup = normalizeBuildSetup(build.setup);
  const equippedGear = calculateEquippedGearEffects(buildPresetInventory(build), weapons, false);
  const gearStatEffect: StatEffectContainer = { rawStat: equippedGear.stats };
  const setupEffects = selectedSetupEffects(
    settings,
    gearStatEffect,
    buildSetup,
    { food: environment.food, divinecraft: environment.divinecraft, script: environment.script },
    pathId,
  );
  const innerWayRules = innerWayEffectRulesFor(buildSetup.innerWays, breakthroughProfile(settings).soloLevel, pathId);
  const innerWayConditions = innerWayConditionsFor(buildSetup.innerWays, undefined, pathId);
  const innerWayStatEffects = innerWayRules
    .filter(
      (rule) =>
        requirementIsUnconditional(rule.requirement) &&
        (rule.effect.rawStat || rule.effect.stat || rule.effect.effectiveStat),
    )
    .map((rule) => rule.effect as StatEffectContainer);
  const unconditionalSetupEffects = setupEffects.filter(
    (effect) => !("requirement" in effect) || requirementIsUnconditional(effect.requirement),
  );
  const enemy = breakthroughProfile(settings);
  const statState = calculateStatsWithOverrides(
    emptyStats,
    [...unconditionalSetupEffects, ...innerWayStatEffects],
    enemy.judgementResistance,
    {},
    weapons,
  );
  const definitions = resolveSkillCalculationDefinitions(
    defaultSkillMaps,
    effectDefinitions,
    dotDefinitions,
    environment.skillOverrides,
  );
  const rotation = { ...environment.rotation, ping: resolvePing(environment.rotation.ping) };
  const rotationAnchor = rotation.start
    ? { rowId: `rotation-${rotation.start.step}`, actionIndex: rotation.start.action }
    : { rowId: "rotation-0" };

  return {
    timeline: {
      rotation,
      skills: definitions.skills,
      eventDefinitions: rotationEventDefinitions,
      dots: definitions.dots,
      effectDefinitions: definitions.effectDefinitions,
      innerWayConditions: [...innerWayConditions, ...setupConditionsFor(setupEffects)],
      innerWayRules,
      setupEffects,
      weapons,
      martialArtState: Object.fromEntries(
        weapons.map((martialArt) => [martialArt, { weapon: martialArtDefinitions[martialArt].weapon }]),
      ),
      initialBuffs: globalBuffTimelineEffects(environment.globalDebuffs),
      initialDebuffs: globalDebuffTimelineEffects(environment.globalDebuffs),
      initialResources: { ...typedSystemStats.initialResources, Vitality: statState.stats.maxVitality },
      resourceRegeneration: { HeavensWill: statState.stats.heavensWillRegen },
      resourceMaximums: { ...typedSystemStats.resourceMaximums, Vitality: statState.stats.maxVitality },
      resourceEvents: typedSystemStats.resourceEvents,
      maxHP: statState.stats.maxHp,
    },
    startAnchor: rotationAnchor,
    stats: statState.stats,
    rawStats: statState.rawStats,
    baseStats: statState.baseStats,
    attunement: { ...defaultAttunementStats, ...equippedGear.attunement },
    enemy,
    weapons,
    statPriority: [],
    attunementPriority: [],
    innerWayPriority: [],
    setupComparisons: {},
  };
}

function StatField({
  definition,
  stats,
  onChange,
  onReset,
  modified = false,
  derivedLabel,
  derivedValue,
  derivedUnit,
  compact,
}: {
  definition: StatDefinition;
  stats: CharacterStats;
  onChange: (key: keyof CharacterStats, value: number) => void;
  onReset?: () => void;
  modified?: boolean;
  derivedLabel?: string;
  derivedValue?: number;
  derivedUnit?: string;
  compact?: boolean;
}) {
  const displayValue = (value: number) => (definition.unit === "%" ? value * 100 : value);
  const [draftValue, setDraftValue] = useState(() => formatNumber(displayValue(stats[definition.key])));
  const [editing, setEditing] = useState(false);
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    if (!editing) setDraftValue(formatNumber(displayValue(stats[definition.key])));
  }, [editing, stats, definition.key]);

  function commitValue(rawValue: string) {
    const normalized = Number(rawValue);
    const displayedValue = Number.isFinite(normalized) ? normalized : 0;
    const uncappedValue = definition.unit === "%" ? displayedValue / 100 : displayedValue;
    const value = Math.min(definition.maximum ?? Number.POSITIVE_INFINITY, uncappedValue);
    setDraftValue(String(displayValue(value)));
    setEditing(false);
    setDirty(false);
    onChange(definition.key, value);
  }

  function finishEditing(rawValue: string) {
    if (dirty) commitValue(rawValue);
    else {
      setEditing(false);
      setDraftValue(formatNumber(displayValue(stats[definition.key])));
    }
  }

  return (
    <label className={`field ${compact ? "compact-field" : ""} ${modified ? "modified-field" : ""}`}>
      <span className="field-label">
        <span>
          {gameText(definition.label)}
          {definition.unit && definition.showUnitInLabel !== false ? ` ${definition.unit}` : ""}
        </span>
        {modified && (
          <button
            className="stat-reset-button"
            type="button"
            aria-label={t("ui.app.resetNamedValue", { name: gameText(definition.label) })}
            title={t("ui.app.resetToCalculatedValue")}
            onClick={(event) => {
              event.preventDefault();
              onReset?.();
            }}
          >
            <UiIcon name="reset" />
          </button>
        )}
      </span>
      <span className="input-wrap">
        <input
          type="number"
          min="0"
          max={
            definition.maximum !== undefined
              ? displayValue(definition.maximum)
              : definition.unit === "%"
                ? 100
                : undefined
          }
          step={definition.step ?? "0.01"}
          value={draftValue}
          onFocus={() => {
            setEditing(true);
            setDirty(false);
          }}
          onChange={(event) => {
            setDraftValue(event.target.value);
            setDirty(true);
          }}
          onBlur={(event) => finishEditing(event.currentTarget.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter") event.currentTarget.blur();
          }}
        />
        {definition.unit && definition.showUnitInInput !== false && (
          <span className="input-unit">{definition.unit}</span>
        )}
      </span>
      {derivedLabel ? <small className="inline-derived">{derivedLabel}</small> : <span className="derived-spacer" />}
      {derivedLabel ? (
        <strong className="inline-derived-value">
          {derivedValue === undefined ? "—" : formatNumber(derivedValue)}
          {derivedUnit ?? ""}
        </strong>
      ) : (
        <span className="derived-spacer" />
      )}
    </label>
  );
}

function PriorityPanel({
  title,
  rows,
  calculationCategory,
  sectionBreakAt,
  showMaxRoll = false,
  showHealing = false,
}: {
  title: string;
  rows: RotationPriority[];
  calculationCategory: RotationCalculationCategory;
  sectionBreakAt?: number;
  showMaxRoll?: boolean;
  showHealing?: boolean;
}) {
  const [statMode, setStatMode] = useState<StatPriorityMode>("max");
  const isStatPriority = calculationCategory === "statPriority";
  const displayedRows = useMemo(
    () => statPriorityDisplayRows(rows, isStatPriority ? statMode : "max"),
    [rows, isStatPriority, statMode],
  );
  const modeLabels = {
    max: t("ui.app.priorityModeMax"),
    relayed: t("ui.buildTab.relayedOptionLabel"),
    both: t("ui.app.priorityModeBoth"),
  };
  return (
    <section className="panel priority-panel">
      <div className="panel-heading">
        <div>
          <h2>{title}</h2>
          <CalculationStatus category={calculationCategory} />
        </div>
        {isStatPriority && (
          <button
            type="button"
            className="button button-secondary priority-mode-control"
            onClick={() => setStatMode(nextStatPriorityMode)}
            aria-label={t("ui.app.priorityModeSwitch", {
              current: modeLabels[statMode],
              next: modeLabels[nextStatPriorityMode(statMode)],
            })}
          >
            {modeLabels[statMode]}
          </button>
        )}
      </div>
      {rows.length > 0 ? (
        <div
          className={`priority-list ${showMaxRoll ? "priority-list-with-roll" : ""} ${showHealing ? "priority-list-with-healing" : ""}`}
        >
          <div className="priority-header">
            <span>{t("ui.app.name")}</span>
            {showMaxRoll && (
              <span>{isStatPriority && statMode !== "max" ? t("ui.app.priorityRoll") : t("ui.app.maxRoll")}</span>
            )}
            <span>{t("ui.app.throughputDeltaHeader", { throughput: t("system.dps") })}</span>
            <span>{t("ui.app.throughputPercentageHeader", { throughput: t("system.dps") })}</span>
            {showHealing ? (
              <>
                <span className="healing-value">
                  {t("ui.app.throughputDeltaHeader", { throughput: t("system.hps") })}
                </span>
                <span className="healing-value">
                  {t("ui.app.throughputPercentageHeader", { throughput: t("system.hps") })}
                </span>
              </>
            ) : null}
          </div>
          {displayedRows.map((row, index) => (
            <div
              className={`priority-row ${sectionBreakAt === index ? "priority-section-start" : ""}`}
              key={`${row.label}-${row.rollKind}`}
            >
              <span>
                {gameText(row.label)}
                {isStatPriority && statMode === "both" && row.rollKind === "relayed" && (
                  <span
                    className="priority-relayed-indicator"
                    role="img"
                    aria-label={t("ui.buildTab.relayedOptionLabel")}
                    title={t("ui.buildTab.relayedOptionLabel")}
                  >
                    <UiIcon name="arrowUp" />
                  </span>
                )}
              </span>
              {showMaxRoll && (
                <strong className="priority-max-roll">
                  {row.maxRoll === undefined ? "—" : formatNumber(row.maxRoll)}
                </strong>
              )}
              <strong className={throughputDeltaClass(row.dpsDifference, "damage")}>
                {deltaPrefix(row.dpsDifference)}
                {formatDelta(row.dpsDifference)}
              </strong>
              <strong className={throughputDeltaClass(row.increase, "damage")}>
                {deltaPrefix(row.increase)}
                {formatDelta(row.increase)}%
              </strong>
              {showHealing ? (
                <>
                  <strong className={throughputDeltaClass(row.hpsDifference, "healing")}>
                    {deltaPrefix(row.hpsDifference)}
                    {formatDelta(row.hpsDifference)}
                  </strong>
                  <strong className={throughputDeltaClass(row.healingIncrease, "healing")}>
                    {deltaPrefix(row.healingIncrease)}
                    {formatDelta(row.healingIncrease)}%
                  </strong>
                </>
              ) : null}
            </div>
          ))}
        </div>
      ) : (
        <p className="priority-empty">{t("ui.app.openTheRotationEditorToCalculatePriority")}</p>
      )}
    </section>
  );
}

function BreakdownGroupTable({
  title,
  rows,
  healingRows = [],
  colored = false,
}: {
  title: string;
  rows: RotationGroupBreakdown[];
  healingRows?: RotationHealingGroupBreakdown[];
  colored?: boolean;
}) {
  const hasHealing = healingRows.some((row) => row.healing > 0);
  return (
    <section className="panel breakdown-panel">
      <div className="panel-heading">
        <div>
          <h2>{title}</h2>
        </div>
      </div>
      {hasHealing ? <h3 className="breakdown-channel-heading">{t("ui.app.damage")}</h3> : null}
      <div className="breakdown-table breakdown-group-table">
        <div className="breakdown-table-header">
          <span>{t("ui.app.category")}</span>
          <span>{t("ui.app.damage")}</span>
          <span>{t("ui.app.total")}</span>
        </div>
        {rows.map((row) => (
          <div className="breakdown-table-row" key={row.id}>
            <span className={colored ? `damage-${row.id}` : ""}>{gameText(row.name)}</span>
            <strong>{formatDamageNumber(row.damage)}</strong>
            <strong>{formatNumber(row.percentage)}%</strong>
          </div>
        ))}
      </div>
      {hasHealing ? (
        <>
          <h3 className="breakdown-channel-heading healing-value">{t("ui.app.healing")}</h3>
          <div className="breakdown-table breakdown-group-table breakdown-healing-table">
            <div className="breakdown-table-header">
              <span>{t("ui.app.category")}</span>
              <span>{t("ui.app.healing")}</span>
              <span>{t("ui.app.total")}</span>
            </div>
            {healingRows
              .filter((row) => row.healing > 0)
              .map((row) => (
                <div className="breakdown-table-row" key={row.id}>
                  <span className={colored ? `healing-${row.id}` : ""}>{gameText(row.name)}</span>
                  <strong className="healing-value">+{formatDamageNumber(row.healing)}</strong>
                  <strong>{formatNumber(row.percentage)}%</strong>
                </div>
              ))}
          </div>
        </>
      ) : null}
    </section>
  );
}

function CastBreakdownComparison({
  value,
  valueWithBuff,
  stacked,
}: {
  value: number | undefined;
  valueWithBuff: number | undefined;
  stacked: boolean;
}) {
  if (valueWithBuff === undefined) return value === undefined ? "—" : formatDamageNumber(value);
  if (!stacked) return `${formatDamageNumber(value ?? 0)} (${formatDamageNumber(valueWithBuff)})`;
  return (
    <span className="breakdown-stacked-value">
      <span>{formatDamageNumber(value ?? 0)}</span>
      <span>({formatDamageNumber(valueWithBuff)})</span>
    </span>
  );
}

const stackedBuffAttributionTags = new Set(["FluteOfTheTides", "GhostlySteps"]);

function EffectCoveragePanel({
  title,
  rows,
  showTimeCoverage = false,
}: {
  title: string;
  rows: RotationEffectCoverage[];
  showTimeCoverage?: boolean;
}) {
  return (
    <section className="panel breakdown-panel">
      <div className="panel-heading">
        <div>
          <h2>{title}</h2>
        </div>
      </div>
      <div className={`breakdown-table breakdown-coverage-table${showTimeCoverage ? " with-time-coverage" : ""}`}>
        <div className="breakdown-table-header">
          <span>{t("ui.app.effect")}</span>
          <span>{t("ui.app.averageStack")}</span>
          {showTimeCoverage ? <span>{t("ui.app.timeCoverage")}</span> : null}
        </div>
        {rows.map((row) => (
          <div className="breakdown-table-row" key={row.id}>
            <span>{gameText(effectDefinitions[row.id]?.name ?? row.id)}</span>
            <strong>{formatNumber(row.averageStacks)}</strong>
            {showTimeCoverage ? (
              <strong>{row.timeCoverage === undefined ? "—" : `${formatNumber(row.timeCoverage)}%`}</strong>
            ) : null}
          </div>
        ))}
      </div>
    </section>
  );
}

function BreakdownTab({ metrics, pathId }: { metrics?: RotationMetrics; pathId: PathId }) {
  if (!metrics)
    return (
      <section className="panel breakdown-empty">
        <h2>{t("ui.app.dpsBreakdown", { dps: t("system.dps") })}</h2>
        <p>{t("ui.app.openTheRotationEditorToCalculateTheActive")}</p>
      </section>
    );
  const { breakdown } = metrics;
  const hasHealing = metrics.totalHealing > 0;
  const showDamagePerVitality = pathId === "silkbindDeluge";
  const castRows = showDamagePerVitality
    ? [...breakdown.casts].sort((left, right) => {
        const leftPerVitality = left.damagePerVitalityWithBuff ?? left.damagePerVitality ?? Number.NEGATIVE_INFINITY;
        const rightPerVitality = right.damagePerVitalityWithBuff ?? right.damagePerVitality ?? Number.NEGATIVE_INFINITY;
        return (
          rightPerVitality - leftPerVitality ||
          (right.averageDpsWithBuff ?? right.averageDps ?? Number.NEGATIVE_INFINITY) -
            (left.averageDpsWithBuff ?? left.averageDps ?? Number.NEGATIVE_INFINITY)
        );
      })
    : breakdown.casts;
  return (
    <div className="breakdown-page">
      <section className="panel breakdown-panel">
        <div className="panel-heading">
          <div>
            <h2>{t("ui.app.perSkillBreakdown")}</h2>
          </div>
          <div className="breakdown-totals">
            <span>
              {t("system.totalDamage")} <strong>{formatDamageNumber(metrics.totalDamage)}</strong>
            </span>
            <span>
              {t("system.dps")} <strong>{formatDamageNumber(metrics.dps)}</strong>
            </span>
            {hasHealing ? (
              <>
                <span>
                  {t("system.totalHealing")}{" "}
                  <strong className="healing-value">+{formatDamageNumber(metrics.totalHealing)}</strong>
                </span>
                <span>
                  {t("system.hps")} <strong className="healing-value">{formatDamageNumber(metrics.hps)}</strong>
                </span>
              </>
            ) : null}
          </div>
        </div>
        {hasHealing ? <h3 className="breakdown-channel-heading">{t("ui.app.damage")}</h3> : null}
        <div className="breakdown-table breakdown-skill-table">
          <div className="breakdown-table-header">
            <span>{t("ui.app.skill")}</span>
            <span>{t("ui.app.casts")}</span>
            <span>{t("ui.app.triggers")}</span>
            <span>{t("ui.app.hits")}</span>
            <span>{t("system.abrasion")}</span>
            <span>{t("system.normal")}</span>
            <span>{t("system.critical")}</span>
            <span>{t("system.affinity")}</span>
            <span>{t("ui.app.damage")}</span>
            <span>{t("ui.app.total")}</span>
          </div>
          {breakdown.skills.map((row) => (
            <div className="breakdown-table-row" key={row.id}>
              <span>{skillDisplayName(allSkillDefinitions[row.id], row.name, row.id)}</span>
              <strong>{row.casts || ""}</strong>
              <strong>{row.triggers ? formatNumber(row.triggers) : ""}</strong>
              <strong>{row.hits ? formatNumber(row.hits) : ""}</strong>
              <strong>{formatNumber(row.abrasionRate)}%</strong>
              <strong>{formatNumber(row.normalRate)}%</strong>
              <strong>{formatNumber(row.criticalRate)}%</strong>
              <strong>{formatNumber(row.affinityRate)}%</strong>
              <strong>{formatDamageNumber(row.damage)}</strong>
              <strong>{formatNumber(row.percentage)}%</strong>
            </div>
          ))}
        </div>
        {hasHealing ? (
          <>
            <h3 className="breakdown-channel-heading healing-value">{t("ui.app.healing")}</h3>
            <div className="breakdown-table breakdown-healing-skill-table breakdown-healing-table">
              <div className="breakdown-table-header">
                <span>{t("ui.app.skill")}</span>
                <span>{t("ui.app.casts")}</span>
                <span>{t("ui.app.triggers")}</span>
                <span>{t("ui.app.heals")}</span>
                <span>{t("system.normal")}</span>
                <span>{t("system.critical")}</span>
                <span>{t("ui.app.healing")}</span>
                <span>{t("ui.app.total")}</span>
              </div>
              {breakdown.healingSkills.map((row) => (
                <div className="breakdown-table-row" key={row.id}>
                  <span>{skillDisplayName(allSkillDefinitions[row.id], row.name, row.id)}</span>
                  <strong>{row.casts || ""}</strong>
                  <strong>{row.triggers || ""}</strong>
                  <strong>{row.heals || ""}</strong>
                  <strong>{formatNumber(row.normalRate)}%</strong>
                  <strong>{formatNumber(row.criticalRate)}%</strong>
                  <strong className="healing-value">+{formatDamageNumber(row.healing)}</strong>
                  <strong>{formatNumber(row.percentage)}%</strong>
                </div>
              ))}
            </div>
          </>
        ) : null}
      </section>
      <section className="panel breakdown-panel">
        <div className="panel-heading">
          <div>
            <h2>{t("ui.app.perCastBreakdown")}</h2>
          </div>
        </div>
        {hasHealing ? <h3 className="breakdown-channel-heading">{t("ui.app.damage")}</h3> : null}
        <div className={`breakdown-table breakdown-cast-table${showDamagePerVitality ? " with-vitality" : ""}`}>
          <div className="breakdown-table-header breakdown-cast-table-header">
            <span>{t("ui.app.skill")}</span>
            <span>{t("ui.app.casts")}</span>
            <span>{t("ui.app.avgCastTime")}</span>
            <span className={`breakdown-damage-header${showDamagePerVitality ? " with-vitality" : ""}`}>
              <span>{t("ui.app.damage")}</span>
              {showDamagePerVitality ? <span>{t("ui.app.perVit")}</span> : null}
              <span>{t("system.dps")}</span>
              <span>{t("ui.app.perCast")}</span>
              <span>{t("ui.app.total")}</span>
            </span>
            <span>{t("ui.app.percentage")}</span>
          </div>
          {castRows.map((row) => {
            const stackBuffComparison =
              allSkillDefinitions[row.skillId]?.tags?.some((tag) => stackedBuffAttributionTags.has(tag)) ?? false;
            return (
              <div className="breakdown-table-row" key={row.id}>
                <span>{skillDisplayName(allSkillDefinitions[row.skillId], row.name, row.skillId)}</span>
                <strong>{row.casts}</strong>
                <strong>
                  {formatNumber(row.averageCastTime)}
                  {t("ui.app.s")}
                </strong>
                {showDamagePerVitality ? (
                  <strong>
                    <CastBreakdownComparison
                      value={row.damagePerVitality}
                      valueWithBuff={row.damagePerVitalityWithBuff}
                      stacked={stackBuffComparison}
                    />
                  </strong>
                ) : null}
                <strong>
                  <CastBreakdownComparison
                    value={row.averageDps}
                    valueWithBuff={row.averageDpsWithBuff}
                    stacked={stackBuffComparison}
                  />
                </strong>
                <strong>
                  <CastBreakdownComparison
                    value={row.averageDamage}
                    valueWithBuff={row.averageDamageWithBuff}
                    stacked={stackBuffComparison}
                  />
                </strong>
                <strong>
                  <CastBreakdownComparison
                    value={row.damage}
                    valueWithBuff={row.damageWithBuff}
                    stacked={stackBuffComparison}
                  />
                </strong>
                <strong>{formatNumber(row.percentage)}%</strong>
              </div>
            );
          })}
        </div>
        {hasHealing ? (
          <>
            <h3 className="breakdown-channel-heading healing-value">{t("ui.app.healing")}</h3>
            <div className="breakdown-table breakdown-healing-cast-table breakdown-healing-table">
              <div className="breakdown-table-header">
                <span>{t("ui.app.skill")}</span>
                <span>{t("ui.app.casts")}</span>
                <span>{t("ui.app.avgCastTime")}</span>
                <span>{t("ui.app.averageHps")}</span>
                <span>{t("ui.app.perCast")}</span>
                <span>{t("ui.app.total")}</span>
                <span>{t("ui.app.percentage")}</span>
              </div>
              {breakdown.healingCasts.map((row) => (
                <div className="breakdown-table-row" key={row.id}>
                  <span>{skillDisplayName(allSkillDefinitions[row.skillId], row.name, row.skillId)}</span>
                  <strong>{row.casts}</strong>
                  <strong>
                    {formatNumber(row.averageCastTime)}
                    {t("ui.app.s")}
                  </strong>
                  <strong className="healing-value">
                    {row.averageHps === undefined ? "—" : formatDamageNumber(row.averageHps)}
                  </strong>
                  <strong className="healing-value">+{formatDamageNumber(row.averageHealing)}</strong>
                  <strong className="healing-value">+{formatDamageNumber(row.healing)}</strong>
                  <strong>{formatNumber(row.percentage)}%</strong>
                </div>
              ))}
            </div>
          </>
        ) : null}
      </section>
      <div className="breakdown-coverage-grid">
        <EffectCoveragePanel title={t("ui.app.buffCoverage")} rows={breakdown.buffCoverage} />
        <EffectCoveragePanel title={t("ui.app.debuffCoverage")} rows={breakdown.debuffCoverage} showTimeCoverage />
      </div>
      <BreakdownGroupTable
        title={t("ui.app.skillTypeBreakdown")}
        rows={breakdown.categories}
        healingRows={breakdown.healingCategories}
      />
      <BreakdownGroupTable
        title={t("ui.app.physicalAndAttributeBreakdown")}
        rows={breakdown.damageTypes}
        healingRows={breakdown.healingTypes}
        colored
      />
    </div>
  );
}

function DamageBreakdownValue({ breakdown, className = "" }: { breakdown: DamageBreakdown; className?: string }) {
  const parts: Array<[keyof DamageBreakdown, string]> = [
    ["physical", "Physical"],
    ["bellstrike", "Bellstrike"],
    ["stonesplit", "Stonesplit"],
    ["silkbind", "Silkbind"],
    ["bamboocut", "Bamboocut"],
  ];
  return (
    <span className={`damage-breakdown-wrap ${className}`}>
      <span>{formatDamageNumber(breakdown.total)}</span>
      <span className="damage-breakdown-tooltip">
        {parts.map(([key, label]) => (
          <span className={`damage-breakdown-part damage-${key}`} key={key}>
            <i>{label}</i>
            {formatDamageNumber(breakdown[key] as number)}
          </span>
        ))}
      </span>
    </span>
  );
}

function HealingBreakdownValue({
  breakdown,
  className = "",
}: {
  breakdown: NonNullable<RotationActionBreakdown["healing"]>;
  className?: string;
}) {
  return (
    <span className={`damage-breakdown-wrap healing-value ${className}`}>
      <span>+{formatDamageNumber(breakdown.total)}</span>
      <span className="damage-breakdown-tooltip">
        <span className="damage-breakdown-part healing-physical">
          <i>{gameText("Physical")}</i>
          {formatDamageNumber(breakdown.physical)}
        </span>
        <span className="damage-breakdown-part healing-silkbind">
          <i>{gameText("Silkbind")}</i>
          {formatDamageNumber(breakdown.silkbind)}
        </span>
      </span>
    </span>
  );
}

function RotationActionBreakdownValue({ breakdown }: { breakdown: RotationActionBreakdown }) {
  return (
    <span className="rotation-action-result">
      {breakdown.total > 0 ? <DamageBreakdownValue breakdown={breakdown} /> : null}
      {breakdown.healing && breakdown.healing.total > 0 ? (
        <HealingBreakdownValue breakdown={breakdown.healing} />
      ) : null}
    </span>
  );
}

function CalculationStatus({
  category,
  className = "",
}: {
  category: RotationCalculationCategory;
  className?: string;
}) {
  const statuses = useSyncExternalStore(
    subscribeToRotationCalculationStatus,
    getRotationCalculationStatus,
    getRotationCalculationStatus,
  );
  const { recalculating, progress } = statuses[category];
  const percentage = Math.round(progress * 100);
  return (
    <div
      className={`calculation-status ${className} ${recalculating ? "" : "idle"}`}
      style={{ "--calculation-progress": `${percentage}%` } as CSSProperties}
      role="progressbar"
      aria-label={t("ui.app.recalculatingProgress", { percentage })}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={recalculating ? percentage : 100}
      aria-live="polite"
    >
      {recalculating ? t("ui.app.recalculatingProgress", { percentage }) : t("ui.app.upToDate")}
    </div>
  );
}

function StatsTab({
  character,
  pathId,
  statOverrides,
  attunementOverrides,
  characterProfiles,
  buildSetupOverrides,
  onStatChange,
  onStatReset,
  onAttunementChange,
  onAttunementReset,
  onApplyCharacterProfile,
  onCharacterProfilesChange,
  onBreakthroughChange,
  onBuildSetupChange,
  onBuildSetupReset,
  rotationMetrics,
  graduationDps,
  activeBuildName,
  activeRotationName,
  onInnerWayChange,
}: {
  character: CharacterState;
  pathId: PathId;
  statOverrides: CharacterStatOverrides;
  attunementOverrides: AttunementOverrides;
  characterProfiles: CharacterProfile[];
  buildSetupOverrides: BuildSetupOverrides;
  onStatChange: (key: keyof CharacterStats, value: number) => void;
  onStatReset: (key: keyof CharacterStats) => void;
  onAttunementChange: (key: keyof AttunementStats, value: number) => void;
  onAttunementReset: (key: keyof AttunementStats) => void;
  onApplyCharacterProfile: (profile?: CharacterProfile) => void;
  onCharacterProfilesChange: (profiles: CharacterProfile[]) => void;
  onBreakthroughChange: (breakthrough: string) => void;
  onBuildSetupChange: <K extends keyof BuildSetup>(key: K, value: BuildSetup[K]) => void;
  onBuildSetupReset: (key: keyof BuildSetup) => void;
  rotationMetrics?: RotationMetrics;
  graduationDps?: number;
  activeBuildName: string;
  activeRotationName: string;
  onInnerWayChange: () => void;
}) {
  const { stats, derivedStats, displayedAttunementStats: attunementStats, buildSetup, settings } = character;
  const showHealingStats = pathId === "silkbindDeluge";
  const breakthrough = breakthroughProfile(settings);
  const [food, setFood] = useState(loadFood);
  const [script, setScript] = useState(loadScript);
  const [divinecraft, setDivinecraft] = useState(loadDivinecraft);
  const [globalDebuffs, setGlobalDebuffs] = useState(loadGlobalDebuffs);
  const [attunementDrafts, setAttunementDrafts] = useState<Partial<Record<keyof AttunementStats, string>>>({});
  const [newProfileName, setNewProfileName] = useState("");
  const profileDialogRef = useRef<HTMLDialogElement>(null);
  const graduationRate =
    rotationMetrics && graduationDps && graduationDps > 0 ? (rotationMetrics.dps / graduationDps) * 100 : undefined;

  useEffect(() => setPersistentItem(foodStorageKey, food), [food]);
  useEffect(() => setPersistentItem(scriptStorageKey, script), [script]);
  useEffect(() => setPersistentItem(divinecraftStorageKey, divinecraft), [divinecraft]);
  useEffect(() => setPersistentItem(globalDebuffStorageKey, JSON.stringify(globalDebuffs)), [globalDebuffs]);

  const { arsenal, bowRingSet, innerWays } = buildSetup;
  const currentProfileData = {
    statOverrides,
    attunementOverrides,
    innerWays,
    buildSetup,
  };
  const matchingProfile = characterProfiles.find((profile) => characterProfileMatches(profile, currentProfileData));
  const isCalculated =
    Object.keys(statOverrides).length === 0 &&
    Object.keys(attunementOverrides).length === 0 &&
    Object.keys(buildSetupOverrides).length === 0;
  const [selectedProfileId, setSelectedProfileId] = useState(() =>
    isCalculated ? "__calculated" : (matchingProfile?.id ?? "__modified"),
  );

  useEffect(() => {
    if (selectedProfileId === "__calculated") {
      if (!isCalculated) setSelectedProfileId("__modified");
      return;
    }
    if (selectedProfileId === "__modified") return;
    const selectedProfile = characterProfiles.find(({ id }) => id === selectedProfileId);
    if (!selectedProfile) {
      setSelectedProfileId(isCalculated ? "__calculated" : "__modified");
      return;
    }
    if (characterProfileMatches(selectedProfile, currentProfileData)) return;
    onCharacterProfilesChange(
      characterProfiles.map((profile) =>
        profile.id === selectedProfileId
          ? {
              ...profile,
              statOverrides: { ...statOverrides },
              attunementOverrides: { ...attunementOverrides },
              innerWays: innerWays.map((row) => ({ ...row })),
              buildSetup: {
                ...buildSetup,
                innerWays: innerWays.map((row) => ({ ...row })),
                weaponSets: { ...buildSetup.weaponSets },
                armorSets: { ...buildSetup.armorSets },
              },
            }
          : profile,
      ),
    );
  }, [
    attunementOverrides,
    buildSetup,
    characterProfiles,
    innerWays,
    isCalculated,
    onCharacterProfilesChange,
    selectedProfileId,
    statOverrides,
  ]);

  function applyProfile(profile?: CharacterProfile) {
    setAttunementDrafts({});
    onApplyCharacterProfile(profile);
    onInnerWayChange();
  }

  function selectProfile(profile?: CharacterProfile) {
    setSelectedProfileId(profile?.id ?? "__calculated");
    applyProfile(profile);
  }

  function createProfile() {
    const name = newProfileName.trim();
    if (!name) return;
    const usedIds = new Set(characterProfiles.map(({ id }) => id));
    const baseId = `character-profile-${Date.now()}`;
    let id = baseId;
    let suffix = 2;
    while (usedIds.has(id)) id = `${baseId}-${suffix++}`;
    onCharacterProfilesChange([
      ...characterProfiles,
      {
        id,
        name,
        statOverrides: { ...statOverrides },
        attunementOverrides: { ...attunementOverrides },
        innerWays: innerWays.map((row) => ({ ...row })),
        buildSetup: {
          ...buildSetup,
          innerWays: innerWays.map((row) => ({ ...row })),
          weaponSets: { ...buildSetup.weaponSets },
          armorSets: { ...buildSetup.armorSets },
        },
      },
    ]);
    setSelectedProfileId(id);
    setNewProfileName("");
    publishNotice({ id: "profile-transfer", message: t("ui.app.profileSaved", { name }) });
  }

  function exportProfiles() {
    const blob = new Blob([exportCharacterProfiles(characterProfiles)], { type: "application/json" });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    link.download = `where-builds-meet-character-profiles-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(href);
    publishNotice({
      id: "profile-transfer",
      message: t("ui.app.profilesExported", { count: characterProfiles.length }),
    });
  }

  async function importProfiles(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    try {
      const result = mergeImportedCharacterProfiles(characterProfiles, JSON.parse(await file.text()));
      onCharacterProfilesChange(result.profiles);
      publishNotice({ id: "profile-transfer", message: t("ui.app.profilesImported", { count: result.importedCount }) });
    } catch (error) {
      publishNotice({
        id: "profile-transfer",
        message: error instanceof Error ? error.message : t("ui.app.profileImportError"),
        error: true,
      });
    }
  }

  function updateStat(key: keyof CharacterStats, value: number) {
    onStatChange(key, Number.isFinite(value) ? value : 0);
  }

  function commitAttunement(key: keyof AttunementStats, rawValue: string) {
    const displayedValue = Number(rawValue);
    const normalizedValue = Number.isFinite(displayedValue) ? displayedValue : 0;
    const nextValue = percentageAttunementKeys.has(key) ? normalizedValue / 100 : normalizedValue;
    setAttunementDrafts((current) => {
      const next = { ...current };
      delete next[key];
      return next;
    });
    onAttunementChange(key, nextValue);
  }

  function resetAttunement(key: keyof AttunementStats) {
    setAttunementDrafts((current) => {
      const next = { ...current };
      delete next[key];
      return next;
    });
    onAttunementReset(key);
  }

  function updateGlobalDebuff<K extends keyof GlobalDebuffState>(key: K, value: GlobalDebuffState[K]) {
    const next = { ...globalDebuffs, [key]: value };
    setPersistentItem(globalDebuffStorageKey, JSON.stringify(next));
    setGlobalDebuffs(next);
    onInnerWayChange();
  }

  function CalculatedStatField({
    definition,
    derivedLabel,
    derivedValue,
    derivedUnit,
    compact,
  }: {
    definition: StatDefinition;
    derivedLabel?: string;
    derivedValue?: number;
    derivedUnit?: string;
    compact?: boolean;
  }) {
    return (
      <StatField
        definition={definition}
        stats={stats}
        onChange={updateStat}
        modified={Object.prototype.hasOwnProperty.call(statOverrides, definition.key)}
        onReset={() => onStatReset(definition.key)}
        derivedLabel={derivedLabel}
        derivedValue={derivedValue}
        derivedUnit={derivedUnit}
        compact={compact}
      />
    );
  }

  const physicalRows = [
    [statDefinition("minPhys"), statDefinition("maxPhys")],
    [statDefinition("power"), statDefinition("agility")],
    [statDefinition("momentum"), statDefinition("precision")],
    [statDefinition("crit"), statDefinition("directCrit")],
    [statDefinition("affinity"), statDefinition("directAffinity")],
  ];
  const bodyStat = statDefinition("body");
  const defenseStat = statDefinition("defense");
  const maxHpStat = statDefinition("maxHp");
  const physicalDefenseStat = statDefinition("physicalDefense");
  const martialRows = [
    [statDefinition("minBellstrike"), statDefinition("maxBellstrike")],
    [statDefinition("minStonesplit"), statDefinition("maxStonesplit")],
    [statDefinition("minSilkbind"), statDefinition("maxSilkbind")],
    [statDefinition("minBamboocut"), statDefinition("maxBamboocut")],
  ];
  const selectedArtStats = Array.from(
    new Set(settings.weapons.map((weapon) => artStatByWeaponFamily[martialArtDefinitions[weapon].weapon])),
  ).map(statDefinition);
  const penetrationRows = [
    [statDefinition("bellstrikePenetration"), statDefinition("silkbindPenetration")],
    [statDefinition("stonesplitPenetration"), statDefinition("bamboocutPenetration")],
  ];
  const innerWayOptions = [
    ["", t("ui.app.none")],
    ...innerWayEntriesForTag(typedPathDefinitions[pathId].tag).map(
      ([value, definition]) =>
        [value, dataText(`system.innerWay.${value.charAt(0).toLowerCase()}${value.slice(1)}`, definition.name)] as [
          string,
          string,
        ],
    ),
  ];
  const attunementFields = Object.entries(attunementData)
    .filter(([key]) => attunementAvailableForSettings(key, pathId, settings))
    .map(
      ([key, definition]) =>
        [
          key as keyof AttunementStats,
          dataText(`system.attunement.${key}`, definition.name),
          definition.percentage ? "%" : "",
        ] as const,
    );
  const armorAttunementStart = attunementFields.findIndex(([key]) => attunementData[key]?.tags.includes("Armor"));
  const availableWeaponSets = availableSetEntriesForSettings(typedWeaponSetDefinitions, settings, pathId);
  const availableArmorSets = availableSetEntriesForSettings(typedArmorSetDefinitions, settings, pathId);
  const setupStatus = (group: string, value: string, active: boolean) => {
    if (active) return <small className="setup-active-label">{t("ui.app.active")}</small>;
    const comparison = rotationMetrics?.setupComparisons[group]?.find((row) => row.label === value);
    return comparison ? (
      <small className="setup-delta-label">
        <span className={throughputDeltaClass(comparison.dpsDifference, "damage")}>
          {deltaPrefix(comparison.dpsDifference)}
          {formatDelta(comparison.dpsDifference)} {t("system.dps")}
        </span>
        <span className={throughputDeltaClass(comparison.increase, "damage")}>
          ({deltaPrefix(comparison.increase)}
          {formatDelta(comparison.increase)}%)
        </span>
        {rotationMetrics && rotationMetrics.hps > 0 ? (
          <>
            <span className={throughputDeltaClass(comparison.hpsDifference, "healing")}>
              {deltaPrefix(comparison.hpsDifference)}
              {formatDelta(comparison.hpsDifference)} {t("system.hps")}
            </span>
            <span className={throughputDeltaClass(comparison.healingIncrease, "healing")}>
              ({deltaPrefix(comparison.healingIncrease)}
              {formatDelta(comparison.healingIncrease)}%)
            </span>
          </>
        ) : null}
      </small>
    ) : (
      <small className="setup-inactive-label">—</small>
    );
  };
  const setPanel = (
    title: string,
    key: "weaponSets" | "armorSets",
    definitions: Record<string, GearSetDefinition>,
    entries: Array<[string, GearSetDefinition]>,
  ) => (
    <section className="panel setup-placeholder-panel">
      <div className="panel-heading">
        <div>
          <h2>{title}</h2>
          <CalculationStatus category={key} />
        </div>
        {buildSetupOverrides[key] && (
          <button
            className="stat-reset-button"
            type="button"
            aria-label={t("ui.app.resetNamedValue", { name: title })}
            title={t("ui.app.resetToBuildValue")}
            onClick={() => onBuildSetupReset(key)}
          >
            <UiIcon name="reset" />
          </button>
        )}
      </div>
      <div className="gear-set-list">
        {entries.map(([setName, definition]) => {
          const selectedTier = buildSetup[key][setName] ?? 0;
          return (
            <div className="setup-field" key={setName}>
              <span>{gameText(definition.name)}</span>
              <div className="setup-option-control">
                <div className="setup-option-list">
                  {[0, 2, 4].map((tier) => (
                    <button
                      className={selectedTier === tier ? "selected" : ""}
                      type="button"
                      key={tier}
                      onClick={() =>
                        onBuildSetupChange(key, selectSetTier(buildSetup[key], setName, tier as 0 | 2 | 4, definitions))
                      }
                    >
                      {t(`system.setPieces.${tier}`)}
                      <span>{setupStatus(`${key}:${setName}`, String(tier), selectedTier === tier)}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
  const globalDebuffOption = (key: (typeof globalDebuffRows)[number]["key"], value: boolean, label: string) => {
    const active = globalDebuffs[key] === value;
    const optionValue = value ? "on" : "off";
    return (
      <button
        className={active ? "selected" : ""}
        type="button"
        key={optionValue}
        onClick={() => updateGlobalDebuff(key, value)}
      >
        {label}
        <span>{setupStatus(`debuff:${key}`, optionValue, active)}</span>
      </button>
    );
  };
  const floatingGraceOptionLabel = (value: GlobalDebuffState["floatingGrace"]) => {
    switch (value) {
      case "none":
        return t("ui.app.none");
      case "mixed":
        return t("data.path.mixed.name");
      case "deluge":
        return t("system.path.deluge");
    }
  };

  return (
    <>
      <div className="app-layout">
        <div className="character-stats-column">
          <section className="panel stats-panel">
            <div className="panel-heading character-stats-heading">
              <div>
                <h2>{t("ui.app.characterStats")}</h2>
              </div>
              <div className="character-profile-controls">
                <select
                  aria-label={t("ui.app.characterProfile")}
                  value={selectedProfileId}
                  onChange={(event) => {
                    if (event.target.value === "__calculated") selectProfile();
                    else selectProfile(characterProfiles.find(({ id }) => id === event.target.value));
                  }}
                >
                  <option value="__calculated">{t("ui.app.calculated")}</option>
                  {selectedProfileId === "__modified" && (
                    <option value="__modified" disabled>
                      {t("ui.app.unsavedChanges")}
                    </option>
                  )}
                  {characterProfiles.map((profile) => (
                    <option value={profile.id} key={profile.id}>
                      {profile.name}
                    </option>
                  ))}
                </select>
                <button
                  className="button button-secondary"
                  type="button"
                  onClick={() => {
                    dismissNotice("profile-transfer");
                    profileDialogRef.current?.showModal();
                  }}
                >
                  {t("ui.app.profiles")}
                </button>
                <button className="button button-secondary" type="button" onClick={() => selectProfile()}>
                  {t("ui.app.reset")}
                </button>
              </div>
            </div>
            <div className="stats-grid">
              {physicalRows.map(([left, right], index) => (
                <div className="stat-row" key={left.key}>
                  <CalculatedStatField
                    definition={left}
                    derivedLabel={
                      index === 0
                        ? t("ui.app.effectiveMinAttack", { name: t("system.damageType.physical") })
                        : index === 3
                          ? t("ui.app.effectiveCritical")
                          : index === 4
                            ? t("ui.app.effectiveAffinity")
                            : undefined
                    }
                    derivedValue={
                      index === 0
                        ? derivedStats.effectiveMinPhys
                        : index === 3
                          ? derivedStats.effectiveCrit * 100
                          : index === 4
                            ? derivedStats.effectiveAffinity * 100
                            : undefined
                    }
                    derivedUnit={index === 3 || index === 4 ? "%" : undefined}
                  />
                  <CalculatedStatField
                    definition={right}
                    derivedLabel={
                      index === 0
                        ? t("ui.app.effectiveMaxAttack", { name: t("system.damageType.physical") })
                        : index === 2
                          ? t("ui.app.effectivePrecision")
                          : index === 3
                            ? t("ui.app.finalCritical")
                            : index === 4
                              ? t("ui.app.finalAffinity")
                              : undefined
                    }
                    derivedValue={
                      index === 0
                        ? derivedStats.effectiveMaxPhys
                        : index === 2
                          ? derivedStats.effectivePrecision * 100
                          : index === 3
                            ? derivedStats.finalCrit * 100
                            : index === 4
                              ? derivedStats.finalAffinity * 100
                              : undefined
                    }
                    derivedUnit={index === 2 || index === 3 || index === 4 ? "%" : undefined}
                  />
                </div>
              ))}
              {martialRows.map(([left, right], index) => (
                <div className="stat-row" key={left.key}>
                  <CalculatedStatField
                    definition={left}
                    derivedLabel={t("ui.app.effectiveMinAttack", {
                      name: t(`system.damageType.${["bellstrike", "stonesplit", "silkbind", "bamboocut"][index]}`),
                    })}
                    derivedValue={
                      derivedStats[
                        [
                          "effectiveMinBellstrike",
                          "effectiveMinStonesplit",
                          "effectiveMinSilkbind",
                          "effectiveMinBamboocut",
                        ][index] as keyof typeof derivedStats
                      ] as number
                    }
                  />
                  <CalculatedStatField
                    definition={right}
                    derivedLabel={t("ui.app.effectiveMaxAttack", {
                      name: t(`system.damageType.${["bellstrike", "stonesplit", "silkbind", "bamboocut"][index]}`),
                    })}
                    derivedValue={
                      derivedStats[
                        [
                          "effectiveMaxBellstrike",
                          "effectiveMaxStonesplit",
                          "effectiveMaxSilkbind",
                          "effectiveMaxBamboocut",
                        ][index] as keyof typeof derivedStats
                      ] as number
                    }
                  />
                </div>
              ))}
              <div className="stat-row">
                <CalculatedStatField definition={statDefinition("minVoidAttack")} compact />
                <CalculatedStatField definition={statDefinition("maxVoidAttack")} compact />
              </div>
              {penetrationRows.map(([left, right]) => (
                <div className="stat-row" key={left.key}>
                  <CalculatedStatField definition={left} compact />
                  <CalculatedStatField definition={right} compact />
                </div>
              ))}
              <div className="stat-row">
                <CalculatedStatField
                  definition={statDefinition("critDmgBonus")}
                  derivedLabel={t("ui.app.effectiveNamedStat", {
                    name: gameText(statDefinition("critDmgBonus").label),
                  })}
                  derivedValue={derivedStats.effectiveCritDmgBonus * 100}
                  derivedUnit="%"
                  compact
                />
                <CalculatedStatField definition={statDefinition("affinityDmgBonus")} compact />
              </div>
              <div className="stat-row">
                <CalculatedStatField definition={statDefinition("physDmgBonus")} compact />
                <CalculatedStatField definition={statDefinition("bellstrikeDmgBonus")} compact />
              </div>
              <div className="stat-row">
                <CalculatedStatField definition={statDefinition("stonesplitDmgBonus")} compact />
                <CalculatedStatField definition={statDefinition("bamboocutDmgBonus")} compact />
              </div>
              <div className="stat-row">
                <CalculatedStatField definition={statDefinition("silkbindDmgBonus")} compact />
                <span />
              </div>
              <div className="stat-row">
                <CalculatedStatField definition={statDefinition("allMartialArts")} compact />
                <CalculatedStatField definition={statDefinition("vsBossDmg")} compact />
              </div>
              <div className="stat-row">
                {selectedArtStats.map((definition) => (
                  <CalculatedStatField definition={definition} compact key={definition.key} />
                ))}
                {selectedArtStats.length === 1 && <span />}
              </div>
              <div className="stat-row">
                <CalculatedStatField definition={statDefinition("singleTargetMysticDmgBoost")} compact />
                <CalculatedStatField definition={statDefinition("areaMysticDmgBoost")} compact />
              </div>
              {showHealingStats ? (
                <div className="stat-row">
                  <CalculatedStatField definition={statDefinition("criticalHealingBonus")} compact />
                  <CalculatedStatField definition={statDefinition("silkbindHealingBonus")} compact />
                </div>
              ) : null}
              <div className="stat-row">
                <CalculatedStatField definition={maxHpStat} compact />
                <CalculatedStatField definition={bodyStat} compact />
              </div>
              <div className="stat-row">
                <CalculatedStatField definition={physicalDefenseStat} compact />
                <CalculatedStatField definition={defenseStat} compact />
              </div>
            </div>
          </section>
          <div className="character-secondary-stats">
            <section className="panel attunement-panel">
              <div className="panel-heading">
                <div>
                  <h2>{t("ui.app.attunementStats")}</h2>
                  <CalculationStatus category="attunementPriority" />
                </div>
              </div>
              <div className="attunement-list">
                {attunementFields.map(([key, label, unit], index) => (
                  <label
                    className={`attunement-field ${index === armorAttunementStart ? "attunement-section-start" : ""} ${Object.prototype.hasOwnProperty.call(attunementOverrides, key) ? "modified-field" : ""}`}
                    key={key}
                  >
                    <span className="attunement-label">
                      <span>{label}</span>
                      {Object.prototype.hasOwnProperty.call(attunementOverrides, key) && (
                        <button
                          className="stat-reset-button"
                          type="button"
                          aria-label={t("ui.app.resetNamedValue", { name: label })}
                          title={t("ui.app.resetToCalculatedValue")}
                          onClick={(event) => {
                            event.preventDefault();
                            resetAttunement(key);
                          }}
                        >
                          <UiIcon name="reset" />
                        </button>
                      )}
                    </span>
                    <span className="attunement-input-wrap">
                      <input
                        type="number"
                        step="0.01"
                        value={
                          attunementDrafts[key] ??
                          formatNumber(unit ? attunementStats[key] * 100 : attunementStats[key])
                        }
                        onChange={(event) =>
                          setAttunementDrafts((current) => ({ ...current, [key]: event.target.value }))
                        }
                        onBlur={(event) => {
                          if (attunementDrafts[key] !== undefined) commitAttunement(key, event.currentTarget.value);
                        }}
                        onKeyDown={(event) => {
                          if (event.key === "Enter") event.currentTarget.blur();
                        }}
                      />
                      {unit && <i>{unit}</i>}
                    </span>
                  </label>
                ))}
              </div>
            </section>
            <section className="panel global-debuff-panel">
              <div className="panel-heading">
                <div>
                  <h2>{t("ui.app.globalBuffsDebuffs")}</h2>
                  <CalculationStatus category="globalDebuffs" />
                </div>
              </div>
              <div className="global-debuff-list">
                {globalDebuffRows.map(({ key, name, path }) => (
                  <div className="global-debuff-row" key={key}>
                    <span>
                      {gameText(name)} ({gameText(path)})
                    </span>
                    <div className="setup-option-list global-debuff-options">
                      {globalDebuffOption(key, false, t("ui.app.off"))}
                      {globalDebuffOption(key, true, t("ui.app.on"))}
                    </div>
                  </div>
                ))}
                <div className="global-debuff-row">
                  <span>
                    {gameText("Floating Grace")} ({t("system.path.deluge")})
                  </span>
                  <div className="setup-option-list global-debuff-options qingyi-options">
                    {(["none", "mixed", "deluge"] as const).map((value) => {
                      const active = globalDebuffs.floatingGrace === value;
                      return (
                        <button
                          className={active ? "selected" : ""}
                          type="button"
                          key={value}
                          onClick={() => updateGlobalDebuff("floatingGrace", value)}
                        >
                          {floatingGraceOptionLabel(value)}
                          <span>{setupStatus("buff:floatingGrace", value, active)}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
                <div className="global-debuff-row">
                  <span>{t("system.innerWay.bitterSeasons")}</span>
                  <div className="setup-option-list global-debuff-options qingyi-options">
                    {(["none", "T1", "T6"] as const).map((value) => {
                      const active = globalDebuffs.qingyisCharm === value;
                      return (
                        <button
                          className={active ? "selected" : ""}
                          type="button"
                          key={value}
                          onClick={() => updateGlobalDebuff("qingyisCharm", value)}
                        >
                          {value === "none" ? t("ui.app.none") : value}
                          <span>{setupStatus("debuff:qingyisCharm", value, active)}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
        <section className="middle-stats-column">
          <section className="panel breakthrough-panel">
            <div className="panel-heading breakthrough-heading">
              <div className="breakthrough-title">
                <h2>{t("ui.app.breakthrough")}</h2>
                <span className="breakthrough-detail-trigger">
                  <button
                    className="breakthrough-detail-mark"
                    type="button"
                    aria-label={t("ui.app.breakthroughDetails")}
                    aria-describedby="breakthrough-details"
                  >
                    !
                  </button>
                  <span className="breakthrough-detail-tooltip" id="breakthrough-details" role="tooltip">
                    <span>
                      {t("ui.app.precision")} {formatNumber(breakthrough.levelBonusStats.rawStat.precision * 100)}%
                    </span>
                    <span>
                      {t("ui.app.baseAttributes")} {breakthrough.levelBonusStats.rawStat.agility}
                    </span>
                    <span>
                      {t("ui.app.gearTier")} {breakthrough.level}
                    </span>
                    <span>
                      {t("ui.app.defense")} {breakthrough.defense}
                    </span>
                    <span>
                      {t("ui.app.physicalResistance")} {breakthrough.physicalResistance}
                    </span>
                    <span>
                      {t("ui.app.attributeResistance")} {breakthrough.bellstrikeResistance}
                    </span>
                    <span>
                      {t("ui.app.judgementResistance")} {formatNumber(breakthrough.judgementResistance * 100)}%
                    </span>
                  </span>
                </span>
              </div>
              <label className="editor-field breakthrough-control">
                <span className="visually-hidden">{t("ui.app.breakthrough")}</span>
                <select value={settings.breakthrough} onChange={(event) => onBreakthroughChange(event.target.value)}>
                  {Object.keys(typedBreakthroughProfiles).map((key) => (
                    <option key={key} value={key}>
                      {key}
                    </option>
                  ))}
                </select>
              </label>
            </div>
          </section>
          <section className="panel inner-way-panel">
            <div className="panel-heading">
              <div>
                <h2>{t("ui.app.innerWays")}</h2>
              </div>
              {buildSetupOverrides.innerWays && (
                <button
                  className="stat-reset-button"
                  type="button"
                  aria-label={t("ui.app.resetInnerWays")}
                  title={t("ui.app.resetToBuildValue")}
                  onClick={() => onBuildSetupReset("innerWays")}
                >
                  <UiIcon name="reset" />
                </button>
              )}
            </div>
            <div className="inner-way-list">
              {innerWays.map((row, index) => (
                <div className="inner-way-row" key={index}>
                  <select
                    aria-label={t("ui.app.innerWayNumber", { number: index + 1 })}
                    value={innerWayAvailableForPath(row.innerWay, pathId) ? row.innerWay : ""}
                    onChange={(event) => {
                      const next = innerWays.map((item, itemIndex) =>
                        itemIndex === index ? { ...item, innerWay: event.target.value } : item,
                      );
                      onBuildSetupChange("innerWays", next);
                      onInnerWayChange();
                    }}
                  >
                    {innerWayOptions.map(([value, label]) => (
                      <option
                        key={value}
                        value={value}
                        disabled={
                          Boolean(value) &&
                          innerWays.some((item, itemIndex) => itemIndex !== index && item.innerWay === value)
                        }
                      >
                        {label}
                      </option>
                    ))}
                  </select>
                  <select
                    aria-label={t("ui.app.innerWayTierNumber", { number: index + 1 })}
                    value={row.tier}
                    onChange={(event) => {
                      const next = innerWays.map((item, itemIndex) =>
                        itemIndex === index ? { ...item, tier: event.target.value } : item,
                      );
                      onBuildSetupChange("innerWays", next);
                      onInnerWayChange();
                    }}
                  >
                    {Array.from({ length: 7 }, (_, tier) => (
                      <option value={`T${tier}`} key={tier}>{`T${tier}`}</option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          </section>
          {setPanel(t("ui.app.weaponSet"), "weaponSets", typedWeaponSetDefinitions, availableWeaponSets)}
          {availableArmorSets.length > 0 &&
            setPanel(t("ui.app.armorSet"), "armorSets", typedArmorSetDefinitions, availableArmorSets)}
          <section className="panel setup-placeholder-panel bow-ring-panel">
            <div className="panel-heading">
              <div>
                <h2>{t("ui.app.bowRingSet")}</h2>
                <CalculationStatus category="bowRingSet" />
              </div>
              {buildSetupOverrides.bowRingSet !== undefined && (
                <button
                  className="stat-reset-button"
                  type="button"
                  aria-label={t("ui.app.resetBowRingSet")}
                  title={t("ui.app.resetToBuildValue")}
                  onClick={() => onBuildSetupReset("bowRingSet")}
                >
                  <UiIcon name="reset" />
                </button>
              )}
            </div>
            <div className="setup-option-list setup-option-list-wide bow-ring-option-list">
              {Object.entries(typedBowRingSetDefinitions).map(([value, definition]) => (
                <button
                  className={bowRingSet === value ? "selected" : ""}
                  type="button"
                  key={value}
                  onClick={() => onBuildSetupChange("bowRingSet", value)}
                >
                  {gameText(definition.name)}
                  <span>{setupStatus("bowRingSet", value, bowRingSet === value)}</span>
                </button>
              ))}
            </div>
          </section>
          <section className="panel setup-placeholder-panel">
            <div className="panel-heading">
              <div>
                <h2>{t("ui.app.arsenal")}</h2>
                <CalculationStatus category="arsenal" />
              </div>
              {buildSetupOverrides.arsenal !== undefined && (
                <button
                  className="stat-reset-button"
                  type="button"
                  aria-label={t("ui.app.resetArsenal")}
                  title={t("ui.app.resetToBuildValue")}
                  onClick={() => onBuildSetupReset("arsenal")}
                >
                  <UiIcon name="reset" />
                </button>
              )}
            </div>
            <div className="setup-option-list setup-option-list-arsenal">
              {Object.entries(typedArsenalDefinitions).map(([value, definition]) => (
                <button
                  className={arsenal === value ? "selected" : ""}
                  type="button"
                  key={value}
                  onClick={() => onBuildSetupChange("arsenal", value)}
                >
                  {gameText(definition.name)}
                  <span>{setupStatus("arsenal", value, arsenal === value)}</span>
                </button>
              ))}
            </div>
          </section>
          <section className="panel setup-placeholder-panel">
            <div className="panel-heading">
              <div>
                <h2>{t("ui.app.food")}</h2>
                <CalculationStatus category="food" />
              </div>
            </div>
            <div className="setup-option-list setup-option-list-food">
              {Object.entries(typedFoodDefinitions).map(([value, definition]) => (
                <button
                  className={food === value ? "selected" : ""}
                  type="button"
                  key={value}
                  onClick={() => {
                    setFood(value);
                    setPersistentItem(foodStorageKey, value);
                    onInnerWayChange();
                  }}
                >
                  {gameText(definition.name)}
                  <span>{setupStatus("food", value, food === value)}</span>
                </button>
              ))}
            </div>
          </section>
          <section className="panel setup-placeholder-panel">
            <div className="panel-heading">
              <div>
                <h2>{t("ui.app.script")}</h2>
                <CalculationStatus category="script" />
              </div>
            </div>
            <div className="script-option-list">
              {scriptDisplayOrder.map((value) => {
                const definition = typedScriptDefinitions[value];
                if (!definition) return null;
                return (
                  <button
                    className={`script-option ${script === value ? "selected" : ""}`}
                    type="button"
                    key={value}
                    title={`${gameText(definition.name)}: ${gameText(definition.description)}`}
                    onClick={() => {
                      setScript(value);
                      setPersistentItem(scriptStorageKey, value);
                      onInnerWayChange();
                    }}
                  >
                    <span className="script-image-frame">
                      {definition.image ? (
                        <img src={`${import.meta.env.BASE_URL}script/${definition.image}`} alt="" />
                      ) : (
                        <span className="script-none-mark" aria-hidden="true" />
                      )}
                    </span>
                    <strong>{gameText(definition.name)}</strong>
                    <span className="script-option-status">{setupStatus("script", value, script === value)}</span>
                  </button>
                );
              })}
            </div>
          </section>
          <section className="panel setup-placeholder-panel divinecraft-panel">
            <div className="panel-heading">
              <div>
                <h2>{t("ui.app.divinecraft")}</h2>
                <CalculationStatus category="divinecraft" />
              </div>
            </div>
            <div className="divinecraft-option-list">
              {divinecraftDisplayOrder.map((value, index) => {
                if (value === null)
                  return <span className="divinecraft-option-spacer" aria-hidden="true" key={`spacer-${index}`} />;
                const definition = typedDivinecraftDefinitions[value];
                if (!definition) return null;
                const available = definition.available !== false;
                return (
                  <button
                    className={`divinecraft-option ${divinecraft === value ? "selected" : ""}`}
                    type="button"
                    key={value}
                    disabled={!available}
                    title={`${gameText(definition.name)}: ${gameText(definition.description)}${available ? "" : t("ui.app.notAvailableYet")}`}
                    onClick={() => {
                      setDivinecraft(value);
                      setPersistentItem(divinecraftStorageKey, value);
                      onInnerWayChange();
                    }}
                  >
                    <span className="divinecraft-image-frame">
                      {definition.image ? (
                        <img src={`${import.meta.env.BASE_URL}divinecraft/${definition.image}`} alt="" />
                      ) : (
                        <span className="divinecraft-none-mark" aria-hidden="true" />
                      )}
                    </span>
                    <strong>{gameText(definition.name)}</strong>
                    <span className="divinecraft-option-status">
                      {available ? (
                        setupStatus("divinecraft", value, divinecraft === value)
                      ) : (
                        <small>{t("ui.app.divinecraftUnavailableBadge")}</small>
                      )}
                    </span>
                  </button>
                );
              })}
            </div>
          </section>
        </section>
        <aside
          className={`results-column ${rotationMetrics && rotationMetrics.hps > 0 ? "results-column-with-healing" : ""}`}
        >
          <section className="panel dps-panel">
            <div className="panel-heading">
              <div>
                <h2>
                  {t("system.dps")}
                  {rotationMetrics && rotationMetrics.hps > 0 ? (
                    <>
                      {" / "}
                      <span className="healing-value">{t("system.hps")}</span>
                    </>
                  ) : null}
                </h2>
              </div>
              <div className="graduation-rate">
                <span>{t("ui.app.graduationRate")}</span>
                <strong>{graduationRate === undefined ? "—" : `${formatNumber(graduationRate)}%`}</strong>
                <span className="breakthrough-detail-trigger">
                  <button
                    className="breakthrough-detail-mark"
                    type="button"
                    aria-label={t("ui.app.graduationRateDetails")}
                    aria-describedby="graduation-rate-details"
                  >
                    !
                  </button>
                  <span
                    className="breakthrough-detail-tooltip graduation-rate-tooltip"
                    id="graduation-rate-details"
                    role="tooltip"
                  >
                    {t("ui.app.graduationRateDescription")}
                  </span>
                </span>
              </div>
            </div>
            <div className="dps-value">
              {rotationMetrics ? (
                <>
                  <span>{formatNumber(rotationMetrics.dps)}</span>
                  {rotationMetrics.hps > 0 ? (
                    <>
                      <span className="throughput-separator">/</span>
                      <span className="healing-value">{formatNumber(rotationMetrics.hps)}</span>
                    </>
                  ) : null}
                </>
              ) : (
                "—"
              )}
            </div>
            {rotationMetrics?.expectedHawkwingStacks !== undefined ? (
              <div className="dps-secondary-metric">
                <span>{t("ui.app.expectedHawkwingStacks")}</span>
                <strong>{formatNumber(rotationMetrics.expectedHawkwingStacks)}</strong>
              </div>
            ) : null}
            <CalculationStatus category="baseline" className="dps-calculation-status" />
            <div className="dps-context">
              <div>
                <span>{t("ui.app.build")}</span>
                <strong title={activeBuildName}>{activeBuildName}</strong>
              </div>
              <div>
                <span>{t("ui.app.rotation")}</span>
                <strong title={activeRotationName}>{activeRotationName}</strong>
              </div>
            </div>
          </section>
          <PriorityPanel
            title={t("ui.app.statsPriority")}
            rows={rotationMetrics?.statPriority ?? []}
            calculationCategory="statPriority"
            showMaxRoll
            showHealing={Boolean(rotationMetrics && rotationMetrics.hps > 0)}
          />
          <PriorityPanel
            title={t("ui.app.attunementStatsPriority")}
            rows={rotationMetrics?.attunementPriority ?? []}
            calculationCategory="attunementPriority"
            sectionBreakAt={2}
            showMaxRoll
            showHealing={Boolean(rotationMetrics && rotationMetrics.hps > 0)}
          />
          <PriorityPanel
            title={t("ui.app.innerWaysPriority")}
            rows={rotationMetrics?.innerWayPriority ?? []}
            calculationCategory="innerWays"
            showHealing={Boolean(rotationMetrics && rotationMetrics.hps > 0)}
          />
        </aside>
      </div>
      <dialog className="character-profile-dialog" ref={profileDialogRef}>
        <div className="character-profile-dialog-heading">
          <div>
            <h2>{t("ui.app.characterProfiles")}</h2>
            <p>{t("ui.app.profilesSaveModifiedStatsAndTheCompleteMain")}</p>
          </div>
          <button
            className="icon-button"
            type="button"
            aria-label={t("ui.app.closeCharacterProfiles")}
            onClick={() => profileDialogRef.current?.close()}
          >
            <UiIcon name="close" />
          </button>
        </div>
        <div className="character-profile-create">
          <input
            value={newProfileName}
            placeholder={t("ui.app.profileName")}
            aria-label={t("ui.app.newCharacterProfileName")}
            onChange={(event) => setNewProfileName(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") createProfile();
            }}
          />
          <button
            className="button button-primary"
            type="button"
            disabled={!newProfileName.trim()}
            onClick={createProfile}
          >
            {t("ui.app.saveCurrent")}
          </button>
        </div>
        <div className="character-profile-list">
          <div className="character-profile-row calculated-profile-row">
            <strong>{t("ui.app.calculated")}</strong>
            <button
              className="button button-secondary button-small"
              type="button"
              onClick={() => {
                selectProfile();
                profileDialogRef.current?.close();
              }}
            >
              {t("ui.app.load")}
            </button>
          </div>
          {characterProfiles.map((profile) => (
            <div className="character-profile-row" key={profile.id}>
              <input
                defaultValue={profile.name}
                aria-label={t("ui.app.renameNamedProfile", { name: profile.name })}
                onBlur={(event) => {
                  const name = event.currentTarget.value.trim();
                  if (!name) {
                    event.currentTarget.value = profile.name;
                    return;
                  }
                  if (name !== profile.name)
                    onCharacterProfilesChange(
                      characterProfiles.map((candidate) =>
                        candidate.id === profile.id ? { ...candidate, name } : candidate,
                      ),
                    );
                }}
              />
              <div>
                <button
                  className="button button-secondary button-small"
                  type="button"
                  onClick={() => {
                    selectProfile(profile);
                    profileDialogRef.current?.close();
                  }}
                >
                  {t("ui.app.load")}
                </button>
                <button
                  className="button button-secondary button-small"
                  type="button"
                  onClick={() => {
                    const usedIds = new Set(characterProfiles.map(({ id }) => id));
                    const baseId = `${profile.id}:copy`;
                    let id = baseId;
                    let suffix = 2;
                    while (usedIds.has(id)) id = `${baseId}:${suffix++}`;
                    onCharacterProfilesChange([
                      ...characterProfiles,
                      {
                        ...profile,
                        id,
                        name: `${profile.name} Copy`,
                        statOverrides: { ...profile.statOverrides },
                        attunementOverrides: { ...profile.attunementOverrides },
                        innerWays: profile.innerWays.map((row) => ({ ...row })),
                        buildSetup: {
                          ...profile.buildSetup,
                          innerWays: profile.innerWays.map((row) => ({ ...row })),
                          weaponSets: { ...profile.buildSetup.weaponSets },
                          armorSets: { ...profile.buildSetup.armorSets },
                        },
                      },
                    ]);
                  }}
                >
                  {t("ui.app.duplicate")}
                </button>
                <button
                  className="button button-danger button-small"
                  type="button"
                  onClick={() => onCharacterProfilesChange(characterProfiles.filter(({ id }) => id !== profile.id))}
                >
                  {t("ui.app.delete")}
                </button>
              </div>
            </div>
          ))}
        </div>
        <div className="character-profile-transfer">
          <div>
            <button
              className="button button-secondary button-small"
              type="button"
              disabled={characterProfiles.length === 0}
              onClick={exportProfiles}
            >
              {t("ui.app.export")}
            </button>
            <label className="button button-secondary button-small character-profile-import">
              {t("ui.app.import")}
              <input
                type="file"
                accept="application/json,.json"
                aria-label={t("ui.app.importCharacterProfiles")}
                onChange={importProfiles}
              />
            </label>
          </div>
          <button className="button button-primary" type="button" onClick={() => profileDialogRef.current?.close()}>
            {t("ui.app.done")}
          </button>
        </div>
      </dialog>
    </>
  );
}

function skillToDraft(skill: SkillRecord) {
  const { name = "", shortName = "", castTime = 0, action = [], modifier = [], tags = [] } = skill;
  const toObjects = (items: unknown[]) =>
    items.map((item) => (item && typeof item === "object" && !Array.isArray(item) ? (item as EditableObject) : {}));
  const stackEffects = Array.isArray(skill.stackEffects) ? skill.stackEffects : [];
  const periodicActions = Array.isArray(skill.periodic?.action) ? skill.periodic.action : [];
  const isDot = tags.includes("DOT");
  return {
    name,
    shortName,
    description: asString(skill.description),
    refresh: skill.refresh !== false,
    castTime: String(baseSkillCastTime(skill)),
    originalCastTime: castTime,
    cooldown: typeof skill.cooldown === "number" ? String(skill.cooldown) : "",
    duration: typeof skill.duration === "number" ? String(skill.duration) : "",
    maxStack: typeof skill.maxStack === "number" ? String(skill.maxStack) : "",
    periodicInterval: typeof skill.periodic?.interval === "number" ? String(skill.periodic.interval) : "",
    firstTick: typeof skill.periodic?.firstTick === "number" ? String(skill.periodic.firstTick) : "",
    resetOnRefresh: skill.periodic?.resetOnRefresh === true,
    tags: tags.join(", "),
    actionItems: toObjects(isDot ? periodicActions : action),
    modifierItems: toObjects(modifier),
    effectItems: toObjects(Array.isArray(skill.effect) ? skill.effect : []),
    stackEffectGroups: stackEffects.map((group) => toObjects(Array.isArray(group) ? group : [])),
  };
}

const actionTypes = [
  "damage",
  "replay",
  "consume",
  "apply",
  "trigger",
  "extend",
  "clearCD",
  "setResource",
  "addResource",
  "consumeResource",
];
const conditionTargets = [
  "self",
  "target",
  "skillTag",
  "martialArt",
  "equippedMartialArt",
  "currentMartialArt",
  "currentWeapon",
  "resource",
  "skillCooldown",
];
const effectFields = [
  "castTimeModifier",
  "castTimeMultiplier",
  "baseDMGBonus",
  "hpDMGBonus",
  "globalDmgBonus",
  "globalHPDMGBonus",
  "globalBellstrikeDMGBonus",
  "dotDamage",
  "dmgBonus",
  "defenseBonus",
  "physicalPenetration",
  "formlessPenetration",
  "physicalResistance",
  "bellstrikeResistance",
  "stonesplitResistance",
  "silkbindResistance",
  "bamboocutResistance",
  "critDmgBonus",
  "affinityDmgBonus",
  "SteadfastGuaranteedCrit",
  "enhanceDrunkenPoet",
];
const booleanEffectFields = new Set(["SteadfastGuaranteedCrit", "enhanceDrunkenPoet"]);

function asNumber(value: unknown, fallback = 0) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function asString(value: unknown) {
  return typeof value === "string" ? value : "";
}

function itemSummary(item: string, index: number, kind: "action" | "modifier" | "effect") {
  try {
    const parsed = JSON.parse(item) as EditableObject;
    if (kind === "effect") {
      const payload =
        parsed.effect && typeof parsed.effect === "object" && !Array.isArray(parsed.effect)
          ? (parsed.effect as EditableObject)
          : parsed;
      const fields = Object.keys(payload).filter((field) => field !== "requirement");
      return `${index + 1}. ${fields.join(", ") || "effect"}`;
    }
    const type = typeof parsed.type === "string" ? parsed.type : kind;
    const time = typeof parsed.time === "number" ? ` at ${parsed.time}s` : "";
    return `${index + 1}. ${type}${time}`;
  } catch {
    return `${index + 1}. ${kind}`;
  }
}

function updateObjectField(object: EditableObject, field: string, value: unknown) {
  return { ...object, [field]: value };
}

function RequirementEditor({ value, onChange }: { value: unknown; onChange: (value: unknown) => void }) {
  const wrapper =
    value && typeof value === "object" && !Array.isArray(value) && (value as EditableObject).resolveAt === "skillStart"
      ? (value as EditableObject)
      : undefined;
  const requirements = Array.isArray(wrapper?.operand)
    ? (wrapper.operand as unknown[])
    : Array.isArray(value)
      ? (value as unknown[])
      : [];
  const emit = (next: unknown[]) => onChange(wrapper ? { ...wrapper, operand: next } : next);
  function editLeaf(leaf: unknown, field: string, fieldValue: string) {
    const current = leaf && typeof leaf === "object" && !Array.isArray(leaf) ? (leaf as EditableObject) : {};
    return { ...current, [field]: fieldValue };
  }
  function updateLeaf(index: number, field: string, fieldValue: string) {
    const next = [...requirements];
    next[index] = editLeaf(next[index], field, fieldValue);
    emit(next);
  }
  function updateOrLeaf(
    groupIndex: number,
    operandIndex: number,
    field: string,
    fieldValue: string,
    nestedIndex?: number,
  ) {
    const group = requirements[groupIndex] as EditableObject;
    const operands = Array.isArray(group.operand) ? [...group.operand] : [];
    if (nestedIndex === undefined) operands[operandIndex] = editLeaf(operands[operandIndex], field, fieldValue);
    else {
      const nested = Array.isArray(operands[operandIndex]) ? [...(operands[operandIndex] as unknown[])] : [];
      nested[nestedIndex] = editLeaf(nested[nestedIndex], field, fieldValue);
      operands[operandIndex] = nested;
    }
    const next = [...requirements];
    next[groupIndex] = { ...group, operand: operands };
    emit(next);
  }
  function addOrGroup() {
    emit([
      ...requirements,
      {
        operator: "or",
        operand: [
          { target: "self", value: "" },
          { target: "self", value: "" },
        ],
      },
    ]);
  }
  function addOrOperand(groupIndex: number) {
    const group = requirements[groupIndex] as EditableObject;
    const next = [...requirements];
    next[groupIndex] = {
      ...group,
      operand: [...(Array.isArray(group.operand) ? group.operand : []), { target: "self", value: "" }],
    };
    emit(next);
  }
  function removeOrOperand(groupIndex: number, operandIndex: number, nestedIndex?: number) {
    const group = requirements[groupIndex] as EditableObject;
    const operands = Array.isArray(group.operand) ? [...group.operand] : [];
    if (nestedIndex === undefined) operands.splice(operandIndex, 1);
    else {
      const nested = Array.isArray(operands[operandIndex]) ? [...(operands[operandIndex] as unknown[])] : [];
      nested.splice(nestedIndex, 1);
      operands[operandIndex] = nested;
    }
    const next = [...requirements];
    next[groupIndex] = { ...group, operand: operands };
    emit(next);
  }
  const addLeaf = () => emit([...requirements, { target: "self", value: "" }]);
  const remove = (index: number) => emit(requirements.filter((_, itemIndex) => itemIndex !== index));
  return (
    <div className="requirement-editor">
      <div className="sub-editor-heading">
        <span>
          {t("ui.app.requirements")} <small>{t("ui.app.allConditionsMustPass")}</small>
        </span>
        <div className="sub-editor-buttons">
          <button className="button button-small" type="button" onClick={addLeaf}>
            {t("ui.app.addCondition")}
          </button>
          <button className="button button-small" type="button" onClick={addOrGroup}>
            {t("ui.app.addOr")}
          </button>
        </div>
      </div>
      {requirements.length === 0 && <span className="sub-editor-empty">{t("ui.app.noRequirements")}</span>}
      {requirements.map((requirement, index) => {
        const item =
          requirement && typeof requirement === "object" && !Array.isArray(requirement)
            ? (requirement as EditableObject)
            : {};
        if (item.operator === "or") {
          const operands = Array.isArray(item.operand) ? item.operand : [];
          return (
            <div className="or-condition" key={index}>
              <div className="or-condition-heading">
                <span>{t("ui.app.orGroup")}</span>
                <button type="button" onClick={() => remove(index)}>
                  {t("ui.app.remove")}
                </button>
              </div>
              {operands.map((operand, operandIndex) =>
                Array.isArray(operand) ? (
                  <div className="and-group" key={operandIndex}>
                    <small>{t("ui.app.andGroup")}</small>
                    {operand.map((leaf, nestedIndex) => (
                      <div className="condition-row" key={nestedIndex}>
                        <select
                          value={asString((leaf as EditableObject)?.target) || "self"}
                          onChange={(event) =>
                            updateOrLeaf(index, operandIndex, "target", event.target.value, nestedIndex)
                          }
                        >
                          {conditionTargets.map((target) => (
                            <option key={target}>{target}</option>
                          ))}
                        </select>
                        <input
                          value={asString((leaf as EditableObject)?.value)}
                          placeholder={t("ui.app.value")}
                          onChange={(event) =>
                            updateOrLeaf(index, operandIndex, "value", event.target.value, nestedIndex)
                          }
                        />
                        <button
                          type="button"
                          aria-label={t("ui.app.removeAlternative")}
                          onClick={() => removeOrOperand(index, operandIndex, nestedIndex)}
                        >
                          <UiIcon name="close" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="condition-row" key={operandIndex}>
                    <select
                      value={asString((operand as EditableObject)?.target) || "self"}
                      onChange={(event) => updateOrLeaf(index, operandIndex, "target", event.target.value)}
                    >
                      {conditionTargets.map((target) => (
                        <option key={target}>{target}</option>
                      ))}
                    </select>
                    <input
                      value={asString((operand as EditableObject)?.value)}
                      placeholder={t("ui.app.value")}
                      onChange={(event) => updateOrLeaf(index, operandIndex, "value", event.target.value)}
                    />
                    <button
                      type="button"
                      aria-label={t("ui.app.removeAlternative")}
                      onClick={() => removeOrOperand(index, operandIndex)}
                    >
                      <UiIcon name="close" />
                    </button>
                  </div>
                ),
              )}
              <button className="button button-small" type="button" onClick={() => addOrOperand(index)}>
                {t("ui.app.addAlternative")}
              </button>
            </div>
          );
        }
        return (
          <div className="condition-row" key={index}>
            <select
              value={asString(item.target) || "self"}
              onChange={(event) => updateLeaf(index, "target", event.target.value)}
            >
              {conditionTargets.map((target) => (
                <option key={target}>{target}</option>
              ))}
            </select>
            <input
              value={asString(item.value)}
              placeholder={t("ui.app.value")}
              onChange={(event) => updateLeaf(index, "value", event.target.value)}
            />
            <button type="button" aria-label={t("ui.app.removeCondition")} onClick={() => remove(index)}>
              <UiIcon name="close" />
            </button>
          </div>
        );
      })}
    </div>
  );
}

function NumberField({ label, value, onChange }: { label: string; value: unknown; onChange: (value: number) => void }) {
  return (
    <label className="detail-field">
      <span>{label}</span>
      <input
        type="number"
        step="0.0001"
        value={typeof value === "number" ? value : ""}
        onChange={(event) => onChange(Number(event.target.value))}
      />
    </label>
  );
}

function ActionDetails({
  item,
  onChange,
  skillIds,
}: {
  item: EditableObject;
  onChange: (item: EditableObject) => void;
  skillIds: string[];
}) {
  const type = asString(item.type) || "damage";
  const isResourceAction = type === "setResource" || type === "addResource" || type === "consumeResource";
  const set = (field: string, value: unknown) => onChange(updateObjectField(item, field, value));
  const consumeValueObject =
    item.value && typeof item.value === "object" && !Array.isArray(item.value)
      ? (item.value as EditableObject)
      : undefined;
  const firstConsume = consumeValueObject?.operator === "first";
  const consumeResolvesAtSkillStart = firstConsume && consumeValueObject.resolveAt === "skillStart";
  const requirementObject =
    item.requirement && typeof item.requirement === "object" && !Array.isArray(item.requirement)
      ? (item.requirement as EditableObject)
      : undefined;
  const requirementResolvesAtSkillStart =
    requirementObject?.resolveAt === "skillStart" && Array.isArray(requirementObject.operand);
  const consumeText = firstConsume
    ? Array.isArray(consumeValueObject?.operand)
      ? (consumeValueObject.operand as unknown[]).map(asString).join(", ")
      : ""
    : asString(item.value);
  function setConsumeMode(mode: string) {
    const current = consumeText
      .split(",")
      .map((value) => value.trim())
      .filter(Boolean);
    set(
      "value",
      mode === "first"
        ? {
            operator: "first",
            operand: current,
            ...(consumeResolvesAtSkillStart ? { resolveAt: "skillStart" } : {}),
          }
        : (current[0] ?? ""),
    );
  }
  function setConsumeText(value: string) {
    set(
      "value",
      firstConsume
        ? {
            operator: "first",
            operand: value
              .split(",")
              .map((part) => part.trim())
              .filter(Boolean),
            ...(consumeResolvesAtSkillStart ? { resolveAt: "skillStart" } : {}),
          }
        : value,
    );
  }
  function setConsumeResolveAtSkillStart(enabled: boolean) {
    if (!firstConsume) return;
    const nextValue = { ...consumeValueObject };
    if (enabled) nextValue.resolveAt = "skillStart";
    else delete nextValue.resolveAt;
    set("value", nextValue);
  }
  function setRequirementResolveAtSkillStart(enabled: boolean) {
    const operand = requirementResolvesAtSkillStart
      ? (requirementObject?.operand as unknown[])
      : Array.isArray(item.requirement)
        ? item.requirement
        : [];
    set("requirement", enabled ? { resolveAt: "skillStart", operand } : operand);
  }
  return (
    <div className="structured-detail">
      <div className="detail-fields">
        <label className="detail-field">
          <span>{t("ui.app.type")}</span>
          <select value={type} onChange={(event) => set("type", event.target.value)}>
            {actionTypes.map((actionType) => (
              <option key={actionType}>{actionType}</option>
            ))}
          </select>
        </label>
        <NumberField label={t("ui.app.time")} value={item.time} onChange={(value) => set("time", value)} />
      </div>
      {(type === "damage" || type === "heal") && (
        <div className="detail-fields detail-fields-four">
          <NumberField
            label={t("ui.app.physicalCoefficient")}
            value={item.phyCoef}
            onChange={(value) => set("phyCoef", value)}
          />
          {type === "heal" ? (
            <NumberField
              label={t("ui.app.silkbindCoefficient")}
              value={item.silkbindCoef}
              onChange={(value) => set("silkbindCoef", value)}
            />
          ) : (
            <NumberField
              label={t("ui.app.attributeCoefficient")}
              value={item.attrCoef}
              onChange={(value) => set("attrCoef", value)}
            />
          )}
          <NumberField
            label={t("ui.app.physicalBonus")}
            value={item.phyBonus}
            onChange={(value) => set("phyBonus", value)}
          />
          <NumberField
            label={t("ui.app.attributeBonus")}
            value={item.attrBonus}
            onChange={(value) => set("attrBonus", value)}
          />
        </div>
      )}
      {type === "replay" && (
        <div className="detail-fields">
          <NumberField label={t("ui.app.coefficient")} value={item.coef} onChange={(value) => set("coef", value)} />
        </div>
      )}
      {(type === "apply" || type === "extend" || type === "clearCD") && (
        <div className="detail-fields">
          <label className="detail-field">
            <span>{t("ui.app.target")}</span>
            <select value={asString(item.target) || "self"} onChange={(event) => set("target", event.target.value)}>
              <option value="self">{"self"}</option>
              <option value="target">{"target"}</option>
            </select>
          </label>
          <label className="detail-field">
            <span>{t("ui.app.value")}</span>
            <input value={asString(item.value)} onChange={(event) => set("value", event.target.value)} />
          </label>
        </div>
      )}
      {type === "consume" && (
        <div className="detail-fields consume-fields">
          <label className="detail-field">
            <span>{t("ui.app.target")}</span>
            <select value={asString(item.target) || "self"} onChange={(event) => set("target", event.target.value)}>
              <option value="self">{"self"}</option>
              <option value="target">{"target"}</option>
            </select>
          </label>
          <label className="detail-field">
            <span>{t("ui.app.valueMode")}</span>
            <select value={firstConsume ? "first" : "name"} onChange={(event) => setConsumeMode(event.target.value)}>
              <option value="name">{t("ui.app.singleName")}</option>
              <option value="first">{t("ui.app.firstAvailable")}</option>
            </select>
          </label>
          <label className="detail-field consume-value-field">
            <span>{firstConsume ? t("ui.app.valuesCommaSeparated") : t("ui.app.value")}</span>
            <input value={consumeText} onChange={(event) => setConsumeText(event.target.value)} />
          </label>
        </div>
      )}
      {isResourceAction && (
        <div className="detail-fields">
          <label className="detail-field">
            <span>{t("ui.app.value")}</span>
            <input value={asString(item.value)} onChange={(event) => set("value", event.target.value)} />
          </label>
          {type === "consumeResource" && item.amount === "all" ? (
            <label className="checkbox-field">
              <input type="checkbox" checked onChange={() => set("amount", 0)} />
              <span>{t("ui.app.all")}</span>
            </label>
          ) : (
            <>
              <NumberField label={t("ui.app.amount")} value={item.amount} onChange={(value) => set("amount", value)} />
              {type === "consumeResource" && (
                <label className="checkbox-field">
                  <input type="checkbox" checked={false} onChange={() => set("amount", "all")} />
                  <span>{t("ui.app.all")}</span>
                </label>
              )}
            </>
          )}
        </div>
      )}
      {(type === "apply" || type === "consume") && (
        <div className="detail-fields">
          {type === "consume" && (
            <label className="checkbox-field">
              <input
                type="checkbox"
                checked={item.stack === "all"}
                onChange={(event) => set("stack", event.target.checked ? "all" : 1)}
              />
              <span>{t("ui.app.allStacks")}</span>
            </label>
          )}
          {type === "consume" && firstConsume && (
            <label className="checkbox-field">
              <input
                type="checkbox"
                checked={consumeResolvesAtSkillStart}
                onChange={(event) => setConsumeResolveAtSkillStart(event.target.checked)}
              />
              <span>{t("ui.app.resolveAtSkillStart")}</span>
            </label>
          )}
          {item.stack !== "all" && (
            <NumberField label={t("ui.app.stack")} value={item.stack} onChange={(value) => set("stack", value)} />
          )}
          {type === "apply" && (
            <label className="checkbox-field">
              <input
                type="checkbox"
                checked={item.reapply === true}
                onChange={(event) => set("reapply", event.target.checked)}
              />
              <span>{t("ui.app.reapply")}</span>
            </label>
          )}
        </div>
      )}
      {(type === "apply" || type === "extend") && (
        <NumberField label={t("ui.app.duration")} value={item.duration} onChange={(value) => set("duration", value)} />
      )}
      {type === "trigger" && (
        <label className="detail-field">
          <span>{t("ui.app.triggeredSkill")}</span>
          <select value={asString(item.value)} onChange={(event) => set("value", event.target.value)}>
            <option value="">{t("ui.app.selectASkill")}</option>
            {skillIds.map((skillId) => (
              <option key={skillId}>{skillId}</option>
            ))}
          </select>
        </label>
      )}
      {(type === "apply" || type === "trigger" || type === "extend" || type === "clearCD" || isResourceAction) && (
        <>
          <label className="checkbox-field">
            <input
              type="checkbox"
              checked={requirementResolvesAtSkillStart}
              onChange={(event) => setRequirementResolveAtSkillStart(event.target.checked)}
            />
            <span>{t("ui.app.resolveAtSkillStart")}</span>
          </label>
          <RequirementEditor value={item.requirement} onChange={(value) => set("requirement", value)} />
        </>
      )}
    </div>
  );
}

function ModifierDetails({ item, onChange }: { item: EditableObject; onChange: (item: EditableObject) => void }) {
  const set = (field: string, value: unknown) => onChange(updateObjectField(item, field, value));
  const effect =
    item.effect && typeof item.effect === "object" && !Array.isArray(item.effect)
      ? (item.effect as EditableObject)
      : {};
  const effectEntries = Object.entries(effect);
  function updateEffect(field: string, value: unknown) {
    set("effect", { ...effect, [field]: value });
  }
  function addEffect() {
    const field = effectFields.find((candidate) => !(candidate in effect));
    if (field) updateEffect(field, booleanEffectFields.has(field) ? false : 0);
  }
  function removeEffect(field: string) {
    const next = { ...effect };
    delete next[field];
    set("effect", next);
  }
  return (
    <div className="structured-detail">
      <RequirementEditor value={item.requirement} onChange={(value) => set("requirement", value)} />
      <div className="sub-editor-heading">
        <span>{t("ui.app.effects")}</span>
        <button className="button button-small" type="button" onClick={addEffect}>
          {t("ui.app.addEffect")}
        </button>
      </div>
      {effectEntries.map(([field, value]) => (
        <div className="effect-row" key={field}>
          <select
            value={field}
            onChange={(event) => {
              const next = { ...effect };
              const nextField = event.target.value;
              if (nextField !== field) {
                next[nextField] = next[field];
                delete next[field];
                set("effect", next);
              }
            }}
          >
            {!effectFields.includes(field) && <option value={field}>{field}</option>}
            {effectFields.map((effectField) => (
              <option key={effectField}>{effectField}</option>
            ))}
          </select>
          <EffectValueEditor value={value} onChange={(nextValue) => updateEffect(field, nextValue)} />
          <button type="button" aria-label={t("ui.app.removeEffect")} onClick={() => removeEffect(field)}>
            <UiIcon name="close" />
          </button>
        </div>
      ))}
    </div>
  );
}

function DynamicByStackValueEditor({
  value,
  onChange,
}: {
  value: EditableObject;
  onChange: (value: EditableObject) => void;
}) {
  return (
    <div className="dynamic-effect-editor">
      <label className="detail-field">
        <span>{t("ui.app.effect")}</span>
        <input
          value={asString(value.param1)}
          onChange={(event) => onChange({ ...value, function: "byStack", param1: event.target.value })}
        />
      </label>
      <label className="detail-field">
        <span>{t("ui.app.valuePerStack")}</span>
        <input
          type="number"
          step="0.0001"
          value={typeof value.param2 === "number" ? value.param2 : ""}
          onChange={(event) => onChange({ ...value, function: "byStack", param2: Number(event.target.value) })}
        />
      </label>
      <label className="detail-field">
        <span>{t("ui.app.target")}</span>
        <select
          value={value.target === "target" ? "target" : "self"}
          onChange={(event) => onChange({ ...value, function: "byStack", target: event.target.value })}
        >
          <option value="self">{"self"}</option>
          <option value="target">{"target"}</option>
        </select>
      </label>
    </div>
  );
}

function DynamicMultiplyValueEditor({
  value,
  onChange,
}: {
  value: EditableObject;
  onChange: (value: EditableObject) => void;
}) {
  return (
    <div className="dynamic-effect-editor">
      <label className="detail-field">
        <span>{t("ui.app.parameter")}</span>
        <input
          value={asString(value.param1)}
          onChange={(event) => onChange({ ...value, function: "multiply", param1: event.target.value })}
        />
      </label>
      <label className="detail-field">
        <span>{t("ui.app.multiplier")}</span>
        <input
          type="number"
          step="0.0001"
          value={typeof value.param2 === "number" || typeof value.param2 === "string" ? value.param2 : ""}
          onChange={(event) => onChange({ ...value, function: "multiply", param2: Number(event.target.value) })}
        />
      </label>
    </div>
  );
}

function DynamicSegmentValueEditor({
  value,
  onChange,
}: {
  value: EditableObject;
  onChange: (value: EditableObject) => void;
}) {
  const thresholds = Array.isArray(value.param2) ? value.param2.map((item) => asNumber(item)) : [];
  const results = Array.isArray(value.param3) ? value.param3.map((item) => asNumber(item)) : [];
  const resizeResults = (nextThresholds: number[]) =>
    Array.from({ length: nextThresholds.length + 1 }, (_, index) => results[index] ?? 0);
  return (
    <div className="dynamic-effect-editor">
      <label className="detail-field">
        <span>{t("ui.app.parameter")}</span>
        <input
          value={typeof value.param1 === "number" ? value.param1 : asString(value.param1)}
          onChange={(event) => onChange({ ...value, function: "segment", param1: event.target.value })}
        />
      </label>
      <div className="sub-editor-heading">
        <span>{t("ui.app.thresholds")}</span>
        <button
          className="button button-small"
          type="button"
          onClick={() => {
            const nextThresholds = [...thresholds, 0];
            onChange({ ...value, function: "segment", param2: nextThresholds, param3: resizeResults(nextThresholds) });
          }}
        >
          {t("ui.app.add")}
        </button>
      </div>
      <div className="dynamic-effect-values">
        {thresholds.map((item, index) => (
          <div key={index}>
            <input
              aria-label={t("ui.app.thresholdNumber", { number: index + 1 })}
              type="number"
              step="0.0001"
              value={item}
              onChange={(event) =>
                onChange({
                  ...value,
                  function: "segment",
                  param2: thresholds.map((threshold, thresholdIndex) =>
                    thresholdIndex === index ? Number(event.target.value) : threshold,
                  ),
                })
              }
            />
            <button
              type="button"
              aria-label={t("ui.app.removeThresholdNumber", { number: index + 1 })}
              onClick={() => {
                const nextThresholds = thresholds.filter((_, thresholdIndex) => thresholdIndex !== index);
                const nextResults = results.filter((_, resultIndex) => resultIndex !== index);
                onChange({
                  ...value,
                  function: "segment",
                  param2: nextThresholds,
                  param3: Array.from(
                    { length: nextThresholds.length + 1 },
                    (_, resultIndex) => nextResults[resultIndex] ?? 0,
                  ),
                });
              }}
            >
              <UiIcon name="close" />
            </button>
          </div>
        ))}
      </div>
      <div className="sub-editor-heading">
        <span>{t("ui.app.segmentValues")}</span>
      </div>
      <div className="dynamic-effect-values">
        {Array.from({ length: thresholds.length + 1 }, (_, index) => results[index] ?? 0).map((item, index) => (
          <div key={index}>
            <input
              aria-label={t("ui.app.segmentValueNumber", { number: index + 1 })}
              type="number"
              step="0.0001"
              value={item}
              onChange={(event) =>
                onChange({
                  ...value,
                  function: "segment",
                  param3: Array.from({ length: thresholds.length + 1 }, (_, resultIndex) =>
                    resultIndex === index ? Number(event.target.value) : (results[resultIndex] ?? 0),
                  ),
                })
              }
            />
          </div>
        ))}
      </div>
    </div>
  );
}

function EffectValueEditor({ value, onChange }: { value: unknown; onChange: (value: unknown) => void }) {
  const objectValue =
    value && typeof value === "object" && !Array.isArray(value) ? (value as EditableObject) : undefined;
  const dynamicValue =
    objectValue?.function === "byStack" || objectValue?.function === "segment" || objectValue?.function === "multiply"
      ? objectValue
      : undefined;
  const kind =
    dynamicValue?.function === "byStack"
      ? "byStack"
      : dynamicValue?.function === "segment"
        ? "segment"
        : dynamicValue?.function === "multiply"
          ? "multiply"
          : typeof value === "boolean"
            ? "boolean"
            : typeof value === "string"
              ? "text"
              : "number";
  return (
    <div className="effect-value-editor">
      <select
        aria-label={t("ui.app.effectValueType")}
        value={kind}
        onChange={(event) => {
          const nextKind = event.target.value;
          onChange(
            nextKind === "byStack"
              ? { function: "byStack", param1: "", param2: 0.2, target: "self" }
              : nextKind === "segment"
                ? { function: "segment", param1: "actionTime", param2: [], param3: [0] }
                : nextKind === "multiply"
                  ? { function: "multiply", param1: "missingHPPercentage", param2: 0.0045 }
                  : nextKind === "boolean"
                    ? false
                    : nextKind === "text"
                      ? ""
                      : 0,
          );
        }}
      >
        <option value="number">{"number"}</option>
        <option value="boolean">{"boolean"}</option>
        <option value="byStack">{"byStack"}</option>
        <option value="segment">{"segment"}</option>
        <option value="multiply">{"multiply"}</option>
        <option value="text">{"text"}</option>
      </select>
      {kind === "byStack" && dynamicValue ? (
        <DynamicByStackValueEditor value={dynamicValue} onChange={onChange} />
      ) : kind === "segment" && dynamicValue ? (
        <DynamicSegmentValueEditor value={dynamicValue} onChange={onChange} />
      ) : kind === "multiply" && dynamicValue ? (
        <DynamicMultiplyValueEditor value={dynamicValue} onChange={onChange} />
      ) : kind === "boolean" ? (
        <label className="checkbox-field">
          <input type="checkbox" checked={value === true} onChange={(event) => onChange(event.target.checked)} />
          <span>{value === true ? "true" : "false"}</span>
        </label>
      ) : (
        <input
          type={kind === "number" ? "number" : "text"}
          step={kind === "number" ? "0.0001" : undefined}
          value={kind === "number" ? (typeof value === "number" ? value : "") : asString(value)}
          onChange={(event) => onChange(kind === "number" ? Number(event.target.value) : event.target.value)}
        />
      )}
    </div>
  );
}

function EffectRuleDetails({ item, onChange }: { item: EditableObject; onChange: (item: EditableObject) => void }) {
  const wrapped = item.effect && typeof item.effect === "object" && !Array.isArray(item.effect);
  const effect = wrapped
    ? (item.effect as EditableObject)
    : Object.fromEntries(Object.entries(item).filter(([field]) => field !== "requirement"));
  const effectEntries = Object.entries(effect);
  function setEffect(nextEffect: EditableObject) {
    if (wrapped) onChange({ ...item, effect: nextEffect });
    else onChange({ ...(Array.isArray(item.requirement) ? { requirement: item.requirement } : {}), ...nextEffect });
  }
  function updateEffect(field: string, value: unknown) {
    setEffect({ ...effect, [field]: value });
  }
  function addEffect() {
    const field = effectFields.find((candidate) => !(candidate in effect));
    if (field) updateEffect(field, booleanEffectFields.has(field) ? false : 0);
  }
  function removeEffect(field: string) {
    const next = { ...effect };
    delete next[field];
    setEffect(next);
  }
  return (
    <div className="structured-detail">
      <RequirementEditor value={item.requirement} onChange={(requirement) => onChange({ ...item, requirement })} />
      <div className="sub-editor-heading">
        <span>
          {t("ui.app.effects")} <small>({wrapped ? t("ui.app.wrapped") : t("ui.app.direct")})</small>
        </span>
        <button className="button button-small" type="button" onClick={addEffect}>
          {t("ui.app.addEffect")}
        </button>
      </div>
      {effectEntries.length === 0 && <span className="sub-editor-empty">{t("ui.app.noEffects")}</span>}
      {effectEntries.map(([field, value]) => (
        <div className="effect-row effect-rule-row" key={field}>
          <select
            value={field}
            onChange={(event) => {
              const next = { ...effect };
              const nextField = event.target.value;
              if (nextField !== field) {
                next[nextField] = next[field];
                delete next[field];
                setEffect(next);
              }
            }}
          >
            {!effectFields.includes(field) && <option value={field}>{field}</option>}
            {effectFields.map((effectField) => (
              <option key={effectField}>{effectField}</option>
            ))}
          </select>
          <EffectValueEditor value={value} onChange={(nextValue) => updateEffect(field, nextValue)} />
          <button
            type="button"
            aria-label={t("ui.app.removeNamedEffect", { name: field })}
            onClick={() => removeEffect(field)}
          >
            <UiIcon name="close" />
          </button>
        </div>
      ))}
    </div>
  );
}

function ArrayItemEditor({
  label,
  kind,
  items,
  onChange,
  skillIds,
}: {
  label: string;
  kind: "action" | "modifier" | "effect";
  items: EditableObject[];
  onChange: (items: EditableObject[]) => void;
  skillIds: string[];
}) {
  const [expanded, setExpanded] = useState<number | null>(items.length ? 0 : null);

  function updateItem(index: number, value: EditableObject) {
    const next = [...items];
    next[index] = value;
    onChange(next);
  }

  function addItem() {
    const item: EditableObject = kind === "action" ? { type: "damage", time: 0 } : { requirement: [], effect: {} };
    const next = [...items, item];
    onChange(next);
    setExpanded(next.length - 1);
  }

  function moveItem(index: number, direction: -1 | 1) {
    const target = index + direction;
    if (target < 0 || target >= items.length) return;
    const next = [...items];
    [next[index], next[target]] = [next[target], next[index]];
    onChange(next);
    setExpanded(target);
  }

  function deleteItem(index: number) {
    onChange(items.filter((_, itemIndex) => itemIndex !== index));
    setExpanded(null);
  }

  return (
    <section className="array-editor">
      <div className="array-editor-heading">
        <span>{label}</span>
        <button className="button button-small" type="button" onClick={addItem}>
          {t("ui.app.add")}
        </button>
      </div>
      {items.length === 0 && (
        <p className="array-editor-empty">
          {t("ui.app.no")} {label.toLowerCase()} {t("ui.app.yet")}
        </p>
      )}
      <div className="array-editor-list">
        {items.map((item, index) => {
          return (
            <div className={`array-item ${expanded === index ? "expanded" : ""}`} key={index}>
              <div className="array-item-header">
                <button
                  className="array-item-toggle"
                  type="button"
                  onClick={() => setExpanded(expanded === index ? null : index)}
                >
                  {itemSummary(JSON.stringify(item), index, kind)}
                </button>
                <div className="array-item-controls">
                  <button
                    type="button"
                    aria-label={t("ui.app.moveUp")}
                    disabled={index === 0}
                    onClick={() => moveItem(index, -1)}
                  >
                    <UiIcon name="up" />
                  </button>
                  <button
                    type="button"
                    aria-label={t("ui.app.moveDown")}
                    disabled={index === items.length - 1}
                    onClick={() => moveItem(index, 1)}
                  >
                    <UiIcon name="down" />
                  </button>
                  <button type="button" aria-label={t("ui.app.delete")} onClick={() => deleteItem(index)}>
                    <UiIcon name="close" />
                  </button>
                </div>
              </div>
              {expanded === index && (
                <div className="array-item-detail">
                  {kind === "action" ? (
                    <ActionDetails item={item} onChange={(next) => updateItem(index, next)} skillIds={skillIds} />
                  ) : kind === "modifier" ? (
                    <ModifierDetails item={item} onChange={(next) => updateItem(index, next)} />
                  ) : (
                    <EffectRuleDetails item={item} onChange={(next) => updateItem(index, next)} />
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}

function StackEffectsEditor({
  groups,
  onChange,
  skillIds,
}: {
  groups: EditableObject[][];
  onChange: (groups: EditableObject[][]) => void;
  skillIds: string[];
}) {
  const [expanded, setExpanded] = useState<number | null>(groups.length ? 0 : null);
  function moveGroup(index: number, direction: -1 | 1) {
    const target = index + direction;
    if (target < 0 || target >= groups.length) return;
    const next = [...groups];
    [next[index], next[target]] = [next[target], next[index]];
    onChange(next);
    setExpanded(target);
  }
  return (
    <section className="array-editor stack-effects-editor">
      <div className="array-editor-heading">
        <span>{t("ui.app.stackEffects")}</span>
        <button
          className="button button-small"
          type="button"
          onClick={() => {
            const next = [...groups, []];
            onChange(next);
            setExpanded(next.length - 1);
          }}
        >
          {t("ui.app.addStack")}
        </button>
      </div>
      {groups.length === 0 && <p className="array-editor-empty">{t("ui.app.noStackEffectsYet")}</p>}
      <div className="array-editor-list">
        {groups.map((group, index) => (
          <div className={`array-item ${expanded === index ? "expanded" : ""}`} key={index}>
            <div className="array-item-header">
              <button
                className="array-item-toggle"
                type="button"
                onClick={() => setExpanded(expanded === index ? null : index)}
              >
                {t("ui.app.stack")} {index + 1} · {group.length} {t("ui.app.stackEffectCountNoun")}
                {group.length === 1 ? "" : t("ui.app.s")}
              </button>
              <div className="array-item-controls">
                <button
                  type="button"
                  aria-label={t("ui.app.moveStackUp")}
                  disabled={index === 0}
                  onClick={() => moveGroup(index, -1)}
                >
                  <UiIcon name="up" />
                </button>
                <button
                  type="button"
                  aria-label={t("ui.app.moveStackDown")}
                  disabled={index === groups.length - 1}
                  onClick={() => moveGroup(index, 1)}
                >
                  <UiIcon name="down" />
                </button>
                <button
                  type="button"
                  aria-label={t("ui.app.deleteStack")}
                  onClick={() => {
                    onChange(groups.filter((_, groupIndex) => groupIndex !== index));
                    setExpanded(null);
                  }}
                >
                  <UiIcon name="close" />
                </button>
              </div>
            </div>
            {expanded === index && (
              <div className="array-item-detail">
                <ArrayItemEditor
                  label={t("ui.app.stackEffectsNumber", { number: index + 1 })}
                  kind="effect"
                  items={group}
                  skillIds={skillIds}
                  onChange={(items) =>
                    onChange(groups.map((candidate, groupIndex) => (groupIndex === index ? items : candidate)))
                  }
                />
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

function SkillEditorTab({
  weapons,
  overrides,
  onOverridesChange,
}: {
  weapons: [WeaponId, WeaponId];
  overrides: SkillOverrides;
  onOverridesChange: (overrides: SkillOverrides) => void;
}) {
  const [category, setCategory] = useState<EditorCategory>("Snowparting");
  const [selectedSkill, setSelectedSkill] = useState(Object.keys(defaultEditorMaps.Snowparting)[0]);
  const [draft, setDraft] = useState(() => skillToDraft(defaultEditorMaps.Snowparting[selectedSkill]));
  const [error, setError] = useState("");
  const setStatus = (message: string) => {
    if (message) publishNotice({ id: "skill-save", message });
    else dismissNotice("skill-save");
  };

  const skills = useMemo(() => ({ ...defaultEditorMaps[category], ...overrides[category] }), [category, overrides]);
  const skillIds = useMemo(() => Object.keys(skills), [skills]);
  const editorModified = hasSkillOverrides(overrides);
  const visibleCategories = useMemo<EditorCategory[]>(() => {
    const martialCategories = weapons.flatMap((weapon) => {
      const item = skillCategoryByWeapon[weapon];
      return item ? [item] : [];
    });
    return [
      ...new Set<EditorCategory>([...martialCategories, "Mystic", "General", "Buff", "Debuff", "DOT"]),
    ] as EditorCategory[];
  }, [weapons]);

  useEffect(() => {
    if (!visibleCategories.includes(category)) setCategory(visibleCategories[0]);
  }, [category, visibleCategories]);

  useEffect(() => {
    const firstSkill = Object.keys(defaultEditorMaps[category])[0];
    setSelectedSkill(firstSkill);
  }, [category]);

  useEffect(() => {
    const skill = skills[selectedSkill] ?? skills[skillIds[0]];
    if (skill) {
      setDraft(skillToDraft(skill));
      setError("");
      setStatus("");
    }
  }, [selectedSkill, skills, skillIds]);

  function selectSkill(id: string) {
    setSelectedSkill(id);
  }

  function save() {
    try {
      const isDefinition = category === "Buff" || category === "Debuff";
      const optionalNumber = (value: string, label: string) => {
        if (!value.trim()) return undefined;
        const number = Number(value);
        if (!Number.isFinite(number)) throw new Error(`${label} must be a number.`);
        return number;
      };
      let updatedSkill: SkillRecord;
      if (isDefinition) {
        updatedSkill = {
          ...skills[selectedSkill],
          name: draft.name,
          description: draft.description,
          refresh: draft.refresh,
          duration: optionalNumber(draft.duration, "Duration"),
          cooldown: optionalNumber(draft.cooldown, "Cooldown"),
          maxStack: optionalNumber(draft.maxStack, "Max stack"),
          effect: draft.effectItems,
          stackEffects: draft.stackEffectGroups,
        };
      } else {
        const action = draft.actionItems;
        const modifier = draft.modifierItems;
        const actionTimes = action.map((item) => item.time);
        if (actionTimes.some((time) => typeof time !== "number" || !Number.isFinite(time))) {
          throw new Error("Every action must have a numeric time.");
        }
        const numericActionTimes = actionTimes as number[];
        const firstOutOfOrder = numericActionTimes.findIndex(
          (time, index) => index > 0 && time < numericActionTimes[index - 1],
        );
        if (firstOutOfOrder !== -1) {
          throw new Error(
            `Actions are out of order: action ${firstOutOfOrder + 1} occurs before action ${firstOutOfOrder}.`,
          );
        }
        const parsedCastTime = category === "DOT" ? undefined : Number(draft.castTime);
        if (parsedCastTime !== undefined && !Number.isFinite(parsedCastTime))
          throw new Error("Cast time must be a number.");
        const originalFallback = baseSkillCastTime({ castTime: draft.originalCastTime });
        const castTime =
          parsedCastTime !== undefined && draft.castTime === String(originalFallback)
            ? draft.originalCastTime
            : parsedCastTime;
        updatedSkill = {
          ...skills[selectedSkill],
          name: draft.name,
          shortName: draft.shortName.trim() || undefined,
          ...(castTime === undefined ? {} : { castTime }),
          cooldown: optionalNumber(draft.cooldown, "Cooldown"),
          action,
          modifier,
          tags: draft.tags
            .split(",")
            .map((tag) => tag.trim())
            .filter(Boolean),
          ...(category === "DOT"
            ? {
                action: undefined,
                periodic: {
                  interval: optionalNumber(draft.periodicInterval, "Periodic interval"),
                  firstTick: optionalNumber(draft.firstTick, "First tick"),
                  resetOnRefresh: draft.resetOnRefresh,
                  action,
                },
                duration: optionalNumber(draft.duration, "Duration"),
                maxStack: optionalNumber(draft.maxStack, "Max stack"),
                refresh: draft.refresh,
              }
            : {}),
        };
      }
      const nextCategoryOverrides = { ...overrides[category] };
      if (JSON.stringify(updatedSkill) === JSON.stringify(defaultEditorMaps[category][selectedSkill])) {
        delete nextCategoryOverrides[selectedSkill];
      } else {
        nextCategoryOverrides[selectedSkill] = updatedSkill;
      }
      const nextOverrides: SkillOverrides = { ...overrides };
      if (Object.keys(nextCategoryOverrides).length > 0) nextOverrides[category] = nextCategoryOverrides;
      else delete nextOverrides[category];
      onOverridesChange(nextOverrides);
      setStatus(t("ui.app.savedForThisSession"));
      setError("");
    } catch (saveError) {
      publishNotice({
        id: "skill-save",
        error: true,
        message: saveError instanceof Error ? saveError.message : t("ui.app.recordSaveError"),
      });
    }
  }

  function restoreDefault() {
    const nextCategoryOverrides = { ...overrides[category] };
    delete nextCategoryOverrides[selectedSkill];
    const nextOverrides: SkillOverrides = { ...overrides };
    if (Object.keys(nextCategoryOverrides).length > 0) nextOverrides[category] = nextCategoryOverrides;
    else delete nextOverrides[category];
    onOverridesChange(nextOverrides);
    setDraft(skillToDraft(defaultEditorMaps[category][selectedSkill]));
    setError("");
    setStatus("");
  }

  function restoreAllDefaults() {
    onOverridesChange({});
    setDraft(skillToDraft(defaultEditorMaps[category][selectedSkill]));
    setError("");
    setStatus("");
  }

  const isDefinitionCategory = category === "Buff" || category === "Debuff";
  const categoryLabel = (item: EditorCategory) => {
    switch (item) {
      case "Snowparting":
        return "Snowparting Blade";
      case "Phalanxbane":
        return "Phalanxbane Blade";
      case "Infernal":
        return "Infernal Twinblades";
      case "Mortal":
        return "Mortal Rope Dart";
      case "Soulshade":
        return "Soulshade Umbrella";
      case "Panacea":
        return "Panacea Fan";
      default:
        return item;
    }
  };

  return (
    <>
      <section className="panel skill-editor-panel">
        <div className="skill-editor-toolbar">
          <div className="skill-category-tabs" role="tablist" aria-label={t("ui.app.skillCategories")}>
            {visibleCategories.map((item) => {
              const categoryModified = Object.keys(overrides[item] ?? {}).length > 0;
              return (
                <button
                  key={item}
                  className={`category-tab ${category === item ? "active" : ""} ${categoryModified ? "modified" : ""}`}
                  type="button"
                  onClick={() => setCategory(item)}
                >
                  {categoryLabel(item)}
                </button>
              );
            })}
          </div>
          <button
            className={`category-tab skill-editor-reset ${editorModified ? "modified" : ""}`}
            type="button"
            disabled={!editorModified}
            onClick={restoreAllDefaults}
          >
            {t("ui.app.reset")}
          </button>
        </div>
        <div className="skill-editor-layout">
          <aside className="skill-list" aria-label={t("ui.app.namedSkills", { name: category })}>
            {skillIds.map((id) => (
              <button
                key={id}
                className={`skill-list-item ${selectedSkill === id ? "active" : ""} ${overrides[category]?.[id] ? "modified" : ""}`}
                type="button"
                onClick={() => selectSkill(id)}
              >
                <strong>{skillDisplayName(skills[id], id)}</strong>
                <small>{id}</small>
              </button>
            ))}
          </aside>
          <div className="skill-detail">
            <div className="skill-detail-heading">
              <div>
                <span className="detail-kicker">{category}</span>
                <h3>{skillDisplayName(skills[selectedSkill], selectedSkill)}</h3>
              </div>
            </div>
            {isDefinitionCategory ? (
              <>
                <div className="skill-basic-fields definition-basic-fields">
                  <label className="editor-field">
                    <span>{t("ui.app.name")}</span>
                    <input value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} />
                  </label>
                  <label className="editor-field">
                    <span>{t("ui.app.maxStack")}</span>
                    <input
                      type="number"
                      min="1"
                      step="1"
                      value={draft.maxStack}
                      onChange={(event) => setDraft({ ...draft, maxStack: event.target.value })}
                    />
                  </label>
                  <label className="editor-field editor-field-wide">
                    <span>{t("ui.app.description")}</span>
                    <input
                      value={draft.description}
                      onChange={(event) => setDraft({ ...draft, description: event.target.value })}
                    />
                  </label>
                  <label className="editor-field">
                    <span>{t("ui.app.duration")}</span>
                    <input
                      type="number"
                      min="0"
                      step="0.0001"
                      value={draft.duration}
                      onChange={(event) => setDraft({ ...draft, duration: event.target.value })}
                    />
                  </label>
                  <label className="editor-field">
                    <span>{t("ui.app.cooldown")}</span>
                    <input
                      type="number"
                      min="0"
                      step="0.0001"
                      value={draft.cooldown}
                      onChange={(event) => setDraft({ ...draft, cooldown: event.target.value })}
                    />
                  </label>
                  <label className="editor-field">
                    <span>{t("ui.app.refreshDuration")}</span>
                    <input
                      type="checkbox"
                      checked={draft.refresh}
                      onChange={(event) => setDraft({ ...draft, refresh: event.target.checked })}
                    />
                  </label>
                </div>
                <div className="structured-editor-grid">
                  <ArrayItemEditor
                    label={t("ui.app.effects")}
                    kind="effect"
                    items={draft.effectItems}
                    onChange={(effectItems) => setDraft({ ...draft, effectItems })}
                    skillIds={editorSkillIds}
                  />
                  <StackEffectsEditor
                    groups={draft.stackEffectGroups}
                    onChange={(stackEffectGroups) => setDraft({ ...draft, stackEffectGroups })}
                    skillIds={editorSkillIds}
                  />
                </div>
              </>
            ) : (
              <>
                <div className="skill-basic-fields">
                  <label className="editor-field">
                    <span>{t("ui.app.name")}</span>
                    <input value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} />
                  </label>
                  <label className="editor-field">
                    <span>{t("ui.app.shortName")}</span>
                    <input
                      value={draft.shortName}
                      onChange={(event) => setDraft({ ...draft, shortName: event.target.value })}
                    />
                  </label>
                  {category === "DOT" ? (
                    <>
                      <label className="editor-field">
                        <span>{t("ui.app.interval")}</span>
                        <input
                          type="number"
                          min="0"
                          step="0.0001"
                          value={draft.periodicInterval}
                          onChange={(event) => setDraft({ ...draft, periodicInterval: event.target.value })}
                        />
                      </label>
                      <label className="editor-field">
                        <span>{t("ui.app.firstTick")}</span>
                        <input
                          type="number"
                          min="0"
                          step="0.0001"
                          value={draft.firstTick}
                          onChange={(event) => setDraft({ ...draft, firstTick: event.target.value })}
                        />
                      </label>
                      <label className="editor-field">
                        <span>{t("ui.app.duration")}</span>
                        <input
                          type="number"
                          min="0"
                          step="0.0001"
                          value={draft.duration}
                          onChange={(event) => setDraft({ ...draft, duration: event.target.value })}
                        />
                      </label>
                      <label className="editor-field">
                        <span>{t("ui.app.maxStack")}</span>
                        <input
                          type="number"
                          min="1"
                          step="1"
                          value={draft.maxStack}
                          onChange={(event) => setDraft({ ...draft, maxStack: event.target.value })}
                        />
                      </label>
                      <label className="editor-field">
                        <span>{t("ui.app.refreshDuration")}</span>
                        <input
                          type="checkbox"
                          checked={draft.refresh}
                          onChange={(event) => setDraft({ ...draft, refresh: event.target.checked })}
                        />
                      </label>
                      <label className="editor-field">
                        <span>{t("ui.app.resetPeriodOnRefresh")}</span>
                        <input
                          type="checkbox"
                          checked={draft.resetOnRefresh}
                          onChange={(event) => setDraft({ ...draft, resetOnRefresh: event.target.checked })}
                        />
                      </label>
                    </>
                  ) : (
                    <>
                      <label className="editor-field">
                        <span>{t("ui.app.castTime")}</span>
                        <input
                          type="number"
                          min="0"
                          step="0.0001"
                          value={draft.castTime}
                          onChange={(event) => setDraft({ ...draft, castTime: event.target.value })}
                        />
                      </label>
                      <label className="editor-field">
                        <span>{t("ui.app.cooldown")}</span>
                        <input
                          type="number"
                          min="0"
                          step="0.0001"
                          value={draft.cooldown}
                          onChange={(event) => setDraft({ ...draft, cooldown: event.target.value })}
                        />
                      </label>
                    </>
                  )}
                  <label className="editor-field editor-field-wide">
                    <span>
                      {t("ui.app.tags")} <small>{t("ui.app.commaSeparated")}</small>
                    </span>
                    <input value={draft.tags} onChange={(event) => setDraft({ ...draft, tags: event.target.value })} />
                  </label>
                </div>
                <div className="json-editor-grid">
                  <ArrayItemEditor
                    label={t("ui.app.actions")}
                    kind="action"
                    items={draft.actionItems}
                    onChange={(actionItems) => setDraft({ ...draft, actionItems })}
                    skillIds={editorSkillIds}
                  />
                  <ArrayItemEditor
                    label={t("ui.app.modifiers")}
                    kind="modifier"
                    items={draft.modifierItems}
                    onChange={(modifierItems) => setDraft({ ...draft, modifierItems })}
                    skillIds={editorSkillIds}
                  />
                </div>
              </>
            )}
            {error && <p className="editor-error">{error}</p>}
            <div className="editor-actions">
              <button className="button button-secondary" type="button" onClick={restoreDefault}>
                {t("ui.app.default")}
              </button>
              <button className="button button-primary" type="button" onClick={save}>
                {t("ui.app.save")}
              </button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function SettingsTab({
  settings,
  pathId,
  devMode,
  layoutMode,
  onSettingsChange,
  onLayoutChange,
}: {
  settings: CalculatorSettings;
  pathId: PathId;
  devMode: boolean;
  layoutMode: LayoutMode;
  onSettingsChange: Dispatch<SetStateAction<CalculatorSettings>>;
  onLayoutChange: (layout: LayoutMode) => void;
}) {
  const weaponsLocked = Boolean(typedPathDefinitions[pathId].lockedWeapons);

  return (
    <section className="panel settings-panel">
      <div className="settings-fields">
        <div className="settings-weapon-row">
          {settings.weapons.map((weapon, index) => (
            <label className="editor-field" key={index}>
              <span>{index === 0 ? t("system.gearSlot.leftWeapon") : t("system.gearSlot.rightWeapon")}</span>
              <select
                value={weapon}
                disabled={weaponsLocked}
                onChange={(event) =>
                  onSettingsChange((current) => {
                    const nextWeapon = event.target.value as WeaponId;
                    const otherWeapon = current.weapons[index === 0 ? 1 : 0];
                    if (pathId === "mixed" && nextWeapon === otherWeapon) return current;
                    const weapons: [WeaponId, WeaponId] = [...current.weapons] as [WeaponId, WeaponId];
                    weapons[index] = nextWeapon;
                    return { ...current, weapons };
                  })
                }
              >
                {Object.entries(martialArtDefinitions)
                  .filter(([value]) => devMode || productionWeaponIds.has(value as WeaponId))
                  .map(([value, definition]) => (
                    <option
                      key={value}
                      value={value}
                      disabled={pathId === "mixed" && value === settings.weapons[index === 0 ? 1 : 0]}
                    >
                      {gameText(definition.name)} ({gameText(weaponFamilyNames[definition.weapon])})
                    </option>
                  ))}
              </select>
            </label>
          ))}
        </div>
        <label className="editor-field ping-field">
          <span>{t("ui.app.ping")}</span>
          <PingInput
            value={settings.ping}
            onCommit={(ping) => onSettingsChange((current) => ({ ...current, ping: ping ?? 0 }))}
          />
        </label>
        <div className="settings-layout-row">
          <label className="editor-field">
            <span>{t("ui.app.layout")}</span>
            <select
              value={layoutMode}
              disabled={!devMode}
              onChange={(event) => onLayoutChange(event.target.value as LayoutMode)}
            >
              <option value="pc">{t("ui.app.pc")}</option>
              <option value="mobile">{t("ui.app.mobile")}</option>
            </select>
          </label>
        </div>
      </div>
    </section>
  );
}

function RotationEditorTab({
  character,
  pathId,
  devMode,
  defaultRotationId,
  selectedRotationId,
  calculationCache,
  skillOverrides,
  onSelectRotationWeapons,
  onActiveRotationChange,
  onMetricsChange,
  onActiveSimulationBundleChange,
  onGraduationDpsChange,
}: {
  character: CharacterState;
  pathId: PathId;
  devMode: boolean;
  defaultRotationId: string;
  selectedRotationId: string;
  calculationCache: RotationCalculationCache;
  skillOverrides: SkillOverrides;
  onSelectRotationWeapons: (weapons: [WeaponId, WeaponId], rotationId: string) => boolean;
  onActiveRotationChange: (id: string) => void;
  onMetricsChange: (metrics: RotationMetrics, isActive: boolean) => void;
  onActiveSimulationBundleChange: (
    bundle: RotationSimulationBundle,
    rotationName: string,
    bundleKey: string,
    isDefault: boolean,
    graduation?: { fingerprint: string; dps?: number },
  ) => void;
  onGraduationDpsChange: (fingerprint: string, dps: number) => void;
}) {
  const {
    stats: displayedCharacterStats,
    baseStats: rawCharacterStats,
    rawStats: talentFormulaStats,
    attunementStats,
    settings,
    enemy,
    innerWayRevision: _innerWayRevision,
    gearStatEffect,
    buildSetup,
  } = character;
  const rotationSkillIds = useMemo(() => selectableRotationSkillIds(settings.weapons), [settings.weapons]);
  const innerWayConditions = useMemo(() => innerWayConditionsFor(buildSetup.innerWays), [buildSetup.innerWays]);
  const soloLevel = breakthroughProfile(settings).soloLevel;
  const innerWayEffectRules = useMemo(
    () => innerWayEffectRulesFor(buildSetup.innerWays, soloLevel),
    [buildSetup.innerWays, soloLevel],
  );
  const calculationDefinitions = useMemo(
    () => resolveSkillCalculationDefinitions(defaultSkillMaps, effectDefinitions, dotDefinitions, skillOverrides),
    [skillOverrides],
  );
  const manualEffectMaxStacks = useMemo(() => {
    const maxStacks = new Map<string, number>();
    for (const [id, definition] of Object.entries(calculationDefinitions.effectDefinitions)) {
      const modifiedDefinition = innerWayEffectRules.reduce((current, rule) => {
        if (rule.target !== id || !rule.modify || rule.requirement !== undefined) return current;
        return mergeEffectDefinition(current, rule.modify);
      }, definition);
      maxStacks.set(id, modifiedDefinition.maxStack ?? 1);
    }
    return maxStacks;
  }, [calculationDefinitions.effectDefinitions, innerWayEffectRules]);
  const [initialState] = useState(() =>
    initialRotationEditorState(devMode, selectedRotationId || defaultRotationId, settings.weapons),
  );
  const [rotationEntries, setRotationEntries] = useState<RotationEntry[]>(initialState.entries);
  const savedRotationSnapshotsRef = useRef<Map<string, RotationRecord> | null>(null);
  if (savedRotationSnapshotsRef.current === null)
    savedRotationSnapshotsRef.current = new Map(
      initialState.entries.map((entry) => [entry.id, JSON.parse(JSON.stringify(entry.rotation)) as RotationRecord]),
    );
  const [editingRotationId, setEditingRotationId] = useState(initialState.activeId);
  const [rotation, setRotation] = useState<RotationRecord>(initialState.rotation);
  const [startAnchor, setStartAnchor] = useState<{ rowId: string; actionIndex?: number }>(initialState.startAnchor);
  const [expandedSkillRows, setExpandedSkillRows] = useState<Set<string>>(() => new Set());
  const [editingName, setEditingName] = useState(false);
  const setStatus = (message: string) => {
    if (message) publishNotice({ id: "rotation-save", message });
    else dismissNotice("rotation-save");
  };
  const [error, setError] = useState("");
  const [eventTimeDrafts, setEventTimeDrafts] = useState<Record<string, string>>({});
  const [eventDurationDrafts, setEventDurationDrafts] = useState<Record<string, string>>({});
  const [eventDistanceDrafts, setEventDistanceDrafts] = useState<Record<string, string>>({});
  const [eventHPDrafts, setEventHPDrafts] = useState<Record<string, string>>({});
  const [rotationResults, setRotationResults] = useState<
    Record<string, { key: string; result: RotationSimulationResult }>
  >({});
  const rotationResultsRef = useRef(rotationResults);
  const calculationCacheRef = useRef(calculationCache);
  const editorPreviewRequestSequenceRef = useRef(0);
  const diffRequestSequenceRef = useRef(0);
  const scheduledRefreshTargetRef = useRef<string | null>(null);
  const runningRefreshTargetRef = useRef<string | null>(null);
  const graduationFingerprintRef = useRef<string | null>(null);
  const [refreshRetryRevision, setRefreshRetryRevision] = useState(0);
  const [readableDialogOpen, setReadableDialogOpen] = useState(false);
  const [readableCopyStatus, setReadableCopyStatus] = useState("");
  const readableDialogRef = useRef<HTMLDialogElement>(null);
  const readableTextRef = useRef<HTMLTextAreaElement>(null);
  const rotationScrollRef = useRef<HTMLDivElement>(null);
  const pendingEventScrollRef = useRef<{ stepIndex: number; top: number } | null>(null);
  const pendingSkillFocusRef = useRef<number | null>(null);
  useEffect(
    () => () => {
      editorPreviewRequestSequenceRef.current += 1;
      diffRequestSequenceRef.current += 1;
      scheduledRefreshTargetRef.current = null;
      runningRefreshTargetRef.current = null;
    },
    [],
  );
  const listedRotationEntries = useMemo(
    () =>
      rotationEntries.filter(
        (entry) =>
          (devMode || !entry.test) && (!entry.isDefault || rotationAvailableForWeapons(entry, settings.weapons)),
      ),
    [devMode, rotationEntries, settings.weapons],
  );
  const compatibleRotationEntries = useMemo(
    () => listedRotationEntries.filter((entry) => rotationAvailableForWeapons(entry, settings.weapons)),
    [listedRotationEntries, settings.weapons],
  );
  const editingEntry =
    listedRotationEntries.find((entry) => entry.id === editingRotationId) ?? compatibleRotationEntries[0];
  const activeRotationId =
    compatibleRotationEntries.find((entry) => entry.id === selectedRotationId)?.id ??
    compatibleRotationEntries.find((entry) => entry.id === defaultRotationId)?.id ??
    compatibleRotationEntries[0]?.id;
  const resolvedActiveRotationIdRef = useRef(activeRotationId);
  resolvedActiveRotationIdRef.current = activeRotationId;
  const rotationLocked = editingEntry?.isDefault === true;
  const editingRotationDisplayName = (rotationLocked ? gameText(rotation.name) : rotation.name) || "Unnamed Rotation";
  const currentGlobalDebuffs = loadGlobalDebuffs();
  const currentFood = loadFood();
  const currentScript = loadScript();
  const currentDivinecraft = loadDivinecraft();
  const currentGlobalDebuffsKey = JSON.stringify(currentGlobalDebuffs);
  const calculationContextKey = useMemo(
    () =>
      calculationFingerprint({
        characterStats: rawCharacterStats,
        attunementStats,
        settings,
        enemy,
        innerWayConditions: [...innerWayConditions],
        innerWayEffectRules,
        innerWayRevision: _innerWayRevision,
        gearStatEffect,
        buildSetup,
        food: currentFood,
        script: currentScript,
        divinecraft: currentDivinecraft,
        globalDebuffs: currentGlobalDebuffs,
        skillOverrides,
      }),
    [
      rawCharacterStats,
      attunementStats,
      settings,
      enemy,
      innerWayConditions,
      innerWayEffectRules,
      _innerWayRevision,
      gearStatEffect,
      buildSetup,
      currentFood,
      currentScript,
      currentDivinecraft,
      currentGlobalDebuffsKey,
      skillOverrides,
    ],
  );
  const calculationContextKeyRef = useRef(calculationContextKey);
  calculationContextKeyRef.current = calculationContextKey;
  rotationResultsRef.current = rotationResults;

  function persistRotationEntries(entries: RotationEntry[]) {
    setPersistentItem(rotationListStorageKey, serializeRotationEntries(entries));
  }

  useEffect(() => {
    const migrated = migrateRotation(rotation);
    setRotation(migrated);
  }, []);

  useEffect(() => {
    if (activeRotationId && selectedRotationId !== activeRotationId) onActiveRotationChange(activeRotationId);
  }, [activeRotationId, onActiveRotationChange, selectedRotationId]);

  useEffect(() => {
    if (startAnchor.actionIndex === undefined) return;
    const key = `${editingRotationId}:${startAnchor.rowId}`;
    setExpandedSkillRows((current) => (current.has(key) ? current : new Set(current).add(key)));
  }, [editingRotationId, startAnchor.rowId, startAnchor.actionIndex]);

  useEffect(() => {
    const dialog = readableDialogRef.current;
    if (!dialog) return;
    if (readableDialogOpen && !dialog.open) dialog.showModal();
    else if (!readableDialogOpen && dialog.open) dialog.close();
  }, [readableDialogOpen]);

  function findSkill(skillId: string) {
    return calculationDefinitions.skills[skillId];
  }

  function updateStep(index: number, changes: Record<string, unknown>) {
    if (rotationLocked) return;
    setRotation((current) => ({
      ...current,
      steps: current.steps.map((step, stepIndex) =>
        stepIndex === index && !isAutomaticDelay(step) ? ({ ...step, ...changes } as RotationStep) : step,
      ),
    }));
  }
  function updateRotationCalculationSetting(value: SetStateAction<RotationRecord>) {
    scheduledRefreshTargetRef.current = null;
    setRotation(value);
  }
  function toggleAutoHP(checked: boolean) {
    if (rotationLocked) return;
    const removedBeforeStart = checked
      ? rotation.steps
          .slice(0, rotation.start?.step ?? 0)
          .filter((step) => step.type === "event" && step.event === "HP").length
      : 0;
    const nextStart = rotation.start
      ? { ...rotation.start, step: Math.max(0, rotation.start.step - removedBeforeStart) }
      : undefined;
    updateRotationCalculationSetting({
      ...rotation,
      ...(checked ? { autoHP: true } : { autoHP: undefined }),
      steps: checked ? rotation.steps.filter((step) => step.type !== "event" || step.event !== "HP") : rotation.steps,
      ...(nextStart ? { start: nextStart } : {}),
    });
    if (nextStart)
      setStartAnchor({
        rowId: `rotation-${nextStart.step}`,
        ...(nextStart.action === undefined ? {} : { actionIndex: nextStart.action }),
      });
  }
  function selectRotationItem(index: number, value: string, control: HTMLSelectElement) {
    if (rotationLocked) return;
    if (isAutomaticDelay(rotation.steps[index])) return;
    if (rotation.autoHP && value === "__event:HP") return;
    if (
      [
        "__event:Move",
        "__event:SelfHP",
        "__event:HP",
        "__event:Qi",
        "__event:Buff",
        "__event:Debuff",
        "__event:MartialArt",
      ].includes(value)
    ) {
      const scrollContainer = rotationScrollRef.current;
      const row = control.closest<HTMLElement>("[data-rotation-step-index]");
      if (scrollContainer && row)
        pendingEventScrollRef.current = {
          stepIndex: index,
          top: row.getBoundingClientRect().top - scrollContainer.getBoundingClientRect().top,
        };
    }
    const rowId = `rotation-${index}`;
    setEventDistanceDrafts((current) => {
      if (!(rowId in current)) return current;
      const next = { ...current };
      delete next[rowId];
      return next;
    });
    const previousSkills = timeline.filter(
      (row) => row.kind === "rotation" && (row.rotationIndex ?? -1) < index && row.step.type === "skill",
    );
    const previousSkill = previousSkills[previousSkills.length - 1];
    setRotation((current) => {
      if (
        value.startsWith("__event:") &&
        current.steps[index]?.type === "skill" &&
        current.steps.filter((step) => step.type === "skill").length <= 1
      )
        return current;
      let steps = current.steps.map((step, stepIndex) => {
        if (stepIndex !== index) return step;
        switch (value) {
          case "__event:Hellfire":
            return {
              type: "event",
              event: "Hellfire",
              startTime: previousSkill ? previousSkill.startTime - anchorTime : 0,
              amount: 0,
            };
          case "__event:Delay":
            return { type: "event", event: "Delay", duration: 1 };
          case "__event:Controlled":
            return {
              type: "event",
              event: "Controlled",
              startTime: previousSkill ? previousSkill.startTime - anchorTime : 0,
              duration: eventDefaultDuration("Controlled"),
            };
          case "__event:ShieldBroken":
            return {
              type: "event",
              event: "ShieldBroken",
              startTime: previousSkill ? previousSkill.startTime - anchorTime : 0,
            };
          case "__event:BattleEnd":
            return {
              type: "event",
              event: "BattleEnd",
              startTime: previousSkill ? previousSkill.startTime - anchorTime : 0,
            };
          case "__event:Move":
            return { type: "event", event: "Move", before: { action: "start" }, distance: 1 };
          case "__event:SelfHP":
            return {
              type: "event",
              event: "SelfHP",
              before: { action: "start" },
              currentHP: displayedCharacterStats.maxHp,
            };
          case "__event:TakeDamage":
            return {
              type: "event",
              event: "TakeDamage",
              startTime: previousSkill ? previousSkill.startTime - anchorTime : 0,
              damage: 0,
            };
          case "__event:HP":
            return { type: "event", event: "HP", before: { action: "start" }, targetHPRatio: 1 };
          case "__event:Qi":
            return { type: "event", event: "Qi", before: { action: "start" }, targetQiRatio: 1 };
          case "__event:Buff":
            return {
              type: "event",
              event: "Buff",
              before: { action: "start" },
              buff: Object.keys(manualBuffDefinitions)[0],
              stack: 1,
            };
          case "__event:Debuff":
            return {
              type: "event",
              event: "Debuff",
              before: { action: "start" },
              debuff: Object.keys(manualDebuffDefinitions)[0],
              stack: 1,
            };
          case "__event:MartialArt":
            return {
              type: "event",
              event: "MartialArt",
              before: { action: "start" },
              martialArt: settings.weapons[0],
            };
          default:
            return { type: "skill", skill: value };
        }
      }) as RotationStep[];
      const attached = [
        "__event:Move",
        "__event:SelfHP",
        "__event:HP",
        "__event:Qi",
        "__event:Buff",
        "__event:Debuff",
        "__event:MartialArt",
      ].includes(value);
      if (attached && !steps.slice(index + 1).some((step) => step.type === "skill"))
        steps.push({ type: "skill", skill: rotationSkillIds[0] });
      return { ...current, steps };
    });
  }
  function commitEventTime(rowId: string, stepIndex: number) {
    const draft = eventTimeDrafts[rowId];
    if (draft === undefined) return;
    const time = Number(draft);
    if (Number.isFinite(time)) updateStep(stepIndex, { startTime: time });
    setEventTimeDrafts((current) => {
      const next = { ...current };
      delete next[rowId];
      return next;
    });
  }
  function commitEventDuration(rowId: string, stepIndex: number) {
    const draft = eventDurationDrafts[rowId];
    if (draft === undefined) return;
    const duration = Number(draft);
    if (Number.isFinite(duration)) updateStep(stepIndex, { duration: Math.max(0, duration) });
    setEventDurationDrafts((current) => {
      const next = { ...current };
      delete next[rowId];
      return next;
    });
  }
  function commitEventDistance(rowId: string, stepIndex: number) {
    const draft = eventDistanceDrafts[rowId];
    if (draft === undefined) return;
    const distance = Number(draft);
    if (Number.isFinite(distance)) updateStep(stepIndex, { distance: Math.max(1, Math.floor(distance)) });
    setEventDistanceDrafts((current) => {
      const next = { ...current };
      delete next[rowId];
      return next;
    });
  }
  function commitEventHP(rowId: string, stepIndex: number) {
    const draft = eventHPDrafts[rowId];
    if (draft === undefined) return;
    const value = Number(draft);
    const step = rotation.steps[stepIndex];
    if (Number.isFinite(value) && step?.type === "event") {
      switch (step.event) {
        case "Hellfire":
          updateStep(stepIndex, { amount: value });
          break;
        case "SelfHP":
          updateStep(stepIndex, {
            currentHP: (Math.min(100, Math.max(0, value)) / 100) * displayedCharacterStats.maxHp,
            currentHPRatio: undefined,
          });
          break;
        case "TakeDamage":
          updateStep(stepIndex, { damage: Math.max(0, value) });
          break;
        case "HP":
          updateStep(stepIndex, { targetHPRatio: Math.min(1, Math.max(0, value / 100)) });
          break;
        case "Qi":
          updateStep(stepIndex, { targetQiRatio: Math.min(1, Math.max(0, value / 100)) });
          break;
      }
    }
    setEventHPDrafts((current) => {
      const next = { ...current };
      delete next[rowId];
      return next;
    });
  }
  function moveAttachedEvent(stepIndex: number, direction: -1 | 1, control: HTMLButtonElement) {
    if (rotationLocked) return;
    const eventStep = rotation.steps[stepIndex];
    const eventTarget = attachedTargetForStep(eventStep);
    if (eventStep?.type !== "event" || !eventTarget) return;
    const reordered = reorderAttachedEventWithinTarget(rotation.steps, stepIndex, direction);
    if (reordered) {
      const scrollContainer = rotationScrollRef.current;
      const eventElement = control.closest<HTMLElement>("[data-rotation-step-index]");
      if (scrollContainer && eventElement)
        pendingEventScrollRef.current = {
          stepIndex: reordered.movedIndex,
          top: eventElement.getBoundingClientRect().top - scrollContainer.getBoundingClientRect().top,
        };
      const startStep = rotation.start ? rotation.steps[rotation.start.step] : undefined;
      const nextStartStep = startStep ? reordered.steps.indexOf(startStep) : -1;
      setRotation({
        ...rotation,
        steps: reordered.steps,
        ...(rotation.start && nextStartStep >= 0 ? { start: { ...rotation.start, step: nextStartStep } } : {}),
      });
      if (nextStartStep >= 0 && rotation.start)
        setStartAnchor({ rowId: `rotation-${nextStartStep}`, actionIndex: rotation.start.action });
      return;
    }
    const eventAfterAction = attachedEventPhase(eventStep) === "after";
    const availableTargets =
      eventStep.event === "MartialArt"
        ? attachmentTargets.filter((target) => target.target.action === "start")
        : eventAfterAction
          ? attachmentTargets.filter((target) => target.target.action !== "start")
          : attachmentTargets;
    const eventRow = timeline.find((row) => row.id === `rotation-${stepIndex}`);
    const currentTargetIndex = availableTargets.findIndex(
      (target) =>
        target.sourceRowId === eventRow?.sourceRowId &&
        target.target.action === eventTarget.action &&
        target.target.trigger === eventTarget.trigger,
    );
    const nextTarget = availableTargets[currentTargetIndex + direction];
    if (!nextTarget) return;

    const startStep = rotation.start ? rotation.steps[rotation.start.step] : undefined;
    const currentTargetRow = timeline.find((row) => row.id === eventRow?.sourceRowId);
    const currentTargetStep =
      currentTargetRow?.rotationIndex === undefined ? undefined : rotation.steps[currentTargetRow.rotationIndex];
    const targetStep = rotation.steps[nextTarget.sourceStepIndex];
    const withoutEvent = rotation.steps.filter((_, index) => index !== stepIndex);
    const targetIndex = withoutEvent.indexOf(targetStep);
    if (targetIndex < 0) return;
    const movedEvent = eventAfterAction
      ? ({ ...eventStep, after: nextTarget.target } as RotationStep)
      : ({ ...eventStep, before: nextTarget.target } as RotationStep);
    const steps = [...withoutEvent.slice(0, targetIndex), movedEvent, ...withoutEvent.slice(targetIndex)];
    const movedEventIndex = steps.indexOf(movedEvent);
    const nextStartStep = startStep ? steps.indexOf(startStep) : -1;
    const nextRotation = {
      ...rotation,
      steps,
      ...(rotation.start && nextStartStep >= 0 ? { start: { ...rotation.start, step: nextStartStep } } : {}),
    };
    const scrollContainer = rotationScrollRef.current;
    const eventElement = control.closest<HTMLElement>("[data-rotation-step-index]");
    if (scrollContainer && eventElement)
      pendingEventScrollRef.current = {
        stepIndex: movedEventIndex,
        top: eventElement.getBoundingClientRect().top - scrollContainer.getBoundingClientRect().top,
      };
    setRotation(nextRotation);
    if (nextStartStep >= 0 && rotation.start)
      setStartAnchor({ rowId: `rotation-${nextStartStep}`, actionIndex: rotation.start.action });
    const movedTargetIndex = steps.indexOf(targetStep);
    const previousTargetIndex = currentTargetStep ? steps.indexOf(currentTargetStep) : -1;
    setExpandedSkillRows((current) => {
      const next = new Set(current);
      if (currentTargetStep !== targetStep) {
        if (currentTargetRow) next.delete(`${editingRotationId}:${currentTargetRow.id}`);
        if (previousTargetIndex >= 0) next.delete(`${editingRotationId}:rotation-${previousTargetIndex}`);
      }
      if (targetStep?.type === "skill" && nextTarget.target.action !== "start")
        next.add(`${editingRotationId}:rotation-${movedTargetIndex}`);
      return next;
    });
  }
  function addStepBelow(index: number) {
    if (rotationLocked) return;
    pendingSkillFocusRef.current = index + 1;
    setRotation((current) => ({
      ...current,
      steps: [
        ...current.steps.slice(0, index + 1),
        { type: "skill", skill: rotationSkillIds[0] },
        ...current.steps.slice(index + 1),
      ],
    }));
  }
  function moveStep(index: number, direction: number) {
    if (rotationLocked) return;
    setRotation((current) => {
      if (isAutomaticDelay(current.steps[index])) return current;
      const movable = (step: RotationStep | undefined) =>
        step?.type === "skill" || (step?.type === "event" && step.event === "Delay" && !isAutomaticDelay(step));
      if (!movable(current.steps[index])) return current;
      const attached = (step: RotationStep | undefined) => Boolean(attachedTargetForStep(step));
      let blockStart = index;
      if (current.steps[index]?.type === "skill")
        while (blockStart > 0 && attached(current.steps[blockStart - 1])) blockStart -= 1;
      const currentBlock = current.steps.slice(blockStart, index + 1);
      if (direction < 0) {
        let previousSkill = blockStart - 1;
        while (previousSkill >= 0 && !movable(current.steps[previousSkill])) previousSkill -= 1;
        if (previousSkill < 0) return current;
        let previousStart = previousSkill;
        if (current.steps[previousSkill]?.type === "skill")
          while (previousStart > 0 && attached(current.steps[previousStart - 1])) previousStart -= 1;
        return {
          ...current,
          steps: [
            ...current.steps.slice(0, previousStart),
            ...currentBlock,
            ...current.steps.slice(previousStart, blockStart),
            ...current.steps.slice(index + 1),
          ],
        };
      }
      let nextSkill = index + 1;
      while (nextSkill < current.steps.length && !movable(current.steps[nextSkill])) nextSkill += 1;
      if (nextSkill >= current.steps.length) return current;
      return {
        ...current,
        steps: [
          ...current.steps.slice(0, blockStart),
          ...current.steps.slice(index + 1, nextSkill + 1),
          ...currentBlock,
          ...current.steps.slice(nextSkill + 1),
        ],
      };
    });
  }
  function removeStep(index: number) {
    if (rotationLocked) return;
    setRotation((current) => {
      if (isAutomaticDelay(current.steps[index])) return current;
      if (current.steps[index]?.type !== "skill")
        return { ...current, steps: current.steps.filter((_, stepIndex) => stepIndex !== index) };
      if (current.steps.filter((step) => step.type === "skill").length <= 1) return current;
      let start = index;
      while (start > 0 && attachedTargetForStep(current.steps[start - 1])) start -= 1;
      return { ...current, steps: current.steps.filter((_, stepIndex) => stepIndex < start || stepIndex > index) };
    });
  }
  function selectStart(step: number, action?: number) {
    if (rotationLocked) return;
    setStartAnchor({ rowId: `rotation-${step}`, actionIndex: action });
    setRotation((current) => ({ ...current, start: { step, ...(action === undefined ? {} : { action }) } }));
  }
  function save() {
    if (rotationLocked) return;
    if (!rotation.name.trim()) {
      setError(t("ui.app.rotationNameRequired"));
      setStatus("");
      return;
    }
    const normalized = migrateRotation(rotation);
    const nextEntries = rotationEntries.map((entry) =>
      entry.id === editingRotationId && !entry.isDefault ? { ...entry, rotation: normalized } : entry,
    );
    setRotationEntries(nextEntries);
    setRotation(normalized);
    savedRotationSnapshotsRef.current?.set(editingRotationId, JSON.parse(JSON.stringify(normalized)) as RotationRecord);
    persistRotationEntries(nextEntries);
    setError("");
    setStatus(t("ui.app.savedForThisSession"));
    if (editingRotationId === activeRotationId && editorTimelineReady)
      void calculateDiffsForRotation(editingRotationId, normalized);
  }
  function resetRotation() {
    if (rotationLocked) return;
    const saved = savedRotationSnapshotsRef.current?.get(editingRotationId);
    if (!saved) return;
    const restored = JSON.parse(JSON.stringify(saved)) as RotationRecord;
    setRotation(restored);
    setStartAnchor(
      restored.start
        ? { rowId: `rotation-${restored.start.step}`, actionIndex: restored.start.action }
        : { rowId: "rotation-0" },
    );
    setEventTimeDrafts({});
    setEventDurationDrafts({});
    setEventDistanceDrafts({});
    setEventHPDrafts({});
    setEditingName(false);
    setStatus("");
    setError("");
  }
  function activateRotation(id: string) {
    if (id === activeRotationId) return;
    const current = migrateRotation(rotation);
    const nextEntries = rotationEntries.map((entry) =>
      entry.id === editingRotationId && !entry.isDefault ? { ...entry, rotation: current } : entry,
    );
    const nextEntry = nextEntries.find((entry) => entry.id === id);
    if (!nextEntry) return;
    const nextRotation = rotationRecordForEntry(nextEntry);
    setRotationEntries(nextEntries);
    onActiveRotationChange(id);
    setEditingRotationId(id);
    setRotation(JSON.parse(JSON.stringify(nextRotation)) as RotationRecord);
    setStartAnchor(
      nextRotation.start
        ? { rowId: `rotation-${nextRotation.start.step}`, actionIndex: nextRotation.start.action }
        : { rowId: "rotation-0" },
    );
    setEventTimeDrafts({});
    persistRotationEntries(nextEntries);
  }
  function editRotation(id: string) {
    if (id === editingRotationId) return;
    const current = migrateRotation(rotation);
    const nextEntries = rotationEntries.map((entry) =>
      entry.id === editingRotationId && !entry.isDefault ? { ...entry, rotation: current } : entry,
    );
    const nextEntry = nextEntries.find((entry) => entry.id === id);
    if (!nextEntry) return;
    const nextRotation = rotationRecordForEntry(nextEntry);
    setRotationEntries(nextEntries);
    setEditingRotationId(id);
    setRotation(JSON.parse(JSON.stringify(nextRotation)) as RotationRecord);
    setStartAnchor(
      nextRotation.start
        ? { rowId: `rotation-${nextRotation.start.step}`, actionIndex: nextRotation.start.action }
        : { rowId: "rotation-0" },
    );
    setEventTimeDrafts({});
    persistRotationEntries(nextEntries);
  }
  function selectRotation(entry: RotationEntry) {
    if (!rotationAvailableForWeapons(entry, settings.weapons)) {
      const entryMartialArts = [...new Set(entry.martialArts)];
      if (entryMartialArts.length !== 2) return;
      persistRotationEntries(currentRotationEntries());
      onSelectRotationWeapons([entryMartialArts[0], entryMartialArts[1]], entry.id);
      return;
    }
    editRotation(entry.id);
  }
  function addRotation() {
    const current = migrateRotation(rotation);
    const id = `rotation-${Date.now()}`;
    const nextRotation: RotationRecord = {
      name: t("ui.app.newRotation"),
      steps: [{ type: "skill", skill: rotationSkillIds[0] }],
      groupSize: 1,
      eventTimeReference: "battleStart",
    };
    const nextEntries = [
      ...rotationEntries.map((entry) =>
        entry.id === editingRotationId && !entry.isDefault ? { ...entry, rotation: current } : entry,
      ),
      { id, rotation: nextRotation, martialArts: [...new Set(settings.weapons)] },
    ];
    setRotationEntries(nextEntries);
    setEditingRotationId(id);
    setRotation(nextRotation);
    savedRotationSnapshotsRef.current?.set(id, JSON.parse(JSON.stringify(nextRotation)) as RotationRecord);
    setStartAnchor({ rowId: "rotation-0" });
    setEventTimeDrafts({});
    persistRotationEntries(nextEntries);
  }
  function duplicateRotation() {
    const id = `rotation-${Date.now()}`;
    const source = migrateRotation(rotation);
    const duplicate: RotationRecord = JSON.parse(
      JSON.stringify({ ...source, name: `${source.name || "Rotation"} Copy` }),
    ) as RotationRecord;
    const sourceEntry = rotationEntries.find((entry) => entry.id === editingRotationId);
    const nextEntries = [
      ...rotationEntries,
      { id, rotation: duplicate, martialArts: [...(sourceEntry?.martialArts ?? new Set(settings.weapons))] },
    ];
    setRotationEntries(nextEntries);
    setEditingRotationId(id);
    setRotation(duplicate);
    savedRotationSnapshotsRef.current?.set(id, JSON.parse(JSON.stringify(duplicate)) as RotationRecord);
    setStartAnchor(
      duplicate.start
        ? { rowId: `rotation-${duplicate.start.step}`, actionIndex: duplicate.start.action }
        : { rowId: "rotation-0" },
    );
    setEventTimeDrafts({});
    setEventDurationDrafts({});
    setEditingName(false);
    setStatus("");
    setError("");
    persistRotationEntries(nextEntries);
  }
  function removeRotation(id: string) {
    const entry = rotationEntries.find((candidate) => candidate.id === id);
    if (
      !entry ||
      entry.isDefault ||
      !window.confirm(
        t("ui.app.deleteNamedRotationConfirmation", {
          name: rotationEntryDisplayName(entry),
        }),
      )
    )
      return;
    if (listedRotationEntries.length <= 1) return;
    const nextEntries = rotationEntries.filter((entry) => entry.id !== id);
    savedRotationSnapshotsRef.current?.delete(id);
    if (id !== editingRotationId && id !== activeRotationId) {
      setRotationEntries(nextEntries);
      persistRotationEntries(nextEntries);
      return;
    }
    const nextVisibleEntries = nextEntries.filter((entry) => rotationAvailableForWeapons(entry, settings.weapons));
    const nextActive =
      nextVisibleEntries[Math.max(0, listedRotationEntries.findIndex((entry) => entry.id === id) - 1)] ??
      nextVisibleEntries[0];
    if (!nextActive) return;
    setRotationEntries(nextEntries);
    if (id === activeRotationId) {
      onActiveRotationChange(nextActive.id);
    }
    if (id === editingRotationId) {
      setEditingRotationId(nextActive.id);
      setRotation(JSON.parse(JSON.stringify(nextActive.rotation)) as RotationRecord);
      setStartAnchor(
        nextActive.rotation.start
          ? { rowId: `rotation-${nextActive.rotation.start.step}`, actionIndex: nextActive.rotation.start.action }
          : { rowId: "rotation-0" },
      );
    }
    setEventTimeDrafts({});
    persistRotationEntries(nextEntries);
  }

  function currentRotationEntries() {
    const current = migrateRotation(rotation);
    return rotationEntries.map((entry) =>
      entry.id === editingRotationId && !entry.isDefault ? { ...entry, rotation: current } : entry,
    );
  }

  function exportRotations() {
    const entries = currentRotationEntries();
    const exportedCount = entries.filter((entry) => !entry.isDefault).length;
    const blob = new Blob([exportRotationEntries(entries)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `where-builds-meet-rotations-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    publishNotice({ id: "rotation-transfer", message: t("ui.app.rotationsExported", { count: exportedCount }) });
  }

  async function importRotations(event: ChangeEvent<HTMLInputElement>) {
    const input = event.currentTarget;
    const file = input.files?.[0];
    input.value = "";
    if (!file) return;
    try {
      const result = mergeImportedRotationEntries(currentRotationEntries(), JSON.parse(await file.text()) as unknown);
      const migratedEntries = result.entries.map((entry) =>
        result.importedIds.includes(entry.id) ? { ...entry, rotation: migrateRotation(entry.rotation) } : entry,
      );
      result.importedIds.forEach((id) => {
        const imported = migratedEntries.find((entry) => entry.id === id);
        if (imported)
          savedRotationSnapshotsRef.current?.set(id, JSON.parse(JSON.stringify(imported.rotation)) as RotationRecord);
      });
      setRotationEntries(migratedEntries);
      persistRotationEntries(migratedEntries);
      const importedEntry = migratedEntries.find((entry) => entry.id === result.importedIds[0]);
      if (importedEntry) {
        setEditingRotationId(importedEntry.id);
        setRotation(JSON.parse(JSON.stringify(importedEntry.rotation)) as RotationRecord);
        setStartAnchor(
          importedEntry.rotation.start
            ? {
                rowId: `rotation-${importedEntry.rotation.start.step}`,
                actionIndex: importedEntry.rotation.start.action,
              }
            : { rowId: "rotation-0" },
        );
        setEventTimeDrafts({});
        setEventDurationDrafts({});
        setEditingName(false);
        setStatus("");
        setError("");
      }
      publishNotice({
        id: "rotation-transfer",
        message: t("ui.app.rotationsImported", { count: result.importedCount }),
      });
    } catch (error) {
      publishNotice({
        id: "rotation-transfer",
        message: error instanceof Error ? error.message : t("ui.app.rotationImportError"),
        error: true,
      });
    }
  }

  const currentCachedResult = rotationResults[editingRotationId]?.result;
  const editorRevision: EditorRevision = { id: editingRotationId, context: calculationContextKey, rotation };
  const editorRevisionRef = useRef(editorRevision);
  editorRevisionRef.current = editorRevision;
  const [editorTimelineState, setEditorTimelineState] = useState<EditorTimelineResult & { revision: EditorRevision }>();
  const editorTimelineReady = Boolean(
    editorTimelineState && sameEditorRevision(editorTimelineState.revision, editorRevision),
  );
  useEffect(() => {
    if (editorTimelineReady) return;
    const requested = editorRevisionRef.current;
    let cancelled = false;
    let timer: ReturnType<typeof window.setTimeout>;
    const current = () => !cancelled && sameEditorRevision(editorRevisionRef.current, requested);
    const run = async () => {
      try {
        const result = await requestEditorTimeline(calculationBundleFor(requested.rotation, false), {
          key: `editor:${requested.id}`,
          priority: 450,
        });
        if (!current()) return;
        setEditorTimelineState({ ...result, rotation: requested.rotation, revision: requested });
      } catch (error) {
        if (!current()) return;
        if (error instanceof Error && error.message.includes("superseded")) {
          timer = window.setTimeout(() => void run(), 150);
          return;
        }
        publishNotice({
          id: "editor-timeline",
          error: true,
          message: error instanceof Error ? error.message : t("ui.notices.calculationError"),
        });
      }
    };
    timer = window.setTimeout(() => void run(), 100);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [calculationContextKey, editingRotationId, rotation, editorTimelineReady]);
  const structuralTimeline = useMemo(
    () =>
      editorTimelineReady
        ? withUnresolvedEditorSteps(
            { rotation, skills: calculationDefinitions.skills, eventDefinitions: rotationEventDefinitions },
            editorTimelineState!.timeline,
          )
        : pendingEditorTimeline(
            { rotation, skills: calculationDefinitions.skills, eventDefinitions: rotationEventDefinitions },
            editorTimelineState?.revision.id === editingRotationId ? editorTimelineState : undefined,
          ),
    [rotation, calculationDefinitions, editingRotationId, editorTimelineReady, editorTimelineState],
  );
  const rotationSkillCount = useMemo(
    () => rotation.steps.filter((step) => step.type === "skill").length,
    [rotation.steps],
  );
  const timeline = useMemo(
    () =>
      editorTimelineReady && rotationResults[editingRotationId]?.key === editorTimelineState?.fingerprint
        ? mergeCalculatedTimelineState(structuralTimeline, currentCachedResult?.timeline)
        : structuralTimeline,
    [
      currentCachedResult?.timeline,
      structuralTimeline,
      editorTimelineReady,
      editorTimelineState,
      rotationResults,
      editingRotationId,
    ],
  );
  const anchorTime = useMemo(() => timelineAnchorTime(timeline, startAnchor), [startAnchor, timeline]);
  useLayoutEffect(() => {
    const scrollContainer = rotationScrollRef.current;
    const pendingScroll = pendingEventScrollRef.current;
    if (scrollContainer && pendingScroll) {
      const row = scrollContainer.querySelector<HTMLElement>(`[data-rotation-step-index="${pendingScroll.stepIndex}"]`);
      if (row) {
        const currentTop = row.getBoundingClientRect().top - scrollContainer.getBoundingClientRect().top;
        scrollContainer.scrollTop += currentTop - pendingScroll.top;
        pendingEventScrollRef.current = null;
      }
    }
    const pendingFocus = pendingSkillFocusRef.current;
    if (scrollContainer && pendingFocus !== null) {
      const select = scrollContainer.querySelector<HTMLSelectElement>(
        `select[data-rotation-step-index="${pendingFocus}"]`,
      );
      if (select) {
        select.focus({ preventScroll: true });
        select.scrollIntoView({ block: "nearest" });
        pendingSkillFocusRef.current = null;
      }
    }
  }, [timeline]);
  const editorCalculationReady =
    editorTimelineReady && rotationResults[editingRotationId]?.key === editorTimelineState?.fingerprint;
  const workerActionBreakdowns = editorCalculationReady ? (currentCachedResult?.actionBreakdowns ?? {}) : {};
  const displayTime = (time: number) => time - anchorTime;
  const calculateTimelineActionBreakdown = (row: TimelineRow, actionIndex: number): RotationActionBreakdown =>
    workerActionBreakdowns[`${row.id}:${actionIndex}`] ?? {
      physical: 0,
      bellstrike: 0,
      stonesplit: 0,
      silkbind: 0,
      bamboocut: 0,
      total: 0,
    };
  const skillExpansionKey = (rowId: string) => `${editingRotationId}:${rowId}`;
  const skillActionsExpanded = (rowId: string) => expandedSkillRows.has(skillExpansionKey(rowId));
  const toggleSkillActions = (rowId: string) =>
    setExpandedSkillRows((current) => {
      const next = new Set(current);
      const key = skillExpansionKey(rowId);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  const damageRowsByOwner = useMemo(() => {
    const result = new Map<string, TimelineRow[]>();
    for (const row of timeline) {
      const owner = row.kind === "rotation" || row.kind === "damageGroup" ? row.id : row.sourceRowId;
      if (!owner) continue;
      const rows = result.get(owner) ?? [];
      rows.push(row);
      result.set(owner, rows);
    }
    return result;
  }, [timeline]);
  const attachmentTargets = useMemo(() => {
    const triggeredRowsBySourceAndSkill = new Map<string, TimelineRow[]>();
    timeline.forEach((row) => {
      if (row.kind !== "trigger" || !row.sourceRowId || row.step.type !== "skill") return;
      const key = `${row.sourceRowId}:${row.step.skill}`;
      const matches = triggeredRowsBySourceAndSkill.get(key);
      if (matches) matches.push(row);
      else triggeredRowsBySourceAndSkill.set(key, [row]);
    });

    return timeline
      .filter((row) => row.kind === "rotation" && isAttachmentAnchorStep(row.step) && !row.skipped)
      .flatMap((sourceRow) => {
        const sourceStepIndex = sourceRow.rotationIndex ?? -1;
        const targets: Array<{
          sourceRowId: string;
          sourceStepIndex: number;
          target: AttachedEventTarget;
          time: number;
          order: number;
        }> = [];
        if (sourceRow.step.type === "skill")
          targets.push({
            sourceRowId: sourceRow.id,
            sourceStepIndex,
            target: { action: "start" },
            time: sourceRow.startTime,
            order: sourceRow.order,
          });
        sourceRow.actions.forEach((action, actionIndex) => {
          if (action.type === "damage" || action.type === "takeDamage")
            targets.push({
              sourceRowId: sourceRow.id,
              sourceStepIndex,
              target: { action: actionIndex },
              time: sourceRow.startTime + Number(action.time ?? 0),
              order: sourceRow.order + 10 + actionIndex,
            });
        });
        if (sourceRow.step.type !== "skill") return targets;
        const nextTriggeredRowBySkill = new Map<string, number>();
        let triggerOrdinal = 0;
        sourceRow.actions.forEach((action) => {
          if (action.type !== "trigger" || typeof action.value !== "string") return;
          const key = `${sourceRow.id}:${action.value}`;
          const matchIndex = nextTriggeredRowBySkill.get(action.value) ?? 0;
          const triggeredRow = triggeredRowsBySourceAndSkill.get(key)?.[matchIndex];
          nextTriggeredRowBySkill.set(action.value, matchIndex + 1);
          if (triggeredRow) {
            triggeredRow.actions.forEach((triggeredAction, actionIndex) => {
              if (triggeredAction.type === "damage")
                targets.push({
                  sourceRowId: sourceRow.id,
                  sourceStepIndex,
                  target: { trigger: triggerOrdinal, action: actionIndex },
                  time: triggeredRow.startTime + Number(triggeredAction.time ?? 0),
                  order: triggeredRow.order + 10 + actionIndex,
                });
            });
          }
          triggerOrdinal += 1;
        });
        return targets;
      })
      .sort((left, right) => compareTimelineTime(left.time, right.time) || left.order - right.order);
  }, [timeline]);
  const displayEntries = useMemo(() => {
    const actionsExpanded = (rowId: string) => expandedSkillRows.has(`${editingRotationId}:${rowId}`);
    return buildTimelineDisplayEntries(timeline, actionsExpanded, startAnchor);
  }, [editingRotationId, expandedSkillRows, startAnchor, timeline]);
  const showDistanceColumn = useMemo(
    () =>
      rotation.steps.some(
        (step) =>
          (step.type === "event" && step.event === "Move") ||
          (step.type === "skill" && findSkill(step.skill ?? "")?.tags?.includes("Distance")),
      ),
    [rotation.steps],
  );
  const showSelfHPColumn = useMemo(
    () =>
      rotation.dummyAttack === true ||
      rotation.steps.some(
        (step) =>
          (step.type === "event" && (step.event === "SelfHP" || step.event === "TakeDamage")) ||
          (step.type === "skill" && findSkill(step.skill ?? "")?.tags?.includes("HP")),
      ),
    [rotation.dummyAttack, rotation.steps],
  );
  const showTargetHPColumn = useMemo(
    () =>
      rotation.autoHP === true ||
      rotation.targetHP !== undefined ||
      rotation.steps.some((step) => step.type === "event" && step.event === "HP"),
    [rotation.autoHP, rotation.steps, rotation.targetHP],
  );
  const showQiColumn = useMemo(
    () => rotation.steps.some((step) => step.type === "event" && step.event === "Qi"),
    [rotation.steps],
  );
  const showHellfireColumn =
    settings.weapons.includes("infernalTwinblades") ||
    rotation.steps.some((step) => step.type === "event" && step.event === "Hellfire");
  const showHeavensWillColumn = settings.weapons.includes("heavenwill") && settings.weapons.includes("skygrasp");
  const showVitalityColumn = useMemo(
    () =>
      rotation.steps.some((step) => {
        if (step.type !== "skill") return false;
        const skill = findSkill(step.skill ?? "");
        return skill?.tags?.includes("Mystic") === true && skill.tags.includes("Triggered") === false;
      }),
    [rotation.steps],
  );
  const totalRotationTime = currentCachedResult?.duration ?? 0;
  const readableRotation = useMemo(
    () => (readableDialogOpen ? readableRotationText(timeline, startAnchor, anchorTime) : ""),
    [anchorTime, readableDialogOpen, startAnchor, timeline],
  );
  const totalRotationDamage = currentCachedResult?.metrics.totalDamage ?? 0;
  const rotationDps = currentCachedResult?.metrics.dps ?? 0;
  const totalRotationHealing = currentCachedResult?.metrics.totalHealing ?? 0;
  const rotationHps = currentCachedResult?.metrics.hps ?? 0;
  const applyPriorityStatLine = (key: keyof CharacterStats, amount: number) => {
    return { ...rawCharacterStats, [key]: rawCharacterStats[key] + amount };
  };
  const priorityLevelData = statRollsForLevel(enemy.level);
  const priorityCharacter = Object.fromEntries(
    Object.entries(priorityLevelData?.affix ?? {}).filter(([key]) =>
      characterStatAvailableForSettings(key as keyof CharacterStats, settings, pathId),
    ),
  ) as Partial<Record<keyof CharacterStats, number>>;
  const priorityAttunement = Object.keys(attunementData)
    .filter((key) => attunementAvailableForSettings(key, loadSelectedPath(), settings))
    .flatMap((key) => {
      const amount = maxGearRoll(key, "attunement", false, enemy.level);
      return typeof amount === "number" ? [[key, amount] as const] : [];
    });
  const selectedInnerWays = buildSetup.innerWays.filter(
    (row) => row.innerWay && innerWayAvailableForPath(row.innerWay),
  );
  const priorityStats: RotationPriority[] = [];
  const priorityAttunementRows: RotationPriority[] = [];
  const priorityInnerWays: RotationPriority[] = [];
  const setupComparisons: Record<string, RotationPriority[]> = {};
  function openReadableRotation() {
    setReadableCopyStatus("");
    setReadableDialogOpen(true);
  }
  async function copyReadableRotation() {
    try {
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(readableRotation);
      else {
        readableTextRef.current?.focus();
        readableTextRef.current?.select();
        if (!document.execCommand("copy")) throw new Error("Copy is unavailable");
      }
      setReadableCopyStatus(t("ui.app.copied"));
    } catch {
      readableTextRef.current?.focus();
      readableTextRef.current?.select();
      setReadableCopyStatus(t("ui.app.manualCopyInstruction"));
    }
  }
  function makeTimelineInput(
    rotationRecord: RotationRecord,
    conditions = innerWayConditions,
    rules = innerWayEffectRules,
    setupEffects = selectedSetupEffects(settings, gearStatEffect, buildSetup),
    globalDebuffs = currentGlobalDebuffs,
  ): TimelineBuildInput {
    return {
      rotation: { ...rotationRecord, ping: resolvePing(rotationRecord.ping, settings.ping) },
      skills: calculationDefinitions.skills,
      eventDefinitions: rotationEventDefinitions,
      dots: calculationDefinitions.dots,
      effectDefinitions: calculationDefinitions.effectDefinitions,
      innerWayConditions: [...conditions, ...setupConditionsFor(setupEffects)],
      innerWayRules: rules,
      setupEffects,
      weapons: settings.weapons,
      martialArtState: Object.fromEntries(
        settings.weapons.map((martialArt) => [martialArt, { weapon: martialArtDefinitions[martialArt].weapon }]),
      ),
      initialBuffs: globalBuffTimelineEffects(globalDebuffs),
      initialDebuffs: globalDebuffTimelineEffects(globalDebuffs),
      initialResources: {
        ...typedSystemStats.initialResources,
        Vitality: displayedCharacterStats.maxVitality,
      },
      resourceRegeneration: { HeavensWill: displayedCharacterStats.heavensWillRegen },
      resourceMaximums: {
        ...typedSystemStats.resourceMaximums,
        Vitality: displayedCharacterStats.maxVitality,
      },
      resourceEvents: typedSystemStats.resourceEvents,
      maxHP: displayedCharacterStats.maxHp,
    };
  }
  function calculationBundleFor(rotationRecord: RotationRecord, includeDiffs: boolean): RotationSimulationBundle {
    const rotationAnchor = rotationRecord.start
      ? { rowId: `rotation-${rotationRecord.start.step}`, actionIndex: rotationRecord.start.action }
      : { rowId: "rotation-0" };
    const baselineSetupEffects = selectedSetupEffects(settings, gearStatEffect, buildSetup);
    const setComparisonGroups = includeDiffs
      ? Object.fromEntries(
          (
            [
              ["weaponSets", typedWeaponSetDefinitions],
              ["armorSets", typedArmorSetDefinitions],
            ] as const
          ).flatMap(([key, definitions]) =>
            Object.entries(definitions)
              .filter(([, definition]) => setAvailableForSettings(definition, settings))
              .map(([setName]) => [
                `${key}:${setName}`,
                [0, 2, 4]
                  .filter((tier) => tier !== buildSetup[key][setName])
                  .map((tier) => {
                    const selections = selectSetTier(buildSetup[key], setName, tier as 0 | 2 | 4, definitions);
                    const setupEffects = selectedSetupEffects(settings, gearStatEffect, buildSetup, {
                      [key]: selections,
                    });
                    const rebuildTimeline = setSelectionChangesTimeline(buildSetup[key], selections, definitions);
                    return {
                      label: String(tier),
                      setupEffects,
                      ...(rebuildTimeline
                        ? {
                            timeline: makeTimelineInput(
                              rotationRecord,
                              innerWayConditions,
                              innerWayEffectRules,
                              setupEffects,
                            ),
                          }
                        : {}),
                    };
                  }),
              ]),
          ),
        )
      : {};
    const selectedFood = currentFood;
    const selectedScript = currentScript;
    const selectedDivinecraft = currentDivinecraft;
    return {
      timeline: makeTimelineInput(rotationRecord, innerWayConditions, innerWayEffectRules, baselineSetupEffects),
      startAnchor: rotationAnchor,
      stats: displayedCharacterStats,
      rawStats: talentFormulaStats,
      baseStats: rawCharacterStats,
      attunement: attunementStats,
      enemy,
      weapons: settings.weapons,
      statPriority: includeDiffs
        ? Object.entries(priorityCharacter).map(([key, amount]) => {
            const variantStats = applyPriorityStatLine(key as keyof CharacterStats, Number(amount));
            const definition = allStatDefinitions.find((candidate) => candidate.key === key);
            return {
              label: definition?.label ?? key,
              maxRoll: Number(amount) * (definition?.unit === "%" ? 100 : 1),
              stats: variantStats,
            };
          })
        : [],
      attunementPriority: includeDiffs
        ? priorityAttunement.map(([key, amount]) => {
            const variantAttunement = {
              ...attunementStats,
              [key]: attunementStats[key as keyof AttunementStats] + Number(amount),
            };
            return {
              label: attunementData[key]?.name ?? key,
              maxRoll: Number(amount) * (percentageAttunementKeys.has(key as keyof AttunementStats) ? 100 : 1),
              attunement: variantAttunement,
            };
          })
        : [],
      innerWayPriority: includeDiffs
        ? selectedInnerWays.map((selected) => {
            const definition = innerWayDefinitions[selected.innerWay as keyof typeof innerWayDefinitions];
            const variantRules = innerWayEffectRules.filter((rule) => rule.source !== selected.innerWay);
            const variantConditions = innerWayConditionsFor(buildSetup.innerWays, selected.innerWay);
            const setupEffects = baselineSetupEffects;
            return {
              label: definition?.name ?? selected.innerWay,
              ...(definition?.altersTimeline
                ? { timeline: makeTimelineInput(rotationRecord, variantConditions, variantRules, setupEffects) }
                : {}),
              innerWayRules: variantRules,
              innerWayConditions: [...variantConditions, ...setupConditionsFor(setupEffects)],
            };
          })
        : [],
      setupComparisons: includeDiffs
        ? {
            arsenal: Object.keys(typedArsenalDefinitions)
              .filter((value) => value !== buildSetup.arsenal)
              .map((value) => ({
                label: value,
                setupEffects: selectedSetupEffects(settings, gearStatEffect, buildSetup, { arsenal: value }),
              })),
            bowRingSet: Object.keys(typedBowRingSetDefinitions)
              .filter((value) => value !== buildSetup.bowRingSet)
              .map((value) => ({
                label: value,
                setupEffects: selectedSetupEffects(settings, gearStatEffect, buildSetup, { bowRingSet: value }),
              })),
            food: Object.keys(typedFoodDefinitions)
              .filter((value) => value !== selectedFood)
              .map((value) => ({
                label: value,
                setupEffects: selectedSetupEffects(settings, gearStatEffect, buildSetup, { food: value }),
              })),
            script: Object.entries(typedScriptDefinitions)
              .filter(([value]) => value !== selectedScript)
              .map(([value]) => {
                const setupEffects = selectedSetupEffects(settings, gearStatEffect, buildSetup, { script: value });
                const rebuildTimeline = setupSelectionChangesTimeline(selectedScript, value, typedScriptDefinitions);
                return {
                  label: value,
                  setupEffects,
                  ...(rebuildTimeline
                    ? {
                        timeline: makeTimelineInput(
                          rotationRecord,
                          innerWayConditions,
                          innerWayEffectRules,
                          setupEffects,
                        ),
                      }
                    : {}),
                };
              }),
            divinecraft: Object.entries(typedDivinecraftDefinitions)
              .filter(([value, definition]) => definition.available !== false && value !== selectedDivinecraft)
              .map(([value]) => {
                const setupEffects = selectedSetupEffects(settings, gearStatEffect, buildSetup, {
                  divinecraft: value,
                });
                const rebuildTimeline = setupSelectionChangesTimeline(
                  selectedDivinecraft,
                  value,
                  typedDivinecraftDefinitions,
                );
                return {
                  label: value,
                  setupEffects,
                  ...(rebuildTimeline
                    ? {
                        timeline: makeTimelineInput(
                          rotationRecord,
                          innerWayConditions,
                          innerWayEffectRules,
                          setupEffects,
                        ),
                      }
                    : {}),
                };
              }),
            ...Object.fromEntries(
              globalDebuffRows.map(({ key }) => [
                `debuff:${key}`,
                [false, true]
                  .filter((enabled) => enabled !== currentGlobalDebuffs[key])
                  .map((enabled) => {
                    const globalDebuffs = { ...currentGlobalDebuffs, [key]: enabled };
                    return {
                      label: enabled ? "on" : "off",
                      timeline: makeTimelineInput(
                        rotationRecord,
                        innerWayConditions,
                        innerWayEffectRules,
                        baselineSetupEffects,
                        globalDebuffs,
                      ),
                    };
                  }),
              ]),
            ),
            "debuff:qingyisCharm": (["none", "T1", "T6"] as const)
              .filter((value) => value !== currentGlobalDebuffs.qingyisCharm)
              .map((value) => {
                const globalDebuffs = { ...currentGlobalDebuffs, qingyisCharm: value };
                return {
                  label: value,
                  timeline: makeTimelineInput(
                    rotationRecord,
                    innerWayConditions,
                    innerWayEffectRules,
                    baselineSetupEffects,
                    globalDebuffs,
                  ),
                };
              }),
            "buff:floatingGrace": (["none", "mixed", "deluge"] as const)
              .filter((value) => value !== currentGlobalDebuffs.floatingGrace)
              .map((value) => {
                const globalDebuffs = { ...currentGlobalDebuffs, floatingGrace: value };
                return {
                  label: value,
                  timeline: makeTimelineInput(
                    rotationRecord,
                    innerWayConditions,
                    innerWayEffectRules,
                    baselineSetupEffects,
                    globalDebuffs,
                  ),
                };
              }),
            ...setComparisonGroups,
          }
        : ({} as Record<string, RotationSimulationVariant[]>),
    };
  }

  useEffect(() => {
    if (!activeRotationId) return;
    const activeEntry = rotationEntries.find((entry) => entry.id === activeRotationId);
    const activeRotation =
      activeRotationId === editingRotationId ? rotation : activeEntry ? rotationRecordForEntry(activeEntry) : undefined;
    if (activeRotation) {
      const graduation = prepareGraduationCalculation(activeRotation);
      graduationFingerprintRef.current = graduation?.fingerprint ?? null;
      const cachedGraduation = graduation
        ? calculationCacheRef.current.baseline(graduation.fingerprint)?.metrics.dps
        : undefined;
      onActiveSimulationBundleChange(
        calculationBundleFor(activeRotation, false),
        activeRotation.name || "Active rotation",
        `${activeRotationId}:${calculationContextKey}:${JSON.stringify(activeRotation)}`,
        activeEntry?.isDefault === true,
        graduation ? { fingerprint: graduation.fingerprint, dps: cachedGraduation } : undefined,
      );
    }
  }, [
    editingRotationId,
    rotation,
    rotationEntries,
    calculationContextKey,
    pathId,
    defaultRotationId,
    activeRotationId,
    onActiveSimulationBundleChange,
  ]);

  const prepareBaselineCalculation = (rotationRecord: RotationRecord) => {
    const bundle = calculationBundleFor(rotationRecord, false);
    return { bundle, fingerprint: rotationBundleFingerprint(bundle) };
  };
  const prepareGraduationCalculation = (rotationRecord: RotationRecord) => {
    const environment: GraduationEnvironment = {
      pathId,
      martialArts: [...settings.weapons],
      rotation: { ...rotationRecord, ping: resolvePing(rotationRecord.ping, settings.ping) },
      breakthrough: settings.breakthrough,
      globalDebuffs: currentGlobalDebuffs,
      food: currentFood,
      script: currentScript,
      divinecraft: currentDivinecraft,
      skillOverrides,
    };
    const bundle = buildPresetRotationBundle(environment, typedPathDefinitions[environment.pathId].graduated);
    return bundle
      ? {
          bundle,
          fingerprint: `graduation:${graduationEnvironmentFingerprint(environment)}`,
        }
      : undefined;
  };
  const workerCacheKeyFor = (fingerprint: string) => `rotation:${fingerprint}`;

  function storeBaselineResult(id: string, key: string, result: RotationSimulationResult) {
    const next = { ...rotationResultsRef.current, [id]: { key, result } };
    rotationResultsRef.current = next;
    setRotationResults(next);
  }

  async function calculateBaselineForRotation(
    id: string,
    rotationRecord: RotationRecord,
    priority = 100,
    prepared = prepareBaselineCalculation(rotationRecord),
  ) {
    const resultKey = prepared.fingerprint;
    const displayed = rotationResultsRef.current[id];
    if (displayed?.key === resultKey) {
      const cachedBaseline = calculationCacheRef.current.baseline(resultKey);
      if (cachedBaseline) return cachedBaseline;
    }
    const cachedBaseline = calculationCacheRef.current.baseline(resultKey);
    if (cachedBaseline) {
      storeBaselineResult(id, resultKey, cachedBaseline);
      return cachedBaseline;
    }
    const result = await requestRotationBaseline(prepared.bundle, workerCacheKeyFor(resultKey), {
      key: `baseline:${id}`,
      priority,
    });
    calculationCacheRef.current.storeBaseline(resultKey, result);
    storeBaselineResult(id, resultKey, result);
    return result;
  }

  async function calculateEditorPreview(id: string, rotationRecord: RotationRecord, requestSequence: number) {
    const prepared = prepareBaselineCalculation(rotationRecord);
    const resultKey = prepared.fingerprint;
    const refreshTarget = `${id}:${resultKey}`;
    const cachedBaseline = calculationCacheRef.current.baseline(resultKey);
    if (cachedBaseline) {
      if (editorPreviewRequestSequenceRef.current === requestSequence)
        storeBaselineResult(id, resultKey, cachedBaseline);
      return;
    }
    if (runningRefreshTargetRef.current === refreshTarget) return;
    const result = await requestRotationBaseline(prepared.bundle, workerCacheKeyFor(resultKey), {
      key: `preview:${id}`,
      priority: 200,
    });
    calculationCacheRef.current.storeBaseline(resultKey, result);
    if (editorPreviewRequestSequenceRef.current === requestSequence) storeBaselineResult(id, resultKey, result);
  }

  async function calculateGraduationDps(rotationRecord: RotationRecord) {
    const prepared = prepareGraduationCalculation(rotationRecord);
    if (!prepared) return;
    let baseline = calculationCacheRef.current.baseline(prepared.fingerprint);
    if (!baseline) {
      baseline = await requestRotationBaseline(prepared.bundle, workerCacheKeyFor(prepared.fingerprint), {
        key: "graduation",
        priority: 390,
      });
      calculationCacheRef.current.storeBaseline(prepared.fingerprint, baseline);
    }
    if (graduationFingerprintRef.current === prepared.fingerprint)
      onGraduationDpsChange(prepared.fingerprint, baseline.metrics.dps);
  }

  async function calculateDiffsForRotation(
    id: string,
    rotationRecord: RotationRecord,
    prepared = prepareBaselineCalculation(rotationRecord),
  ) {
    const requestSequence = ++diffRequestSequenceRef.current;
    supersedeRotationCalculationRequests();
    beginRotationCalculation();
    const contextKey = calculationContextKey;
    const resultKey = prepared.fingerprint;
    const refreshTarget = `${id}:${resultKey}`;
    scheduledRefreshTargetRef.current = refreshTarget;
    runningRefreshTargetRef.current = refreshTarget;
    try {
      const baseline = await calculateBaselineForRotation(id, rotationRecord, 400, prepared);
      if (calculationContextKeyRef.current !== contextKey) {
        if (diffRequestSequenceRef.current !== requestSequence) return "superseded" as const;
        endRotationCalculation();
        return "discarded" as const;
      }
      if (diffRequestSequenceRef.current !== requestSequence) return "superseded" as const;
      if (resolvedActiveRotationIdRef.current !== id) {
        endRotationCalculation();
        return "discarded" as const;
      }

      let metrics = baselineMetricsWithPreviousComparisons(baseline.metrics, getRotationMetrics());
      onMetricsChange(metrics, true);
      completeRotationCalculationCategory("baseline");

      try {
        await calculateGraduationDps(rotationRecord);
      } catch (graduationError) {
        if (diffRequestSequenceRef.current === requestSequence)
          publishNotice({
            id: "graduation-calculation",
            error: true,
            message: graduationError instanceof Error ? graduationError.message : t("ui.notices.calculationError"),
          });
      }
      if (diffRequestSequenceRef.current !== requestSequence) return "superseded" as const;

      const comparisonBundle = calculationBundleFor(rotationRecord, true);
      for (const category of comparisonCategoryOrder) {
        const variants = comparisonVariantRequests(comparisonBundle, category);
        if (variants.length === 0) {
          metrics = mergeComparisonCategory(metrics, baseline.metrics, category);
          onMetricsChange(metrics, true);
          completeRotationCalculationCategory(category);
          continue;
        }
        const variantMetrics: RotationMetrics[] = [];
        for (let index = 0; index < variants.length; index += 1) {
          const variant = variants[index];
          let calculated = calculationCacheRef.current.variant(resultKey, variant.key);
          if (!calculated) {
            calculated = await requestRotationComparisons(variant.bundle, workerCacheKeyFor(resultKey), baseline, {
              key: `diff:${id}:${category}:${variant.key}`,
              priority: 350,
              onProgress: (progress) => {
                if (diffRequestSequenceRef.current === requestSequence)
                  publishRotationCategoryProgress(category, (index + progress) / variants.length);
              },
            });
            calculationCacheRef.current.storeVariant(resultKey, variant.key, calculated);
          }
          variantMetrics.push(calculated);
          if (diffRequestSequenceRef.current === requestSequence)
            publishRotationCategoryProgress(category, (index + 1) / variants.length);
        }
        if (calculationContextKeyRef.current !== contextKey) {
          if (diffRequestSequenceRef.current !== requestSequence) return "superseded" as const;
          endRotationCalculation();
          return "discarded" as const;
        }
        if (diffRequestSequenceRef.current !== requestSequence) return "superseded" as const;
        if (resolvedActiveRotationIdRef.current !== id) {
          endRotationCalculation();
          return "discarded" as const;
        }
        metrics = combineComparisonVariantMetrics(metrics, variantMetrics, category);
        onMetricsChange(metrics, true);
        completeRotationCalculationCategory(category);
      }
      return "published" as const;
    } catch (calculationError) {
      if (diffRequestSequenceRef.current === requestSequence) endRotationCalculation();
      if (diffRequestSequenceRef.current !== requestSequence) return "superseded" as const;
      publishNotice({
        id: "rotation-calculation",
        error: true,
        message: calculationError instanceof Error ? calculationError.message : t("ui.notices.calculationError"),
      });
      return "failed" as const;
    } finally {
      if (diffRequestSequenceRef.current === requestSequence) runningRefreshTargetRef.current = null;
    }
  }

  const localRotationCalculation: RotationMetrics = {
    totalDamage: totalRotationDamage,
    dps: rotationDps,
    unscaledTotalDamage: currentCachedResult?.metrics.unscaledTotalDamage ?? totalRotationDamage,
    unscaledDps: currentCachedResult?.metrics.unscaledDps ?? rotationDps,
    totalHealing: totalRotationHealing,
    hps: rotationHps,
    breakdown: currentCachedResult?.metrics.breakdown ?? emptyRotationBreakdown(),
    statPriority: priorityStats,
    attunementPriority: priorityAttunementRows,
    innerWayPriority: priorityInnerWays,
    setupComparisons,
  };
  const rotationCalculation = currentCachedResult?.metrics ?? localRotationCalculation;

  useEffect(() => {
    const requestSequence = ++editorPreviewRequestSequenceRef.current;
    if (!editorTimelineReady) return;
    const timer = window.setTimeout(() => {
      void calculateEditorPreview(editingRotationId, rotation, requestSequence).catch((calculationError) => {
        if (editorPreviewRequestSequenceRef.current !== requestSequence) return;
        if (calculationError instanceof Error && calculationError.message.includes("superseded")) return;
        publishNotice({
          id: "rotation-preview",
          error: true,
          message: calculationError instanceof Error ? calculationError.message : t("ui.notices.calculationError"),
        });
      });
    }, 250);
    return () => {
      window.clearTimeout(timer);
      if (editorPreviewRequestSequenceRef.current === requestSequence) editorPreviewRequestSequenceRef.current += 1;
    };
  }, [calculationContextKey, editingRotationId, rotation, editorTimelineReady]);

  useEffect(() => {
    const entries = rotationEntries.filter((entry) => rotationAvailableForWeapons(entry, settings.weapons));
    const activeEntry =
      entries.find((entry) => entry.id === activeRotationId) ??
      entries.find((entry) => entry.id === defaultRotationId) ??
      entries[0];
    if (!activeEntry) return;
    if (activeEntry.id === editingRotationId && !editorTimelineReady) return;
    const activeRotation = activeEntry.id === editingRotationId ? rotation : rotationRecordForEntry(activeEntry);
    const prepared = prepareBaselineCalculation(activeRotation);
    const refreshTarget = `${activeEntry.id}:${prepared.fingerprint}`;
    if (scheduledRefreshTargetRef.current === refreshTarget) return;
    void (async () => {
      const outcome = await calculateDiffsForRotation(activeEntry.id, activeRotation, prepared);
      if (outcome === "discarded") {
        setRefreshRetryRevision((current) => current + 1);
        return;
      }
      if (outcome !== "published") return;
      if (calculationContextKeyRef.current !== calculationContextKey) return;
      for (const entry of entries) {
        if (entry.id === activeEntry.id) continue;
        try {
          await calculateBaselineForRotation(entry.id, rotationRecordForEntry(entry), 100);
        } catch {
          /* Superseded by newer work. */
        }
      }
    })();
  }, [
    activeRotationId,
    calculationContextKey,
    defaultRotationId,
    editingRotationId,
    refreshRetryRevision,
    editorTimelineReady,
    rotation,
    rotationEntries,
  ]);
  return (
    <section className="panel rotation-editor-panel">
      <div className="rotation-editor-layout">
        <aside className="rotation-list">
          <div className="rotation-list-heading">
            <span>{t("ui.app.rotations")}</span>
            <button className="button button-secondary button-small" type="button" onClick={addRotation}>
              {t("ui.app.newRotation")}
            </button>
          </div>
          <div className="rotation-list-entries">
            {listedRotationEntries.map((entry) => {
              const incompatible = !rotationAvailableForWeapons(entry, settings.weapons);
              return (
                <div
                  className={`rotation-list-item ${entry.id === activeRotationId ? "active" : ""} ${entry.id === editingRotationId ? "editing" : ""} ${incompatible ? "incompatible" : ""}`}
                  key={entry.id}
                  role="button"
                  tabIndex={0}
                  title={incompatible ? t("ui.app.selectThisRotationAndSwitchToItsMartial") : undefined}
                  onClick={() => selectRotation(entry)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" || event.key === " ") selectRotation(entry);
                  }}
                >
                  <strong>
                    {entry.id === activeRotationId && (
                      <span className="active-rotation-icon" title={t("ui.app.activeRotation")}>
                        <UiIcon name="active" />
                      </span>
                    )}
                    {rotationEntryDisplayName(entry)}
                  </strong>
                  {!entry.isDefault && (
                    <span className="rotation-list-actions">
                      <button
                        className="rotation-remove-button"
                        type="button"
                        aria-label={t("ui.app.removeNamedRotation", {
                          name: entry.rotation.name || t("ui.app.rotation"),
                        })}
                        title={t("ui.app.removeRotation")}
                        disabled={listedRotationEntries.length <= 1}
                        onClick={(event) => {
                          event.stopPropagation();
                          removeRotation(entry.id);
                        }}
                      >
                        <UiIcon name="close" />
                      </button>
                    </span>
                  )}
                </div>
              );
            })}
          </div>
          <div className="rotation-transfer-actions">
            <div>
              <button className="button button-secondary button-small" type="button" onClick={exportRotations}>
                {t("ui.app.export")}
              </button>
              <label className="button button-secondary button-small rotation-import-button">
                {t("ui.app.import")}
                <input
                  type="file"
                  accept="application/json,.json"
                  aria-label={t("ui.app.importRotations")}
                  onChange={importRotations}
                />
              </label>
            </div>
          </div>
        </aside>
        {editingEntry ? (
          <div className="rotation-editor-content">
            <div className="skill-detail-heading">
              <div>
                {editingName && !rotationLocked ? (
                  <input
                    className="rotation-name-input"
                    autoFocus
                    value={rotation.name}
                    onChange={(event) => setRotation({ ...rotation, name: event.target.value })}
                    onBlur={() => setEditingName(false)}
                    onKeyDown={(event) => {
                      if (event.key === "Enter") setEditingName(false);
                    }}
                  />
                ) : (
                  <h3>
                    {editingRotationDisplayName}
                    {!rotationLocked && (
                      <button
                        className="icon-button"
                        type="button"
                        aria-label={t("ui.app.editRotationName")}
                        onClick={() => setEditingName(true)}
                      >
                        <UiIcon name="edit" />
                      </button>
                    )}
                  </h3>
                )}
                {rotationLocked && (
                  <p className="rotation-default-note">{t("ui.app.thisIsAPrebuiltDefaultRotationAndCannot")}</p>
                )}
                <div className="rotation-target-controls">
                  <label className="rotation-option-toggle">
                    <input
                      type="checkbox"
                      disabled={rotationLocked}
                      checked={rotation.autoHP === true}
                      onChange={(event) => toggleAutoHP(event.target.checked)}
                    />
                    <span>{t("ui.app.autoHp")}</span>
                  </label>
                  <label className="rotation-target-hp">
                    <span>{t("ui.app.targetHp")}</span>
                    <input
                      type="number"
                      min="1"
                      step="1"
                      disabled={rotationLocked}
                      placeholder={t("ui.app.notSpecified")}
                      value={rotation.targetHP ?? ""}
                      onChange={(event) => {
                        const value = event.target.value;
                        const parsed = Number(value);
                        if (value !== "" && !Number.isFinite(parsed)) return;
                        updateRotationCalculationSetting((current) => ({
                          ...current,
                          ...(value === "" ? { targetHP: undefined } : { targetHP: Math.max(1, parsed) }),
                        }));
                      }}
                    />
                  </label>
                  <label className="rotation-option-toggle">
                    <input
                      type="checkbox"
                      disabled={rotationLocked}
                      checked={rotation.infiniteVitality === true}
                      onChange={(event) =>
                        updateRotationCalculationSetting((current) => ({
                          ...current,
                          infiniteVitality: event.target.checked,
                        }))
                      }
                    />
                    <span>{t("ui.app.infiniteVitality")}</span>
                  </label>
                  <label className="rotation-option-toggle">
                    <input
                      type="checkbox"
                      disabled={rotationLocked}
                      checked={rotation.dummyAttack === true}
                      onChange={(event) =>
                        updateRotationCalculationSetting((current) => ({
                          ...current,
                          dummyAttack: event.target.checked,
                        }))
                      }
                    />
                    <span>{t("ui.app.dummyAttack")}</span>
                  </label>
                  <label className="rotation-group-size">
                    <span>{t("ui.app.groupType")}</span>
                    <select
                      disabled={rotationLocked}
                      value={rotation.groupSize ?? 1}
                      onChange={(event) => {
                        const groupSize = Number(event.target.value);
                        if (groupSize !== 1 && groupSize !== 5 && groupSize !== 10) return;
                        updateRotationCalculationSetting((current) => ({ ...current, groupSize }));
                      }}
                    >
                      <option value={1}>{t("ui.app.solo")}</option>
                      <option value={5}>{t("ui.app.team")}</option>
                      <option value={10}>{t("ui.app.group")}</option>
                    </select>
                  </label>
                  <RotationPingField
                    key={editingRotationId}
                    value={rotation.ping}
                    inheritedValue={settings.ping}
                    disabled={rotationLocked}
                    onCommit={(ping) => updateRotationCalculationSetting((current) => ({ ...current, ping }))}
                  />
                </div>
              </div>
              <div className="detail-active-actions">
                <span className="rotation-heading-actions">
                  <button
                    className="button button-secondary button-small"
                    type="button"
                    disabled={timeline.length === 0}
                    onClick={openReadableRotation}
                  >
                    {t("ui.app.readableFormat")}
                  </button>
                  {!rotationLocked && (
                    <>
                      <button className="button button-secondary button-small" type="button" onClick={resetRotation}>
                        {t("ui.app.reset")}
                      </button>
                      <button className="button button-primary button-small" type="button" onClick={save}>
                        {t("ui.app.save")}
                      </button>
                    </>
                  )}
                  <span className="rotation-activation-actions">
                    <button className="button button-secondary button-small" type="button" onClick={duplicateRotation}>
                      {t("ui.app.duplicate")}
                    </button>
                    <button
                      className="button button-small detail-active-button"
                      type="button"
                      disabled={editingRotationId === activeRotationId}
                      onClick={() => activateRotation(editingRotationId)}
                    >
                      {editingRotationId === activeRotationId ? t("ui.app.active") : t("ui.app.makeActive")}
                    </button>
                  </span>
                </span>
              </div>
            </div>
            <div className="rotation-toolbar">
              <span>
                {rotation.steps.filter((step) => step.type === "skill").length} {t("ui.app.steps")}{" "}
                {formatNumber(totalRotationTime)}
                {t("ui.app.sTotalTime")}
              </span>
              <span className="rotation-results">
                <span>
                  {t("system.totalDamage")}: {formatDamageNumber(rotationCalculation.unscaledTotalDamage)}
                </span>
                {rotationCalculation.totalHealing > 0 ? (
                  <span className="healing-value">
                    {t("system.totalHealing")}: +{formatDamageNumber(rotationCalculation.totalHealing)}
                  </span>
                ) : null}
                <span>
                  {t("system.dps")}: {formatDamageNumber(rotationCalculation.unscaledDps)}
                  {rotationCalculation.hps > 0 ? (
                    <span className="healing-value">
                      {" / "}
                      {t("system.hps")}: {formatDamageNumber(rotationCalculation.hps)}
                    </span>
                  ) : null}
                </span>
              </span>
            </div>
            <div className="rotation-scroll-content" ref={rotationScrollRef}>
              <div
                className="rotation-table"
                style={
                  {
                    "--rotation-state-columns": [
                      showDistanceColumn ? "10ch" : "",
                      showSelfHPColumn ? "8ch" : "",
                      showTargetHPColumn ? "8ch" : "",
                      showQiColumn ? "8ch" : "",
                      showHellfireColumn ? "10ch" : "",
                      showHeavensWillColumn ? "13ch" : "",
                      showVitalityColumn ? "10ch" : "",
                    ]
                      .filter(Boolean)
                      .join(" "),
                    minInlineSize: `${67.5 + (Number(showDistanceColumn) + Number(showSelfHPColumn) + Number(showTargetHPColumn) + Number(showQiColumn)) * 5.3125 + Number(showHellfireColumn) * 5.3125 + Number(showHeavensWillColumn) * 6.875 + Number(showVitalityColumn) * 5.3125}rem`,
                  } as CSSProperties
                }
              >
                <div className="rotation-table-header">
                  <span></span>
                  <span>#</span>
                  <span>{t("ui.app.startTime")}</span>
                  <span>{t("ui.app.castTime")}</span>
                  <span>{t("ui.app.skill")}</span>
                  {showDistanceColumn && <span>{t("ui.app.distance")}</span>}
                  {showSelfHPColumn && <span>{t("ui.app.selfHp")}</span>}
                  {showTargetHPColumn && <span>{t("ui.app.hp")}</span>}
                  {showQiColumn && <span>{t("ui.app.qi")}</span>}
                  {showHellfireColumn && <span>{t("system.resource.hellfire")}</span>}
                  {showHeavensWillColumn && <span>{t("system.resource.heavensWill")}</span>}
                  {showVitalityColumn && <span>{t("system.resource.vitality")}</span>}
                  <span className="rotation-damage-heading">{t("ui.app.damage")}</span>
                  <span>{t("ui.app.buff")}</span>
                  <span>{t("ui.app.debuff")}</span>
                  <span>{t("ui.app.actions")}</span>
                </div>
                <div className="rotation-step-list">
                  {displayEntries.map((entry) => {
                    const row = entry.row;
                    if (row.kind === "damageGroup") {
                      const groupSkillId = row.step.type === "skill" ? row.step.skill : undefined;
                      const damage =
                        currentCachedResult?.metrics.breakdown.casts.find((cast) => cast.skillId === groupSkillId)
                          ?.damage ?? 0;
                      return (
                        <div className="rotation-row-group" key={`${row.id}-summary`}>
                          <div className="rotation-table-row">
                            <span aria-hidden="true" />
                            <span aria-hidden="true" />
                            <span aria-hidden="true" />
                            <span aria-hidden="true" />
                            <span className="rotation-skill-name">
                              <RotationSkillName skill={row.skill} fallback={groupSkillId ?? ""} />
                            </span>
                            {showDistanceColumn && <span aria-hidden="true" />}
                            {showSelfHPColumn && <span aria-hidden="true" />}
                            {showTargetHPColumn && <span aria-hidden="true" />}
                            {showQiColumn && <span aria-hidden="true" />}
                            {showHellfireColumn && <span aria-hidden="true" />}
                            {showHeavensWillColumn && <span aria-hidden="true" />}
                            {showVitalityColumn && <span aria-hidden="true" />}
                            <span className="rotation-damage-value" data-mobile-label={t("ui.app.damage")}>
                              {formatDamageNumber(damage)}
                            </span>
                            <span aria-hidden="true" />
                            <span aria-hidden="true" />
                            <span aria-hidden="true" />
                          </div>
                        </div>
                      );
                    }
                    const isAction = entry.kind === "action";
                    const { step, startTime, skill } = row;
                    const castTime = row.effectiveCastTime;
                    const effectNames = (
                      effects: Array<{
                        name: string;
                        stack?: number;
                        maxStack?: number;
                        remainingTriggers?: number;
                        expiresAt?: number;
                        hideRemainingTime?: boolean;
                        averageStackOnly?: boolean;
                      }>,
                      atTime: number,
                    ) =>
                      effects.length === 0 ? (
                        ""
                      ) : (
                        <span className="effect-plates">
                          {effects.map((effect) => {
                            const definition = calculationDefinitions.effectDefinitions[effect.name];
                            const description = gameText(definition?.description?.trim());
                            const name = gameText(definition?.name ?? effect.name);
                            const showStack =
                              effect.stack !== undefined &&
                              (effect.maxStack === undefined ||
                                effect.maxStack > 1 ||
                                (effect.averageStackOnly && Math.abs(effect.stack - 1) > 1e-9));
                            const label = `${gameText(definition?.shortName) || name}${showStack ? ` ×${formatNumber(effect.stack ?? 0)}` : ""}`;
                            const timeLeft =
                              effect.expiresAt === undefined ? "∞" : Math.max(0, effect.expiresAt - atTime).toFixed(2);
                            const finiteListener = definition?.listen?.find(
                              (listener) =>
                                typeof listener.maxTriggers === "number" &&
                                Number.isFinite(listener.maxTriggers) &&
                                listener.action?.type === "trigger" &&
                                typeof listener.action.value === "string",
                            );
                            const triggerSkillId = finiteListener?.action?.value;
                            const remainingTriggerName =
                              typeof triggerSkillId === "string"
                                ? gameText(calculationDefinitions.skills[triggerSkillId]?.name ?? triggerSkillId)
                                : "";
                            const plateKind = dotEffectIds.has(effect.name)
                              ? " effect-plate-dot"
                              : generalDebuffIds.has(effect.name)
                                ? " effect-plate-general-debuff"
                                : "";
                            return (
                              <span className={`effect-plate${plateKind}`} key={`${effect.name}-${effect.stack ?? 1}`}>
                                {label}
                                <span className="effect-plate-tooltip" role="tooltip">
                                  {effect.averageStackOnly ? (
                                    <span>
                                      {t("ui.app.averageStack")}: {formatNumber(effect.stack ?? 0)}
                                    </span>
                                  ) : (
                                    <>
                                      {effect.remainingTriggers !== undefined && remainingTriggerName ? (
                                        <>
                                          <strong>{name}</strong>
                                          <span>
                                            {t("ui.app.remainingTriggerCount", {
                                              name: remainingTriggerName,
                                              number: effect.remainingTriggers,
                                            })}
                                          </span>
                                          {!effect.hideRemainingTime ? (
                                            <span>{t("ui.app.sLeft", { number: timeLeft })}</span>
                                          ) : null}
                                        </>
                                      ) : (
                                        <strong>
                                          {effect.hideRemainingTime
                                            ? name
                                            : `${name} - ${t("ui.app.sLeft", { number: timeLeft })}`}
                                        </strong>
                                      )}
                                      {description ? <span>{description}</span> : null}
                                    </>
                                  )}
                                </span>
                              </span>
                            );
                          })}
                        </span>
                      );
                    const actionIndex = entry.actionIndex;
                    const actionTime = entry.time;
                    const isManualEvent = step.type === "event";
                    const isDelayEvent = isManualEvent && step.event === "Delay";
                    const isProtectedDelay = isAutomaticDelay(step);
                    const isGeneratedEvent =
                      step.type === "event" &&
                      step.event === "TakeDamage" &&
                      "automatic" in step &&
                      step.automatic === "dummyAttack";
                    const rowReadOnly = rotationLocked || isGeneratedEvent;
                    const resolvedTakeDamage =
                      step.type === "event" && step.event === "TakeDamage"
                        ? Number(row.actions.find((action) => action.type === "takeDamage")?.damage ?? step.damage)
                        : 0;
                    const skillNumber =
                      step.type === "skill" && row.rotationIndex !== undefined
                        ? rotation.steps.slice(0, row.rotationIndex).filter((candidate) => candidate.type === "skill")
                            .length
                        : "";
                    const attachedTarget = attachedTargetForStep(step);
                    const isAttachedEvent = Boolean(attachedTarget);
                    const availableAttachmentTargets =
                      step.type === "event" && step.event === "MartialArt"
                        ? attachmentTargets.filter((target) => target.target.action === "start")
                        : attachedEventPhase(step) === "after"
                          ? attachmentTargets.filter((target) => target.target.action !== "start")
                          : attachmentTargets;
                    const attachedTargetIndex = attachedTarget
                      ? availableAttachmentTargets.findIndex(
                          (target) =>
                            target.sourceRowId === row.sourceRowId &&
                            target.target.action === attachedTarget.action &&
                            target.target.trigger === attachedTarget.trigger,
                        )
                      : -1;
                    const attachedSiblingAbove =
                      row.rotationIndex === undefined
                        ? -1
                        : attachedEventSiblingIndex(rotation.steps, row.rotationIndex, -1);
                    const attachedSiblingBelow =
                      row.rotationIndex === undefined
                        ? -1
                        : attachedEventSiblingIndex(rotation.steps, row.rotationIndex, 1);
                    const stepSkill = step.type === "skill" ? step.skill : undefined;
                    const actionsExpanded = skillActionsExpanded(row.id);
                    const actionState =
                      actionIndex === undefined
                        ? undefined
                        : (row.actionStates[actionIndex] ?? {
                            buffs: row.buffs,
                            debuffs: row.debuffs,
                            distance: row.distance,
                            currentHPRatio: row.currentHPRatio,
                            targetHPRatio: row.targetHPRatio,
                            targetQiRatio: row.targetQiRatio,
                            resources: row.resources,
                          });
                    const selfHPMaximum = Math.max(1, displayedCharacterStats.maxHp);
                    const selfHPPercentage = (actionState?.currentHPRatio ?? row.currentHPRatio) * 100;
                    const selfHPEventPercentage =
                      step.type === "event" && step.event === "SelfHP"
                        ? ("currentHP" in step && typeof step.currentHP === "number"
                            ? step.currentHP / selfHPMaximum
                            : (step.currentHPRatio ?? 1)) * 100
                        : selfHPPercentage;
                    const durationEvent =
                      isManualEvent && (step.event === "Controlled" || step.event === "Delay") ? step.event : undefined;
                    const editableCastTime = step.type === "skill" && row.skill?.editableCastTime === true;
                    let durationValue = 0;
                    switch (step.type) {
                      case "skill":
                        durationValue = step.duration ?? baseSkillCastTime(row.skill);
                        break;
                      case "event":
                        if (durationEvent)
                          durationValue =
                            ("duration" in step ? step.duration : undefined) ??
                            (durationEvent === "Delay" ? 1 : eventDefaultDuration(durationEvent));
                        break;
                    }
                    const actionBuffs =
                      actionState?.buffs.filter(
                        (effect) => effect.expiresAt === undefined || effect.expiresAt > actionTime,
                      ) ?? [];
                    const actionDebuffs =
                      actionState?.debuffs.filter(
                        (effect) => effect.expiresAt === undefined || effect.expiresAt > actionTime,
                      ) ?? [];
                    const skillDamageRows =
                      !isAction && row.kind === "rotation" ? (damageRowsByOwner.get(row.id) ?? [row]) : [row];
                    const skillExpectedBuffStacks = skillDamageRows.reduce<
                      { time: number; stacks: Record<string, number> } | undefined
                    >((earliest, damageRow) => {
                      let next = earliest;
                      damageRow.actions.forEach((action, damageIndex) => {
                        if (action.type !== "damage") return;
                        const expectedBuffStacks =
                          workerActionBreakdowns[`${damageRow.id}:${damageIndex}`]?.expectedBuffStacks;
                        if (!expectedBuffStacks) return;
                        const time = damageRow.startTime + Number(action.time ?? 0);
                        if (!next || time < next.time) next = { time, stacks: expectedBuffStacks };
                      });
                      return next;
                    }, undefined);
                    const displayedSkillBuffs = withExpectedOutcomeBuffPlates(
                      row.buffs,
                      skillExpectedBuffStacks?.stacks,
                    );
                    const skillBreakdown = skillDamageRows.reduce<RotationActionBreakdown>(
                      (skillTotal, damageRow) =>
                        damageRow.actions.reduce<RotationActionBreakdown>((total, action, damageIndex) => {
                          if (action.type !== "damage" && action.type !== "replay" && action.type !== "heal")
                            return total;
                          const breakdown = calculateTimelineActionBreakdown(damageRow, damageIndex);
                          const physicalHealing = (total.healing?.physical ?? 0) + (breakdown.healing?.physical ?? 0);
                          const silkbindHealing = (total.healing?.silkbind ?? 0) + (breakdown.healing?.silkbind ?? 0);
                          const totalHealing = (total.healing?.total ?? 0) + (breakdown.healing?.total ?? 0);
                          return {
                            physical: total.physical + breakdown.physical,
                            bellstrike: total.bellstrike + breakdown.bellstrike,
                            stonesplit: total.stonesplit + breakdown.stonesplit,
                            silkbind: total.silkbind + breakdown.silkbind,
                            bamboocut: total.bamboocut + breakdown.bamboocut,
                            total: total.total + breakdown.total,
                            ...(totalHealing > 0
                              ? {
                                  healing: {
                                    physical: physicalHealing,
                                    silkbind: silkbindHealing,
                                    total: totalHealing,
                                  },
                                }
                              : {}),
                          };
                        }, skillTotal),
                      {
                        physical: 0,
                        bellstrike: 0,
                        stonesplit: 0,
                        silkbind: 0,
                        bamboocut: 0,
                        total: 0,
                      } as RotationActionBreakdown,
                    );
                    return (
                      <div className="rotation-row-group" key={`${row.id}-${entry.kind}-${actionIndex ?? "skill"}`}>
                        {!isAction && (
                          <div
                            className={`rotation-table-row ${isManualEvent ? "rotation-event-row" : ""} ${isManualEvent && step.event === "Move" ? "rotation-move-event-row" : ""} ${isManualEvent && step.event === "TakeDamage" ? "rotation-take-damage-event-row" : ""}`}
                            data-rotation-step-index={row.rotationIndex}
                          >
                            {row.kind === "rotation" ? (
                              <button
                                className={`start-marker ${startAnchor.rowId === row.id && startAnchor.actionIndex === undefined ? "active" : ""}`}
                                type="button"
                                aria-label={t("ui.app.setFightStartHere")}
                                disabled={rowReadOnly || isProtectedDelay}
                                onClick={() => selectStart(row.rotationIndex ?? 0)}
                              >
                                {startAnchor.rowId === row.id && startAnchor.actionIndex === undefined ? "→" : "•"}
                              </button>
                            ) : (
                              <span aria-hidden="true" />
                            )}
                            <span className="rotation-index">{skillNumber}</span>
                            <span className="rotation-mobile-field" data-mobile-label={t("ui.app.startTime")}>
                              {isManualEvent ? (
                                isAttachedEvent || isDelayEvent || rowReadOnly ? (
                                  <span>
                                    {formatNumber(displayTime(startTime))}
                                    {t("ui.app.s")}
                                  </span>
                                ) : (
                                  <input
                                    className="rotation-event-time"
                                    type="number"
                                    step="0.01"
                                    value={eventTimeDrafts[row.id] ?? formatNumber(displayTime(startTime))}
                                    onChange={(event) =>
                                      setEventTimeDrafts((current) => ({ ...current, [row.id]: event.target.value }))
                                    }
                                    onBlur={() => commitEventTime(row.id, row.rotationIndex ?? 0)}
                                    onKeyDown={(event) => {
                                      if (event.key === "Enter") event.currentTarget.blur();
                                    }}
                                  />
                                )
                              ) : (
                                <span>
                                  {formatNumber(displayTime(startTime))}
                                  {t("ui.app.s")}
                                </span>
                              )}
                            </span>
                            <span className="rotation-mobile-field" data-mobile-label={t("ui.app.castTime")}>
                              {durationEvent || editableCastTime ? (
                                rowReadOnly || isProtectedDelay ? (
                                  <span>
                                    {formatNumber(durationValue)}
                                    {t("ui.app.s")}
                                  </span>
                                ) : (
                                  <input
                                    className="rotation-event-time"
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    value={eventDurationDrafts[row.id] ?? String(durationValue)}
                                    onChange={(event) =>
                                      setEventDurationDrafts((current) => ({
                                        ...current,
                                        [row.id]: event.target.value,
                                      }))
                                    }
                                    onBlur={() => commitEventDuration(row.id, row.rotationIndex ?? 0)}
                                    onKeyDown={(event) => {
                                      if (event.key === "Enter") event.currentTarget.blur();
                                    }}
                                  />
                                )
                              ) : isAttachedEvent ? null : (
                                <span>
                                  {isManualEvent ? "" : row.kind === "rotation" ? `${formatNumber(castTime)}s` : "—"}
                                </span>
                              )}
                            </span>
                            {row.kind === "rotation" ? (
                              rowReadOnly || isProtectedDelay ? (
                                <span className="rotation-skill-name">
                                  {isManualEvent ? (
                                    <span>{rotationEventDisplayName(step.event)}</span>
                                  ) : (
                                    <RotationSkillName skill={skill} fallback={stepSkill ?? ""} />
                                  )}
                                </span>
                              ) : (
                                <span className="rotation-skill-select-wrap">
                                  <RotationSkillName
                                    skill={isManualEvent ? undefined : skill}
                                    fallback={isManualEvent ? rotationEventDisplayName(step.event) : (stepSkill ?? "")}
                                  />
                                  <select
                                    className="rotation-skill-select"
                                    data-rotation-step-index={row.rotationIndex}
                                    aria-label={t("ui.app.skillOrEvent")}
                                    value={isManualEvent ? `__event:${step.event}` : (stepSkill ?? "")}
                                    onChange={(event) =>
                                      selectRotationItem(
                                        row.rotationIndex ?? 0,
                                        event.target.value,
                                        event.currentTarget,
                                      )
                                    }
                                  >
                                    {stepSkill && !rotationSkillIds.includes(stepSkill) && (
                                      <option value={stepSkill} disabled>
                                        {skillDisplayName(findSkill(stepSkill), stepSkill)} {t("ui.app.unavailable")}
                                      </option>
                                    )}
                                    {rotationSkillIds.map((id) => (
                                      <option key={id} value={id}>
                                        {skillDisplayName(findSkill(id), id)}
                                      </option>
                                    ))}
                                    {rotationEventOptionIds
                                      .filter((id) => !rotation.autoHP || id !== "__event:HP")
                                      .map((id) => (
                                        <option key={id} value={id}>
                                          {rotationEventDisplayName(id.slice(8))}
                                        </option>
                                      ))}
                                  </select>
                                </span>
                              )
                            ) : (
                              <span className="rotation-skill-name">
                                <RotationSkillName skill={skill} fallback={stepSkill ?? ""} />
                              </span>
                            )}
                            {showDistanceColumn && (
                              <span data-mobile-label={t("ui.app.distance")}>
                                {isManualEvent && step.event === "Move" ? (
                                  rowReadOnly ? (
                                    <span>
                                      {step.distance}
                                      {t("ui.app.m")}
                                    </span>
                                  ) : (
                                    <span className="rotation-distance-input-wrap">
                                      <input
                                        className="rotation-event-time"
                                        aria-label={t("ui.app.distanceAfterMove")}
                                        type="number"
                                        min="1"
                                        step="1"
                                        value={eventDistanceDrafts[row.id] ?? String(step.distance)}
                                        onChange={(event) =>
                                          setEventDistanceDrafts((current) => ({
                                            ...current,
                                            [row.id]: event.target.value,
                                          }))
                                        }
                                        onBlur={() => commitEventDistance(row.id, row.rotationIndex ?? 0)}
                                        onKeyDown={(event) => {
                                          if (event.key === "Enter") event.currentTarget.blur();
                                        }}
                                      />
                                      <span>{t("ui.app.m")}</span>
                                    </span>
                                  )
                                ) : (
                                  <span>
                                    {formatNumber(row.distance)}
                                    {t("ui.app.m")}
                                  </span>
                                )}
                              </span>
                            )}
                            {showSelfHPColumn && (
                              <span data-mobile-label={t("ui.app.selfHp")}>
                                {isManualEvent && step.event === "TakeDamage" ? (
                                  rowReadOnly ? (
                                    <span>{formatDamageNumber(resolvedTakeDamage)}</span>
                                  ) : (
                                    <span className="rotation-distance-input-wrap">
                                      <input
                                        className="rotation-event-time"
                                        aria-label={t("ui.app.damageTaken")}
                                        type="number"
                                        min="0"
                                        step="0.01"
                                        value={eventHPDrafts[row.id] ?? String(step.damage)}
                                        onChange={(event) =>
                                          setEventHPDrafts((current) => ({ ...current, [row.id]: event.target.value }))
                                        }
                                        onBlur={() => commitEventHP(row.id, row.rotationIndex ?? 0)}
                                        onKeyDown={(event) => {
                                          if (event.key === "Enter") event.currentTarget.blur();
                                        }}
                                      />
                                    </span>
                                  )
                                ) : isManualEvent && step.event === "SelfHP" ? (
                                  rotationLocked ? (
                                    <span>{formatNumber(selfHPEventPercentage)}%</span>
                                  ) : (
                                    <span className="rotation-distance-input-wrap">
                                      <input
                                        className="rotation-event-time"
                                        aria-label={t("ui.app.currentSelfHp")}
                                        type="number"
                                        min="0"
                                        max="100"
                                        step="0.01"
                                        value={eventHPDrafts[row.id] ?? String(selfHPEventPercentage)}
                                        onChange={(event) =>
                                          setEventHPDrafts((current) => ({ ...current, [row.id]: event.target.value }))
                                        }
                                        onBlur={() => commitEventHP(row.id, row.rotationIndex ?? 0)}
                                        onKeyDown={(event) => {
                                          if (event.key === "Enter") event.currentTarget.blur();
                                        }}
                                      />
                                      <span>%</span>
                                    </span>
                                  )
                                ) : (
                                  <span>{formatNumber(row.currentHPRatio * 100)}%</span>
                                )}
                              </span>
                            )}
                            {showTargetHPColumn && (
                              <span data-mobile-label={t("ui.app.hp")}>
                                {isManualEvent && step.event === "HP" ? (
                                  rotationLocked ? (
                                    <span>{formatNumber(step.targetHPRatio * 100)}%</span>
                                  ) : (
                                    <span className="rotation-distance-input-wrap">
                                      <input
                                        className="rotation-event-time"
                                        aria-label={t("ui.app.targetHpPercentage")}
                                        type="number"
                                        min="0"
                                        max="100"
                                        step="0.01"
                                        value={eventHPDrafts[row.id] ?? String(step.targetHPRatio * 100)}
                                        onChange={(event) =>
                                          setEventHPDrafts((current) => ({ ...current, [row.id]: event.target.value }))
                                        }
                                        onBlur={() => commitEventHP(row.id, row.rotationIndex ?? 0)}
                                        onKeyDown={(event) => {
                                          if (event.key === "Enter") event.currentTarget.blur();
                                        }}
                                      />
                                      <span>%</span>
                                    </span>
                                  )
                                ) : (
                                  <span>{formatNumber(row.targetHPRatio * 100)}%</span>
                                )}
                              </span>
                            )}
                            {showQiColumn && (
                              <span data-mobile-label={t("ui.app.qi")}>
                                {isManualEvent && step.event === "Qi" ? (
                                  rotationLocked ? (
                                    <span>{formatNumber(step.targetQiRatio * 100)}%</span>
                                  ) : (
                                    <span className="rotation-distance-input-wrap">
                                      <input
                                        className="rotation-event-time"
                                        aria-label={t("ui.app.targetQiPercentage")}
                                        type="number"
                                        min="0"
                                        max="100"
                                        step="0.01"
                                        value={eventHPDrafts[row.id] ?? String(step.targetQiRatio * 100)}
                                        onChange={(event) =>
                                          setEventHPDrafts((current) => ({ ...current, [row.id]: event.target.value }))
                                        }
                                        onBlur={() => commitEventHP(row.id, row.rotationIndex ?? 0)}
                                        onKeyDown={(event) => {
                                          if (event.key === "Enter") event.currentTarget.blur();
                                        }}
                                      />
                                      <span>%</span>
                                    </span>
                                  )
                                ) : (
                                  <span>{formatNumber(row.targetQiRatio * 100)}%</span>
                                )}
                              </span>
                            )}
                            {showHellfireColumn && (
                              <span
                                className="rotation-hellfire-value"
                                data-full={(row.resources.Hellfire ?? 0) >= typedSystemStats.resourceMaximums.Hellfire}
                                data-flamelash={row.buffs.some((buff) => buff.name === "Flamelash")}
                                data-mobile-label={t("system.resource.hellfire")}
                              >
                                {isManualEvent && step.event === "Hellfire" ? (
                                  rowReadOnly ? (
                                    <span>
                                      {step.amount > 0 ? "+" : ""}
                                      {formatNumber(step.amount)}
                                    </span>
                                  ) : (
                                    <input
                                      className="rotation-event-time"
                                      aria-label={t("ui.app.hellfireChange")}
                                      title={t("ui.app.hellfireChange")}
                                      type="number"
                                      step="0.01"
                                      value={eventHPDrafts[row.id] ?? String(step.amount)}
                                      onChange={(event) =>
                                        setEventHPDrafts((current) => ({ ...current, [row.id]: event.target.value }))
                                      }
                                      onBlur={() => commitEventHP(row.id, row.rotationIndex ?? 0)}
                                      onKeyDown={(event) => {
                                        if (event.key === "Enter") event.currentTarget.blur();
                                      }}
                                    />
                                  )
                                ) : (
                                  formatNumber(row.resources.Hellfire ?? 0)
                                )}
                              </span>
                            )}
                            {showHeavensWillColumn && (
                              <span data-mobile-label={t("system.resource.heavensWill")}>
                                {formatNumber(row.resources.HeavensWill ?? 0)}
                              </span>
                            )}
                            {showVitalityColumn && (
                              <span data-mobile-label={t("system.resource.vitality")}>
                                {rotation.infiniteVitality
                                  ? "∞"
                                  : formatResourceRange(row.resources.Vitality ?? 0, row.resourceRanges?.Vitality)}
                              </span>
                            )}
                            <span className="rotation-damage-value" data-mobile-label={t("ui.app.damage")}>
                              {isManualEvent ? (
                                step.event === "MartialArt" ? (
                                  rotationLocked ? (
                                    <span>{gameText(martialArtDefinitions[step.martialArt].name)}</span>
                                  ) : (
                                    <select
                                      className="rotation-martial-art-select"
                                      aria-label={t("ui.app.martialArtToSwitchTo")}
                                      value={step.martialArt}
                                      onChange={(event) =>
                                        updateStep(row.rotationIndex ?? 0, {
                                          martialArt: event.target.value as WeaponId,
                                        })
                                      }
                                    >
                                      {!settings.weapons.includes(step.martialArt) && (
                                        <option value={step.martialArt} disabled>
                                          {gameText(martialArtDefinitions[step.martialArt].name)}{" "}
                                          {t("ui.app.unavailable")}
                                        </option>
                                      )}
                                      {settings.weapons.map((martialArt) => (
                                        <option value={martialArt} key={martialArt}>
                                          {gameText(martialArtDefinitions[martialArt].name)}
                                        </option>
                                      ))}
                                    </select>
                                  )
                                ) : (
                                  ""
                                )
                              ) : step.type === "skill" &&
                                (skillBreakdown.total > 0 || (skillBreakdown.healing?.total ?? 0) > 0) ? (
                                <RotationActionBreakdownValue breakdown={skillBreakdown} />
                              ) : (
                                ""
                              )}
                            </span>
                            <span data-mobile-label={t("ui.app.buff")}>
                              {isManualEvent && step.event === "Buff" ? (
                                rotationLocked ? (
                                  <span>
                                    {calculationDefinitions.effectDefinitions[step.buff]?.name ?? step.buff}
                                    {(step.stack ?? 1) > 1 ? ` ×${step.stack}` : ""}
                                  </span>
                                ) : (
                                  <span
                                    className={`rotation-effect-event-control ${(manualEffectMaxStacks.get(step.buff) ?? 1) <= 1 ? "single" : ""}`}
                                  >
                                    <select
                                      className="rotation-effect-select"
                                      aria-label={t("ui.app.buffToApply")}
                                      value={step.buff}
                                      onChange={(event) => {
                                        const buff = event.target.value;
                                        updateStep(row.rotationIndex ?? 0, {
                                          buff,
                                          stack: Math.min(step.stack ?? 1, manualEffectMaxStacks.get(buff) ?? 1),
                                        });
                                      }}
                                    >
                                      {Object.keys(manualBuffDefinitions).map((id) => (
                                        <option value={id} key={id}>
                                          {calculationDefinitions.effectDefinitions[id]?.name ?? id}
                                        </option>
                                      ))}
                                    </select>
                                    {(manualEffectMaxStacks.get(step.buff) ?? 1) > 1 && (
                                      <input
                                        className="rotation-effect-stack"
                                        aria-label={t("ui.app.buffStacks")}
                                        type="number"
                                        min="1"
                                        max={manualEffectMaxStacks.get(step.buff) ?? 1}
                                        step="1"
                                        value={step.stack ?? 1}
                                        onChange={(event) => {
                                          const stack = Number(event.target.value);
                                          if (Number.isFinite(stack))
                                            updateStep(row.rotationIndex ?? 0, {
                                              stack: Math.max(
                                                1,
                                                Math.min(manualEffectMaxStacks.get(step.buff) ?? 1, Math.floor(stack)),
                                              ),
                                            });
                                        }}
                                      />
                                    )}
                                  </span>
                                )
                              ) : isManualEvent ? (
                                ""
                              ) : (
                                effectNames(displayedSkillBuffs, startTime)
                              )}
                            </span>
                            <span data-mobile-label={t("ui.app.debuff")}>
                              {isManualEvent && step.event === "Debuff" ? (
                                rotationLocked ? (
                                  <span>
                                    {calculationDefinitions.effectDefinitions[step.debuff]?.name ?? step.debuff}
                                    {(step.stack ?? 1) > 1 ? ` ×${step.stack}` : ""}
                                  </span>
                                ) : (
                                  <span
                                    className={`rotation-effect-event-control ${(manualEffectMaxStacks.get(step.debuff) ?? 1) <= 1 ? "single" : ""}`}
                                  >
                                    <select
                                      className="rotation-effect-select"
                                      aria-label={t("ui.app.debuffToApply")}
                                      value={step.debuff}
                                      onChange={(event) => {
                                        const debuff = event.target.value;
                                        updateStep(row.rotationIndex ?? 0, {
                                          debuff,
                                          stack: Math.min(step.stack ?? 1, manualEffectMaxStacks.get(debuff) ?? 1),
                                        });
                                      }}
                                    >
                                      {Object.keys(manualDebuffDefinitions).map((id) => (
                                        <option value={id} key={id}>
                                          {calculationDefinitions.effectDefinitions[id]?.name ?? id}
                                        </option>
                                      ))}
                                    </select>
                                    {(manualEffectMaxStacks.get(step.debuff) ?? 1) > 1 && (
                                      <input
                                        className="rotation-effect-stack"
                                        aria-label={t("ui.app.debuffStacks")}
                                        type="number"
                                        min="1"
                                        max={manualEffectMaxStacks.get(step.debuff) ?? 1}
                                        step="1"
                                        value={step.stack ?? 1}
                                        onChange={(event) => {
                                          const stack = Number(event.target.value);
                                          if (Number.isFinite(stack))
                                            updateStep(row.rotationIndex ?? 0, {
                                              stack: Math.max(
                                                1,
                                                Math.min(
                                                  manualEffectMaxStacks.get(step.debuff) ?? 1,
                                                  Math.floor(stack),
                                                ),
                                              ),
                                            });
                                        }}
                                      />
                                    )}
                                  </span>
                                )
                              ) : isManualEvent ? (
                                ""
                              ) : (
                                effectNames(row.debuffs, startTime)
                              )}
                            </span>
                            <span className="rotation-controls">
                              {isAttachedEvent && (
                                <>
                                  <span className="rotation-control-placeholder" aria-hidden="true" />
                                  <button
                                    type="button"
                                    aria-label={t("ui.app.moveEventToPreviousAction")}
                                    disabled={rotationLocked || (attachedSiblingAbove < 0 && attachedTargetIndex <= 0)}
                                    onClick={(event) =>
                                      moveAttachedEvent(row.rotationIndex ?? 0, -1, event.currentTarget)
                                    }
                                  >
                                    <UiIcon name="up" />
                                  </button>
                                  <button
                                    type="button"
                                    aria-label={t("ui.app.moveEventToNextAction")}
                                    disabled={
                                      rotationLocked ||
                                      (attachedSiblingBelow < 0 &&
                                        (attachedTargetIndex < 0 ||
                                          attachedTargetIndex >= availableAttachmentTargets.length - 1))
                                    }
                                    onClick={(event) =>
                                      moveAttachedEvent(row.rotationIndex ?? 0, 1, event.currentTarget)
                                    }
                                  >
                                    <UiIcon name="down" />
                                  </button>
                                </>
                              )}
                              {row.kind === "rotation" && !isManualEvent && (
                                <button
                                  className="rotation-expand-button"
                                  type="button"
                                  aria-label={t("ui.app.toggleNamedSkillActions", {
                                    action: actionsExpanded ? t("ui.app.collapse") : t("ui.app.expand"),
                                    name: skillDisplayName(skill, stepSkill ?? t("ui.app.skillFallback")),
                                  })}
                                  aria-expanded={actionsExpanded}
                                  onClick={() => toggleSkillActions(row.id)}
                                >
                                  <UiIcon name={actionsExpanded ? "chevronDown" : "chevronRight"} />
                                </button>
                              )}
                              {row.kind === "rotation" && (!isManualEvent || isDelayEvent) && !isProtectedDelay && (
                                <>
                                  <button
                                    type="button"
                                    aria-label={t("ui.app.moveUp")}
                                    disabled={rotationLocked || (row.rotationIndex ?? 0) === 0}
                                    onClick={() => moveStep(row.rotationIndex ?? 0, -1)}
                                  >
                                    <UiIcon name="up" />
                                  </button>
                                  <button
                                    type="button"
                                    aria-label={t("ui.app.moveDown")}
                                    disabled={rotationLocked || (row.rotationIndex ?? 0) === rotation.steps.length - 1}
                                    onClick={() => moveStep(row.rotationIndex ?? 0, 1)}
                                  >
                                    <UiIcon name="down" />
                                  </button>
                                </>
                              )}{" "}
                              {row.kind === "rotation" && !isProtectedDelay && !isGeneratedEvent && (
                                <>
                                  <button
                                    type="button"
                                    aria-label={t("ui.app.deleteStep")}
                                    disabled={rotationLocked || (!isManualEvent && rotationSkillCount <= 1)}
                                    onClick={() => removeStep(row.rotationIndex ?? 0)}
                                  >
                                    <UiIcon name="close" />
                                  </button>
                                  {(!isManualEvent || isDelayEvent) && (
                                    <button
                                      type="button"
                                      aria-label={t("ui.app.addStepBelow")}
                                      disabled={rotationLocked}
                                      onClick={() => addStepBelow(row.rotationIndex ?? 0)}
                                    >
                                      <UiIcon name="plus" />
                                    </button>
                                  )}
                                </>
                              )}
                              {isAttachedEvent && <span className="rotation-control-placeholder" aria-hidden="true" />}
                            </span>
                          </div>
                        )}
                        {isAction &&
                          (() => {
                            const actionKey = `${row.id}:${actionIndex ?? 0}`;
                            const actionCalculated = Object.prototype.hasOwnProperty.call(
                              workerActionBreakdowns,
                              actionKey,
                            );
                            const actionBreakdown = workerActionBreakdowns[actionKey];
                            const expectedBuffStacks = actionBreakdown?.expectedBuffStacks;
                            const displayedActionBuffs = withExpectedOutcomeBuffPlates(actionBuffs, expectedBuffStacks);
                            return (
                              <div
                                className={`rotation-action-row ${row.kind === "trigger" ? "rotation-action-trigger" : row.kind === "dot" ? "rotation-action-dot" : ""}`}
                              >
                                {row.kind === "rotation" ? (
                                  <button
                                    className={`start-marker ${startAnchor.rowId === row.id && startAnchor.actionIndex === actionIndex ? "active" : ""}`}
                                    type="button"
                                    aria-label={t("ui.app.setFightStartHere")}
                                    disabled={rotationLocked}
                                    onClick={() => selectStart(row.rotationIndex ?? 0, actionIndex)}
                                  >
                                    {startAnchor.rowId === row.id && startAnchor.actionIndex === actionIndex
                                      ? "→"
                                      : "•"}
                                  </button>
                                ) : (
                                  <span aria-hidden="true" />
                                )}
                                <span aria-hidden="true" />
                                <span className="rotation-mobile-field" data-mobile-label={t("ui.app.startTime")}>
                                  {formatNumber(displayTime(actionTime))}
                                  {t("ui.app.s")}
                                </span>
                                <span aria-hidden="true" />
                                <span>
                                  <RotationSkillName skill={skill} fallback={stepSkill ?? ""} />
                                </span>
                                {showDistanceColumn && (
                                  <span data-mobile-label={t("ui.app.distance")}>
                                    {formatNumber(actionState?.distance ?? row.distance)}
                                    {t("ui.app.m")}
                                  </span>
                                )}
                                {showSelfHPColumn && (
                                  <span data-mobile-label={t("ui.app.selfHp")}>{formatNumber(selfHPPercentage)}%</span>
                                )}
                                {showTargetHPColumn && (
                                  <span data-mobile-label={t("ui.app.hp")}>
                                    {formatNumber((actionState?.targetHPRatio ?? row.targetHPRatio) * 100)}%
                                  </span>
                                )}
                                {showQiColumn && (
                                  <span data-mobile-label={t("ui.app.qi")}>
                                    {formatNumber((actionState?.targetQiRatio ?? row.targetQiRatio) * 100)}%
                                  </span>
                                )}
                                {showHellfireColumn && (
                                  <span
                                    className="rotation-hellfire-value"
                                    data-full={
                                      (actionState?.resources.Hellfire ?? row.resources.Hellfire ?? 0) >=
                                      typedSystemStats.resourceMaximums.Hellfire
                                    }
                                    data-flamelash={(actionState?.buffs ?? row.buffs).some(
                                      (buff) => buff.name === "Flamelash",
                                    )}
                                    data-mobile-label={t("system.resource.hellfire")}
                                  >
                                    {formatNumber(actionState?.resources.Hellfire ?? row.resources.Hellfire ?? 0)}
                                  </span>
                                )}
                                {showHeavensWillColumn && (
                                  <span data-mobile-label={t("system.resource.heavensWill")}>
                                    {formatNumber(actionState?.resources.HeavensWill ?? row.resources.HeavensWill ?? 0)}
                                  </span>
                                )}
                                {showVitalityColumn && (
                                  <span data-mobile-label={t("system.resource.vitality")}>
                                    {rotation.infiniteVitality
                                      ? "∞"
                                      : formatResourceRange(
                                          actionState?.resources.Vitality ?? row.resources.Vitality ?? 0,
                                          actionState?.resourceRanges?.Vitality ?? row.resourceRanges?.Vitality,
                                        )}
                                  </span>
                                )}
                                <span className="rotation-action-damage" data-mobile-label={t("ui.app.damage")}>
                                  {actionCalculated ? (
                                    <RotationActionBreakdownValue
                                      breakdown={calculateTimelineActionBreakdown(row, actionIndex ?? 0)}
                                    />
                                  ) : null}
                                </span>
                                <span data-mobile-label={t("ui.app.buff")}>
                                  {effectNames(displayedActionBuffs, actionTime)}
                                </span>
                                <span data-mobile-label={t("ui.app.debuff")}>
                                  {effectNames(actionDebuffs, actionTime)}
                                </span>
                                <span aria-hidden="true" />
                              </div>
                            );
                          })()}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
            {error && <p className="editor-error">{error}</p>}
          </div>
        ) : (
          <div className="rotation-editor-content">
            <p className="array-editor-empty">{t("ui.app.noRotationsMatchTheSelectedMartialArtsAdd")}</p>
          </div>
        )}
      </div>
      <dialog className="rotation-readable-dialog" ref={readableDialogRef} onClose={() => setReadableDialogOpen(false)}>
        <div className="rotation-readable-heading">
          <div>
            <span className="detail-kicker">{t("ui.app.readableFormat")}</span>
            <h3>{editingRotationDisplayName}</h3>
          </div>
          <button
            className="icon-button"
            type="button"
            aria-label={t("ui.app.closeReadableRotation")}
            onClick={() => readableDialogRef.current?.close()}
          >
            <UiIcon name="close" />
          </button>
        </div>
        <p>{t("ui.app.skillsBeforeTheStartUseARoundedPre")}</p>
        <textarea
          ref={readableTextRef}
          readOnly
          value={readableRotation}
          aria-label={t("ui.app.readableRotation")}
          onFocus={(event) => event.currentTarget.select()}
        />
        <div className="rotation-readable-actions">
          <span role="status">{readableCopyStatus}</span>
          <button className="button button-secondary" type="button" onClick={() => readableDialogRef.current?.close()}>
            {t("ui.app.close")}
          </button>
          <button className="button button-primary" type="button" onClick={copyReadableRotation}>
            {t("ui.app.copy")}
          </button>
        </div>
      </dialog>
    </section>
  );
}

export default function App() {
  const compactViewport = useSyncExternalStore(subscribeToCompactLayout, compactLayoutSnapshot, () => false);
  const [locale, setLocale] = useState(getLocale);
  const [activeTab, setActiveTab] = useState<
    "main" | "build" | "breakdown" | "rotations" | "simulation" | "skills" | "settings"
  >("main");
  // Mount the simulator only on first use, then keep it mounted while hidden. Its module is preloaded below.
  // Remounting would cancel its worker and discard progress/results on every tab switch.
  const [simulationMounted, setSimulationMounted] = useState(false);

  useEffect(() => {
    const preloadDeferredTabs = () => {
      void Promise.allSettled([loadBuildTab(), loadSimulationTab()]);
    };
    if (typeof window.requestIdleCallback === "function") {
      const idleCallback = window.requestIdleCallback(preloadDeferredTabs, { timeout: 1500 });
      return () => window.cancelIdleCallback(idleCallback);
    }
    const timeout = window.setTimeout(preloadDeferredTabs, 1);
    return () => window.clearTimeout(timeout);
  }, []);

  const [skillOverrides, setSkillOverrides] = useState<SkillOverrides>(loadSkillOverrides);
  const skillEditorModified = hasSkillOverrides(skillOverrides);
  const [activeSimulation, setActiveSimulation] = useState<{
    bundle: RotationSimulationBundle;
    rotationName: string;
    bundleKey: string;
    rotationIsDefault: boolean;
    graduationFingerprint?: string;
    graduationDps?: number;
  }>();
  const rotationMetrics = useSyncExternalStore(subscribeToRotationMetrics, getRotationMetrics, getRotationMetrics);
  const [innerWayRevision, setInnerWayRevision] = useState(0);
  const [statOverrides, setStatOverrides] = useState<CharacterStatOverrides>(loadStatOverrides);
  const [attunementOverrides, setAttunementOverrides] = useState<AttunementOverrides>(loadAttunementOverrides);
  const [characterProfiles, setCharacterProfiles] = useState<CharacterProfile[]>(loadCharacterProfiles);
  const [devMode, setDevMode] = useState(loadDevMode);
  const [layoutPreview, setLayoutPreview] = useState<LayoutMode>(() => loadLayoutPreview(compactViewport));
  const layoutMode: LayoutMode = devMode ? layoutPreview : compactViewport ? "mobile" : "pc";
  const [pathId, setPathId] = useState<PathId>(() => loadSelectedPath(devMode));
  const [settings, setSettings] = useState<CalculatorSettings>(() => settingsForPath(loadSettings(), pathId));
  const [buildState, setBuildState] = useState<BuildState>(loadBuildState);
  const [activeBuildIdsByPath, setActiveBuildIdsByPath] = useState<PathSelectionIds>(() =>
    loadPathSelectionIds(activeBuildByPathStorageKey, activeBuildStorageKey, pathId),
  );
  const [activeRotationIdsByPath, setActiveRotationIdsByPath] = useState<PathSelectionIds>(() =>
    loadPathSelectionIds(activeRotationByPathStorageKey, activeRotationStorageKey, pathId),
  );
  const rotationCalculationCacheRef = useRef(new RotationCalculationCache());
  const breakthrough = breakthroughProfile(settings);
  const enemy: EnemyProfile = breakthrough;
  const availableBuildEntries = buildState.entries.filter(
    (entry) =>
      (devMode || !buildEntryIsTestPreset(entry)) &&
      buildEntryAvailableForPath(entry, typedPathDefinitions[pathId].buildGroup, settings.weapons),
  );
  const activeBuild =
    availableBuildEntries.find((entry) => entry.id === activeBuildIdsByPath[pathId]) ??
    availableBuildEntries.find((entry) => entry.id === defaultBuildIdForPath(pathId)) ??
    availableBuildEntries[0];
  const effectiveBuildState = useMemo(
    () => ({ ...buildState, activeBuildId: activeBuild?.id ?? "" }),
    [activeBuild?.id, buildState],
  );
  const selectedRotationId = activeRotationIdsByPath[pathId] ?? defaultRotationIdForPath(pathId);
  const activeBuildDisplayName = activeBuild
    ? (activeBuild.isDefault ? gameText(activeBuild.name) : activeBuild.name) || "Unnamed Build"
    : "Unnamed Build";
  const activeBuildSetup = useMemo(() => resolveBuildSetup(activeBuild), [activeBuild]);
  const [buildSetupOverrides, setBuildSetupOverrides] = useState<BuildSetupOverrides>(() =>
    loadBuildSetupOverrides(activeBuildSetup),
  );
  const buildSetup = useMemo<BuildSetup>(
    () => ({
      innerWays: (buildSetupOverrides.innerWays ?? activeBuildSetup.innerWays).map((row) => ({ ...row })),
      weaponSets: { ...(buildSetupOverrides.weaponSets ?? activeBuildSetup.weaponSets) },
      armorSets: { ...(buildSetupOverrides.armorSets ?? activeBuildSetup.armorSets) },
      bowRingSet: buildSetupOverrides.bowRingSet ?? activeBuildSetup.bowRingSet,
      arsenal: buildSetupOverrides.arsenal ?? activeBuildSetup.arsenal,
    }),
    [activeBuildSetup, buildSetupOverrides],
  );
  const activeGearInventory = useMemo(
    () =>
      activeBuild
        ? resolveBuildInventory(activeBuild, buildState.gearItems, settings.weapons)
        : { items: [], equipped: {} },
    [activeBuild, buildState.gearItems, settings.weapons],
  );
  const equippedGearEffects = useMemo(
    () => calculateEquippedGearEffects(activeGearInventory, settings.weapons, activeBuild?.isDefault !== true),
    [activeGearInventory, settings.weapons, activeBuild?.isDefault],
  );
  const gearStatEffect = useMemo<StatEffectContainer>(
    () => ({ rawStat: equippedGearEffects.stats }),
    [equippedGearEffects],
  );
  const globalStatState = useMemo(
    () => calculateGlobalStatState(statOverrides, settings, gearStatEffect, buildSetup),
    [statOverrides, settings, gearStatEffect, buildSetup, innerWayRevision],
  );
  const displayedStats = globalStatState.stats;
  const derivedStats = globalStatState.derivedStats;
  const resolvedAttunementStats = useMemo(
    () =>
      resolveAttunementStats(defaultAttunementStats, equippedGearEffects.attunement, attunementOverrides, {
        physicalPenetration: displayedStats.physicalPenetration,
        formlessPenetration: displayedStats.formlessPenetration,
      }),
    [
      attunementOverrides,
      displayedStats.physicalPenetration,
      displayedStats.formlessPenetration,
      equippedGearEffects.attunement,
    ],
  );
  const character = useMemo(
    () => ({
      stats: displayedStats,
      rawStats: globalStatState.rawStats,
      baseStats: globalStatState.baseStats,
      attunementStats: resolvedAttunementStats.calculation,
      displayedAttunementStats: resolvedAttunementStats.displayed,
      settings,
      enemy,
      derivedStats,
      innerWayRevision,
      gearStatEffect,
      buildSetup,
    }),
    [
      displayedStats,
      globalStatState.baseStats,
      globalStatState.rawStats,
      resolvedAttunementStats,
      settings,
      enemy,
      derivedStats,
      innerWayRevision,
      gearStatEffect,
      buildSetup,
    ],
  );
  const updateStatOverride = (key: keyof CharacterStats, value: number) => {
    setStatOverrides((current) => ({ ...current, [key]: value }));
  };
  const resetStatOverride = (key: keyof CharacterStats) => {
    setStatOverrides((current) => {
      const next = { ...current };
      delete next[key];
      return next;
    });
  };
  const updateAttunementOverride = (key: keyof AttunementStats, value: number) =>
    setAttunementOverrides((current) => ({ ...current, [key]: value }));
  const resetAttunementOverride = (key: keyof AttunementStats) =>
    setAttunementOverrides((current) => {
      const next = { ...current };
      delete next[key];
      return next;
    });
  function updateBuildSetupOverride<K extends keyof BuildSetup>(key: K, value: BuildSetup[K]) {
    setBuildSetupOverrides((current) => {
      if (!sameBuildSetupValue(key, value, activeBuildSetup[key])) return { ...current, [key]: value };
      const next = { ...current };
      delete next[key];
      return next;
    });
  }
  const resetBuildSetupOverride = (key: keyof BuildSetup) =>
    setBuildSetupOverrides((current) => {
      const next = { ...current };
      delete next[key];
      return next;
    });
  const applyCharacterProfile = (profile?: CharacterProfile) => {
    setStatOverrides(profile ? { ...profile.statOverrides } : {});
    setAttunementOverrides(profile ? { ...profile.attunementOverrides } : {});
    if (!profile) {
      setBuildSetupOverrides({});
      return;
    }
    setBuildSetupOverrides({
      innerWays: profile.innerWays.map((row) => ({ ...row })),
      weaponSets: { ...profile.buildSetup.weaponSets },
      armorSets: { ...profile.buildSetup.armorSets },
      bowRingSet: profile.buildSetup.bowRingSet,
      arsenal: profile.buildSetup.arsenal,
    });
  };
  const handleRotationMetrics = (metrics: RotationMetrics, isActive: boolean) => {
    if (isActive) publishRotationMetrics(metrics);
  };
  const handleActiveSimulationBundle = useCallback(
    (
      bundle: RotationSimulationBundle,
      rotationName: string,
      bundleKey: string,
      rotationIsDefault: boolean,
      graduation?: { fingerprint: string; dps?: number },
    ) =>
      setActiveSimulation({
        bundle,
        rotationName,
        bundleKey,
        rotationIsDefault,
        graduationFingerprint: graduation?.fingerprint,
        graduationDps: graduation?.dps,
      }),
    [],
  );
  const handleGraduationDps = useCallback((fingerprint: string, dps: number) => {
    setActiveSimulation((current) =>
      current?.graduationFingerprint === fingerprint ? { ...current, graduationDps: dps } : current,
    );
  }, []);
  const activeRotationDisplayName = activeSimulation
    ? activeSimulation.rotationIsDefault
      ? gameText(activeSimulation.rotationName)
      : activeSimulation.rotationName
    : "—";
  const activateBuildForPath = useCallback(
    (id: string, targetPathId = pathId) => {
      setActiveBuildIdsByPath((current) => {
        const next = withPathSelection(current, targetPathId, id);
        if (next !== current) setPersistentItem(activeBuildByPathStorageKey, JSON.stringify(next));
        return next;
      });
      setBuildState((current) => (current.activeBuildId === id ? current : { ...current, activeBuildId: id }));
    },
    [pathId],
  );
  const activateRotationForPath = useCallback(
    (id: string, targetPathId = pathId) => {
      setActiveRotationIdsByPath((current) => {
        const next = withPathSelection(current, targetPathId, id);
        if (next !== current) setPersistentItem(activeRotationByPathStorageKey, JSON.stringify(next));
        return next;
      });
    },
    [pathId],
  );
  const transitionPath = (
    nextPathId: PathId,
    options: { weapons?: [WeaponId, WeaponId]; rotationId?: string } = {},
  ) => {
    if (pathRequiresDev(typedPathDefinitions[nextPathId]) && !devMode) return;
    const nextSettings =
      nextPathId === "mixed" && options.weapons
        ? { ...settingsForPath(settings, nextPathId), weapons: [...options.weapons] as [WeaponId, WeaponId] }
        : settingsForPath(settings, nextPathId);
    const nextBuildEntries = buildState.entries.filter(
      (entry) =>
        (devMode || !buildEntryIsTestPreset(entry)) &&
        buildEntryAvailableForPath(entry, typedPathDefinitions[nextPathId].buildGroup, nextSettings.weapons),
    );
    const nextRotationEntries = loadRotationEntries().filter(
      (entry) => (devMode || !entry.test) && rotationAvailableForWeapons(entry, nextSettings.weapons),
    );
    const selection = resolvePathWorkspaceSelection({
      buildIds: nextBuildEntries.map((entry) => entry.id),
      rotationIds: nextRotationEntries.map((entry) => entry.id),
      savedBuildId: activeBuildIdsByPath[nextPathId],
      savedRotationId: activeRotationIdsByPath[nextPathId],
      requestedRotationId: options.rotationId,
      defaultBuildId: defaultBuildIdForPath(nextPathId),
      defaultRotationId: defaultRotationIdForPath(nextPathId),
    });
    if (!selection) return;

    supersedeRotationCalculationRequests();
    endRotationCalculation();
    setActiveSimulation(undefined);

    const nextBuildIds = withPathSelection(activeBuildIdsByPath, nextPathId, selection.buildId);
    const nextRotationIds = withPathSelection(activeRotationIdsByPath, nextPathId, selection.rotationId);
    if (nextBuildIds !== activeBuildIdsByPath)
      setPersistentItem(activeBuildByPathStorageKey, JSON.stringify(nextBuildIds));
    if (nextRotationIds !== activeRotationIdsByPath)
      setPersistentItem(activeRotationByPathStorageKey, JSON.stringify(nextRotationIds));
    setPersistentItem(pathStorageKey, nextPathId);
    setActiveBuildIdsByPath(nextBuildIds);
    setActiveRotationIdsByPath(nextRotationIds);
    setBuildState((current) => ({ ...current, activeBuildId: selection.buildId }));
    setPathId(nextPathId);
    setSettings(nextSettings);
    setInnerWayRevision((current) => current + 1);
  };
  const selectPath = (nextPathId: PathId) => transitionPath(nextPathId);
  const selectBuildWeapons = (nextWeapons: [WeaponId, WeaponId], rotationId?: string) => {
    const matchingPath = (Object.entries(typedPathDefinitions) as Array<[PathId, PathDefinition]>).find(
      ([candidateId, definition]) =>
        candidateId !== "mixed" &&
        (!pathRequiresDev(definition) || devMode) &&
        definition.lockedWeapons &&
        sameWeaponPair(definition.lockedWeapons, nextWeapons),
    );
    const nextPathId = matchingPath?.[0] ?? (devMode ? "mixed" : undefined);
    if (!nextPathId) return false;
    transitionPath(nextPathId, { weapons: nextWeapons, rotationId });
    return true;
  };
  const toggleDevMode = () => {
    const nextDevMode = !devMode;
    localStorage.setItem(devModeStorageKey, String(nextDevMode));
    setDevMode(nextDevMode);
    if (!nextDevMode && pathRequiresDev(typedPathDefinitions[pathId])) selectPath("stonesplitStrength");
    if (!nextDevMode && isLocaleWip(locale)) void changeLocale("en");
  };
  const changeLocale = async (nextLocale: string) => {
    if (await selectLocale(nextLocale)) setLocale(getLocale());
  };
  const changeLayoutPreview = (nextLayout: LayoutMode) => {
    setPersistentItem(layoutPreviewStorageKey, nextLayout);
    setLayoutPreview(nextLayout);
  };
  const updateSkillOverrides = (nextOverrides: SkillOverrides) => {
    setSkillOverrides(nextOverrides);
    if (hasSkillOverrides(nextOverrides)) setPersistentItem(skillStorageKey, serializeSkillOverrides(nextOverrides));
    else removePersistentItem(skillStorageKey);
  };

  useEffect(() => localStorage.setItem(statOverrideStorageKey, JSON.stringify(statOverrides)), [statOverrides]);
  useEffect(
    () => localStorage.setItem(characterProfileStorageKey, serializeCharacterProfiles(characterProfiles)),
    [characterProfiles],
  );
  useEffect(() => {
    if (!activeBuild) return;
    if (activeBuildIdsByPath[pathId] !== activeBuild.id) activateBuildForPath(activeBuild.id);
    else if (activeBuild.id !== buildState.activeBuildId)
      setBuildState((current) => ({ ...current, activeBuildId: activeBuild.id }));
  }, [activateBuildForPath, activeBuild, activeBuildIdsByPath, buildState.activeBuildId, pathId]);
  useEffect(() => localStorage.setItem(buildListStorageKey, serializeBuildState(buildState)), [buildState]);
  useEffect(
    () => setPersistentItem(attunementOverrideStorageKey, JSON.stringify(attunementOverrides)),
    [attunementOverrides],
  );
  useEffect(
    () => setPersistentItem(buildSetupOverrideStorageKey, JSON.stringify(buildSetupOverrides)),
    [buildSetupOverrides],
  );
  useEffect(
    () => setPersistentItem(settingsStorageKey, JSON.stringify({ weapons: settings.weapons, ping: settings.ping })),
    [settings.weapons, settings.ping],
  );
  useEffect(() => setPersistentItem(pathStorageKey, pathId), [pathId]);

  return (
    <main
      className={`page-shell layout-${layoutMode} ${layoutMode === "pc" && (activeTab === "build" || activeTab === "rotations") ? "viewport-page-shell" : ""}`}
      data-layout={layoutMode}
    >
      <header className="page-header">
        <div>
          <h1>{t("ui.app.whereBuildsMeet")}</h1>
          <p className="intro">{t("ui.app.buildSimulateAndOptimizeForWhereWindsMeet")}</p>
        </div>
        <div className="page-header-controls">
          <NoticeArea />
          <label className="locale-selector">
            <span>{t("ui.app.language")}</span>
            <select value={locale} onChange={(event) => void changeLocale(event.target.value)}>
              {getSupportedLocales().map((supportedLocale) => (
                <option
                  value={supportedLocale}
                  key={supportedLocale}
                  disabled={!devMode && isLocaleWip(supportedLocale)}
                >
                  {getLocaleDisplayName(supportedLocale)}
                </option>
              ))}
            </select>
          </label>
          <button
            className="button button-secondary dev-mode-button"
            type="button"
            aria-pressed={devMode}
            onClick={toggleDevMode}
          >
            {t("ui.app.dev")}
          </button>
        </div>
      </header>
      <section className="path-selector" aria-label={t("ui.app.combatPath")}>
        <div className="path-selector-options">
          {(Object.entries(typedPathDefinitions) as Array<[PathId, PathDefinition]>).map(([value, definition]) => (
            <button
              className={pathId === value ? "selected" : ""}
              type="button"
              key={value}
              aria-pressed={pathId === value}
              disabled={pathRequiresDev(definition) && !devMode}
              onClick={() => selectPath(value)}
            >
              {definition.icon && <img src={`${import.meta.env.BASE_URL}paths/${definition.icon}`} alt="" />}
              <span>{gameText(definition.name)}</span>
              {definition.status !== "available" && (
                <small className="path-status-badge">{pathStatusLabel(definition)}</small>
              )}
            </button>
          ))}
        </div>
      </section>
      <nav className="main-tabs" aria-label={t("ui.app.mainSections")}>
        <button className={activeTab === "main" ? "active" : ""} type="button" onClick={() => setActiveTab("main")}>
          {t("ui.app.main")}
        </button>
        <button className={activeTab === "build" ? "active" : ""} type="button" onClick={() => setActiveTab("build")}>
          {t("ui.app.build")}
        </button>
        <button
          className={activeTab === "breakdown" ? "active" : ""}
          type="button"
          onClick={() => setActiveTab("breakdown")}
        >
          {t("ui.app.dpsBreakdown", {
            dps:
              rotationMetrics && rotationMetrics.hps > 0 ? `${t("system.dps")} / ${t("system.hps")}` : t("system.dps"),
          })}
        </button>
        <button
          className={activeTab === "rotations" ? "active" : ""}
          type="button"
          onClick={() => setActiveTab("rotations")}
        >
          {t("ui.app.rotationEditor")}
        </button>
        <button
          className={activeTab === "simulation" ? "active" : ""}
          type="button"
          onClick={() => {
            setSimulationMounted(true);
            setActiveTab("simulation");
          }}
        >
          {t("ui.app.simulation")}
        </button>
        <button
          className={`${activeTab === "skills" ? "active" : ""} ${skillEditorModified ? "modified" : ""}`}
          type="button"
          onClick={() => setActiveTab("skills")}
        >
          {t("ui.app.skillEditor")}
        </button>
        <button
          className={activeTab === "settings" ? "active" : ""}
          type="button"
          onClick={() => setActiveTab("settings")}
        >
          {t("ui.app.settings")}
        </button>
      </nav>
      {activeTab === "main" ? (
        <StatsTab
          character={character}
          pathId={pathId}
          statOverrides={statOverrides}
          attunementOverrides={attunementOverrides}
          characterProfiles={characterProfiles}
          buildSetupOverrides={buildSetupOverrides}
          onStatChange={updateStatOverride}
          onStatReset={resetStatOverride}
          onAttunementChange={updateAttunementOverride}
          onAttunementReset={resetAttunementOverride}
          onApplyCharacterProfile={applyCharacterProfile}
          onCharacterProfilesChange={setCharacterProfiles}
          onBreakthroughChange={(breakthrough) => setSettings((current) => ({ ...current, breakthrough }))}
          onBuildSetupChange={updateBuildSetupOverride}
          onBuildSetupReset={resetBuildSetupOverride}
          rotationMetrics={rotationMetrics}
          graduationDps={activeSimulation?.graduationDps}
          activeBuildName={activeBuildDisplayName}
          activeRotationName={activeRotationDisplayName}
          onInnerWayChange={() => setInnerWayRevision((current) => current + 1)}
        />
      ) : activeTab === "build" ? (
        <FeatureLoadBoundary>
          <Suspense fallback={<div className="viewport-tab-content" />}>
            <div className="viewport-tab-content">
              <BuildTab
                weapons={settings.weapons}
                martialArtTags={settings.weapons.map((weapon) => martialArtDefinitions[weapon].tag)}
                pathTag={pathId === "mixed" ? undefined : typedPathDefinitions[pathId].tag}
                buildGroup={typedPathDefinitions[pathId].buildGroup}
                graduatedBuildId={typedPathDefinitions[pathId].graduated}
                devMode={devMode}
                buildState={effectiveBuildState}
                onBuildStateChange={setBuildState}
                onActiveBuildChange={activateBuildForPath}
                onSelectBuildWeapons={selectBuildWeapons}
              />
            </div>
          </Suspense>
        </FeatureLoadBoundary>
      ) : activeTab === "breakdown" ? (
        <BreakdownTab metrics={rotationMetrics} pathId={pathId} />
      ) : activeTab === "skills" ? (
        <SkillEditorTab
          weapons={settings.weapons}
          overrides={skillOverrides}
          onOverridesChange={updateSkillOverrides}
        />
      ) : activeTab === "settings" ? (
        <SettingsTab
          settings={settings}
          pathId={pathId}
          devMode={devMode}
          layoutMode={layoutMode}
          onSettingsChange={setSettings}
          onLayoutChange={changeLayoutPreview}
        />
      ) : null}
      <div className={`viewport-tab-content ${activeTab === "rotations" ? "" : "tab-hidden"}`}>
        <RotationEditorTab
          key={pathId}
          character={character}
          pathId={pathId}
          devMode={devMode}
          defaultRotationId={defaultRotationIdForPath(pathId)}
          selectedRotationId={selectedRotationId}
          calculationCache={rotationCalculationCacheRef.current}
          skillOverrides={skillOverrides}
          onSelectRotationWeapons={selectBuildWeapons}
          onActiveRotationChange={activateRotationForPath}
          onMetricsChange={handleRotationMetrics}
          onActiveSimulationBundleChange={handleActiveSimulationBundle}
          onGraduationDpsChange={handleGraduationDps}
        />
      </div>
      {simulationMounted && (
        <div className={activeTab === "simulation" ? "" : "tab-hidden"}>
          <FeatureLoadBoundary>
            <Suspense fallback={null}>
              <SimulationTab
                bundle={activeSimulation?.bundle}
                bundleKey={activeSimulation?.bundleKey}
                rotationName={activeSimulation ? activeRotationDisplayName : undefined}
                buildName={activeBuildDisplayName}
              />
            </Suspense>
          </FeatureLoadBoundary>
        </div>
      )}
      <footer className="page-footer">
        <span>{t("ui.app.authorGreydustWwmIgnGreydustDiscord")}</span>
        <span className="page-footer-accuracy">
          {t("ui.app.accuracyMatters")}{" "}
          <a href="https://github.com/greydust/where-builds-meet/issues" target="_blank" rel="noreferrer">
            {t("ui.app.reportAnyDamageDiscrepancy")}
          </a>
        </span>
        <a href="https://github.com/greydust/where-builds-meet" target="_blank" rel="noreferrer">
          {t("ui.app.github")}
        </a>
      </footer>
    </main>
  );
}
